<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

// Fonction simple de redirection
function redirect($url) {
    header("Location: $url");
    exit;
}

// Fonction simple pour générer un token CSRF
function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Déterminer le mode d'affichage (clair/sombre)
$darkMode = false;
if (isset($_COOKIE['darkMode']) && $_COOKIE['darkMode'] === 'true') {
    $darkMode = true;
}

// Si l'utilisateur change de mode
if (isset($_GET['mode'])) {
    if ($_GET['mode'] === 'dark') {
        $darkMode = true;
        setcookie('darkMode', 'true', time() + (365 * 24 * 60 * 60), '/');
    } else if ($_GET['mode'] === 'light') {
        $darkMode = false;
        setcookie('darkMode', 'false', time() + (365 * 24 * 60 * 60), '/');
    }
    // Rediriger vers la même page sans le paramètre GET
    $redirectUrl = strtok($_SERVER['REQUEST_URI'], '?');
    header("Location: $redirectUrl");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr" class="<?= $darkMode ? 'dark-mode' : '' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - MusiTeach</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            /* Couleurs de MusiTeach - Mode clair */
            --primary-color: #4F5D95;     /* Violet-bleu */
            --secondary-color: #FF9933;   /* Orange */
            --accent-color: #27AE60;      /* Vert */
            --text-color: #333333;        /* Texte foncé */
            --bg-color: #f0f2f5;          /* Fond clair */
            --card-bg: #ffffff;           /* Arrière-plan carte */
            --input-bg: #ffffff;          /* Arrière-plan input */
            --border-color: #dddddd;      /* Couleur bordure */
            --muted-color: #6c757d;       /* Texte secondaire */
        }
        
        /* Variables pour le mode sombre */
        .dark-mode {
            --primary-color: #6D7FBE;     /* Violet-bleu plus clair */
            --secondary-color: #FFA94D;   /* Orange plus clair */
            --accent-color: #2ECC71;      /* Vert plus clair */
            --text-color: #E1E1E1;        /* Texte clair */
            --bg-color: #121212;          /* Fond très sombre */
            --card-bg: #1E1E1E;           /* Arrière-plan carte */
            --input-bg: #2D2D2D;          /* Arrière-plan input */
            --border-color: #444444;      /* Couleur bordure */
            --muted-color: #AAAAAA;       /* Texte secondaire */
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            transition: all 0.3s ease;
        }
        
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .login-card {
            width: 100%;
            max-width: 450px;
            background: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .login-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 2.5rem 2rem 4rem;
            text-align: center;
            color: white;
            border-radius: 0 0 30% 30%;
            margin-bottom: -2rem;
        }
        
        .login-logo {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 1rem;
            letter-spacing: 1px;
        }
        
        .login-form {
            padding: 3rem 2rem 2rem;
        }
        
        .form-control {
            padding: 0.75rem 1.25rem;
            border-radius: 10px;
            border: 1px solid var(--border-color);
            background-color: var(--input-bg);
            color: var(--text-color);
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(79, 93, 149, 0.25);
        }
        
        .input-group-text {
            background-color: var(--input-bg);
            border-right: none;
            border-radius: 10px 0 0 10px;
            color: var(--muted-color);
            border-color: var(--border-color);
        }
        
        .input-group .form-control {
            border-left: none;
            border-radius: 0 10px 10px 0;
        }
        
        .login-button {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: 10px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s;
        }
        
        .login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
        }
        
        .social-login {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .social-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            transition: all 0.3s;
        }
        
        .social-btn:hover {
            transform: translateY(-3px);
        }
        
        .facebook {
            background-color: #3b5998;
        }
        
        .google {
            background-color: #db4437;
        }
        
        .twitter {
            background-color: #1da1f2;
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 1.5rem 0;
            color: var(--muted-color);
        }
        
        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid var(--border-color);
        }
        
        .divider::before {
            margin-right: 1rem;
        }
        
        .divider::after {
            margin-left: 1rem;
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .footer-links {
            text-align: center;
            margin-top: 1.5rem;
        }
        
        .footer-links a {
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .alert {
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }
        
        .alert-dismissible .btn-close {
            padding: 1.25rem;
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-card {
            animation: fadeIn 0.5s ease-out;
        }
        
        /* Mode switch */
        .mode-switch {
            position: fixed;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            transition: all 0.3s;
        }
        
        .mode-switch:hover {
            transform: scale(1.1);
        }
        
        /* Dark mode specific styles */
        .dark-mode .form-control::placeholder {
            color: #999;
        }
        
        .dark-mode .form-text {
            color: #bbb;
        }
        
        .dark-mode .btn-outline-primary {
            border-color: var(--primary-color);
            color: var(--primary-color);
        }
        
        .dark-mode .btn-outline-primary:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .dark-mode .btn-outline-danger {
            border-color: var(--secondary-color);
            color: var(--secondary-color);
        }
        
        .dark-mode .btn-outline-danger:hover {
            background-color: var(--secondary-color);
            color: white;
        }
    </style>
</head>
<body>
    <!-- Mode Switch Button -->
    <a href="?mode=<?= $darkMode ? 'light' : 'dark' ?>" class="mode-switch" title="Changer de mode">
        <i class="fas fa-<?= $darkMode ? 'sun' : 'moon' ?>"></i>
    </a>
    
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">MusiTeach</div>
                <p>La plateforme qui connecte élèves et professeurs de musique</p>
            </div>
            
            <div class="login-form">
                <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?= $_SESSION['flash_message']['type'] ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['flash_message']['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['flash_message']); ?>
                <?php endif; ?>
                
                <h2 class="text-center mb-4">Connexion</h2>
                
                <form action="process_login.php" method="post">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Adresse email" required
                                value="<?= isset($_SESSION['login_email']) ? htmlspecialchars($_SESSION['login_email']) : '' ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" required>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between mb-3">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="remember" name="remember" value="1">
                            <label class="form-check-label" for="remember">Se souvenir de moi</label>
                        </div>
                        <a href="reset_password.php" class="text-decoration-none">Mot de passe oublié ?</a>
                    </div>
                    
                    <button type="submit" class="btn login-button w-100 mb-3">Se connecter</button>
                </form>
                
                <div class="divider">ou connectez-vous avec</div>
                
                <div class="social-login">
                    <a href="#" class="social-btn facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-btn google"><i class="fab fa-google"></i></a>
                    <a href="#" class="social-btn twitter"><i class="fab fa-twitter"></i></a>
                </div>
                
                <div class="footer-links">
                    <p class="mb-1">Pas encore de compte ? <a href="signup.php">S'inscrire</a></p>
                    <?php if (defined('REQUIRE_EMAIL_VERIFICATION') && REQUIRE_EMAIL_VERIFICATION): ?>
                    <p><a href="resend_verification.php">Renvoyer l'email de vérification</a></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
// Nettoyer les données de connexion stockées en session
if (isset($_SESSION['login_email'])) {
    unset($_SESSION['login_email']);
}
?>