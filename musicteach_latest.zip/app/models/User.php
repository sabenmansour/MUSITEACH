<?php
require_once __DIR__ . '/../db_connect.php';
require_once __DIR__ . '/../auth.php';

class User {
    /**
     * Récupérer un utilisateur par son ID
     */
    public static function findById($id) {
        try {
            require_once __DIR__ . '/../db_connect.php';
            $db = getDbConnection();
            $stmt = $db->prepare("SELECT * FROM users WHERE id = :id");
            $stmt->execute(['id' => $id]);
            return $stmt->fetch();
        } catch (Exception $e) {
            if (defined('DEBUG') && DEBUG) {
                error_log("Error in findById: " . $e->getMessage());
            }
            return false;
        }
    }
    
    /**
     * Récupérer un utilisateur par son email
     */
    public static function findByEmail($email) {
        try {
            require_once __DIR__ . '/../db_connect.php';
            $db = getDbConnection();
            $stmt = $db->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->execute(['email' => $email]);
            return $stmt->fetch();
        } catch (Exception $e) {
            if (defined('DEBUG') && DEBUG) {
                error_log("Error in findByEmail: " . $e->getMessage());
            }
            return false;
        }
    }
    
    /**
     * Récupérer un utilisateur par son token d'activation
     */
    public static function findByActivationToken($token) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE activation_token = :token AND activation_expires > NOW()");
        $stmt->execute(['token' => $token]);
        return $stmt->fetch();
    }
    
    /**
     * Créer un nouvel utilisateur
     */
    public static function create($name, $email, $password, $role = 'student') {
        try {
            require_once __DIR__ . '/../db_connect.php';
            $db = getDbConnection();
            $hashedPassword = hashPassword($password);
            
            // Générer un token d'activation si la vérification est requise
            $activationToken = null;
            $activationExpires = null;
            
            if (defined('REQUIRE_EMAIL_VERIFICATION') && REQUIRE_EMAIL_VERIFICATION) {
                $activationToken = generateActivationToken();
                $expiry = defined('EMAIL_VERIFICATION_EXPIRY') ? EMAIL_VERIFICATION_EXPIRY : 24;
                $activationExpires = date('Y-m-d H:i:s', strtotime("+{$expiry} hours"));
            }
            
            $stmt = $db->prepare(
                "INSERT INTO users (name, email, password, role, is_active, activation_token, activation_expires, created_at, updated_at) 
                 VALUES (:name, :email, :password, :role, :is_active, :activation_token, :activation_expires, NOW(), NOW())"
            );
            
            $stmt->execute([
                'name' => $name,
                'email' => $email,
                'password' => $hashedPassword,
                'role' => $role,
                'is_active' => defined('REQUIRE_EMAIL_VERIFICATION') && REQUIRE_EMAIL_VERIFICATION ? 0 : 1,
                'activation_token' => $activationToken,
                'activation_expires' => $activationExpires
            ]);
            
            $userId = $db->lastInsertId();
            
            // Envoyer un email de vérification si nécessaire
            if (defined('REQUIRE_EMAIL_VERIFICATION') && REQUIRE_EMAIL_VERIFICATION && $activationToken) {
                require_once __DIR__ . '/../mail.php';
                sendVerificationEmail($email, $name, $activationToken);
            }
            
            return $userId;
        } catch (Exception $e) {
            if (defined('DEBUG') && DEBUG) {
                error_log("Error in create: " . $e->getMessage());
                if (ini_get('display_errors')) {
                    echo "<p>Error in create: " . $e->getMessage() . "</p>";
                }
            }
            throw $e; // Rethrow to be handled by the caller
        }
    }
    
    /**
     * Mettre à jour un utilisateur
     */
    public static function update($id, $data) {
        $db = getDbConnection();
        
        $allowedFields = ['name', 'email', 'role'];
        $fields = [];
        $params = ['id' => $id];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $fields[] = "$key = :$key";
                $params[$key] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }
    
    /**
     * Mettre à jour le mot de passe d'un utilisateur
     */
    public static function updatePassword($id, $password) {
        $db = getDbConnection();
        $hashedPassword = hashPassword($password);
        
        $stmt = $db->prepare(
            "UPDATE users SET password = :password, updated_at = NOW() WHERE id = :id"
        );
        
        return $stmt->execute([
            'id' => $id,
            'password' => $hashedPassword
        ]);
    }
    
    /**
     * Supprimer un utilisateur
     */
    public static function delete($id) {
        $db = getDbConnection();
        $stmt = $db->prepare("DELETE FROM users WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    /**
     * Récupérer tous les utilisateurs
     */
    public static function findAll($page = 1, $perPage = 10) {
        $db = getDbConnection();
        $offset = ($page - 1) * $perPage;
        
        $stmt = $db->prepare(
            "SELECT * FROM users ORDER BY created_at DESC LIMIT :offset, :limit"
        );
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Compter le nombre total d'utilisateurs
     */
    public static function count() {
        $db = getDbConnection();
        $stmt = $db->query("SELECT COUNT(*) FROM users");
        return $stmt->fetchColumn();
    }
    
    /**
     * Récupérer tous les professeurs
     */
    public static function findAllTeachers($page = 1, $perPage = 10) {
        try {
            require_once __DIR__ . '/../db_connect.php';
            $db = getDbConnection();
            $offset = ($page - 1) * $perPage;
            
            $stmt = $db->prepare(
                "SELECT u.*, p.description, p.instrument, p.experience 
                 FROM users u
                 LEFT JOIN profiles p ON u.id = p.user_id
                 WHERE u.role = 'teacher'
                 ORDER BY u.created_at DESC
                 LIMIT :offset, :limit"
            );
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            if (defined('DEBUG') && DEBUG) {
                error_log("Error in findAllTeachers: " . $e->getMessage());
                if (ini_get('display_errors')) {
                    echo "<p>Error in findAllTeachers: " . $e->getMessage() . "</p>";
                }
            }
            // Return empty array instead of failing
            return [];
        }
    }
    
    /**
     * Compter le nombre total de professeurs
     */
    public static function countTeachers() {
        $db = getDbConnection();
        $stmt = $db->query("SELECT COUNT(*) FROM users WHERE role = 'teacher'");
        return $stmt->fetchColumn();
    }
    
    /**
     * Vérifier si l'email existe déjà
     */
    public static function emailExists($email, $excludeId = null) {
        $db = getDbConnection();
        
        if ($excludeId) {
            $stmt = $db->prepare(
                "SELECT COUNT(*) FROM users WHERE email = :email AND id != :id"
            );
            $stmt->execute(['email' => $email, 'id' => $excludeId]);
        } else {
            $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
            $stmt->execute(['email' => $email]);
        }
        
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * Activer un compte utilisateur
     */
    public static function activate($userId) {
        $db = getDbConnection();
        $stmt = $db->prepare(
            "UPDATE users SET is_active = 1, activation_token = NULL, activation_expires = NULL, updated_at = NOW() 
             WHERE id = :id"
        );
        return $stmt->execute(['id' => $userId]);
    }
    
    /**
     * Vérifier si un compte est actif
     */
    public static function isActive($userId) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT is_active FROM users WHERE id = :id");
        $stmt->execute(['id' => $userId]);
        return (bool)$stmt->fetchColumn();
    }
    
    /**
     * Générer un nouveau token d'activation
     */
    public static function generateNewActivationToken($userId) {
        $db = getDbConnection();
        
        $token = generateActivationToken();
        $expiry = defined('EMAIL_VERIFICATION_EXPIRY') ? EMAIL_VERIFICATION_EXPIRY : 24;
        $expires = date('Y-m-d H:i:s', strtotime("+{$expiry} hours"));
        
        $stmt = $db->prepare(
            "UPDATE users SET activation_token = :token, activation_expires = :expires, updated_at = NOW() 
             WHERE id = :id"
        );
        
        $success = $stmt->execute([
            'id' => $userId,
            'token' => $token,
            'expires' => $expires
        ]);
        
        if ($success) {
            return $token;
        }
        
        return false;
    }
}