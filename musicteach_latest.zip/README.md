# 🎵 MusiTeach

<div align="center">
  <img src="public/resources/img/hero-bg.jpg" alt="MusiTeach Logo" width="600"/>
  <h3>La plateforme qui connecte professeurs et élèves de musique</h3>
</div>

<p align="center">
  <a href="#fonctionnalités">Fonctionnalités</a> •
  <a href="#technologies-utilisées">Technologies</a> •
  <a href="#capture-décran">Captures d'écran</a> •
  <a href="#installation">Installation</a> •
  <a href="#déploiement-docker">Docker</a> •
  <a href="#licence">Licence</a>
</p>

## 🌟 Introduction

MusiTeach est une application web innovante qui met en relation professeurs de musique et élèves. La plateforme permet aux enseignants de proposer leurs services, gérer leur planning et leurs disponibilités, tandis que les élèves peuvent rechercher des professeurs selon différents critères, consulter les profils et réserver des cours en ligne ou en présentiel.

## ✨ Fonctionnalités

### Pour les élèves
- 🔍 Recherche avancée de professeurs par instrument, localisation, tarif
- 👤 Profils détaillés des professeurs avec expérience, qualifications, tarifs
- 📅 Système de réservation intuitif avec calendrier interactif
- 📚 Ressources pédagogiques et contenu éducatif
- 🌓 Interface adaptative avec mode clair/sombre

### Pour les professeurs
- 📝 Création et personnalisation de profil
- 🗓️ Gestion flexible des disponibilités
- 💰 Configuration des tarifs et forfaits
- 📊 Tableau de bord avec statistiques
- 🔔 Notifications de nouvelles réservations

### Autres fonctionnalités
- 🔐 Système d'authentification sécurisé
- 📱 Interface responsive pour tous les appareils
- ❓ FAQ complète et support utilisateur
- 🎯 Navigation intuitive et interface moderne

## 🛠️ Technologies utilisées

- **Backend**: PHP 8.1
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Base de données**: MariaDB 10.6
- **Serveur**: Apache
- **Déploiement**: Docker, Docker Compose
- **Autres**: Git, Font Awesome, AOS Animations

## 📸 Captures d'écran

<div align="center">
  <p><i>Captures d'écran à venir</i></p>
</div>

## 🚀 Installation

### Méthode standard

1. Clonez ce dépôt :
   ```bash
   git clone https://github.com/votre-username/MusiTeach.git
   cd MusiTeach
   ```

2. Configurez votre serveur web pour pointer vers le dossier `/public`

3. Importez la base de données :
   ```bash
   mysql -u [utilisateur] -p [nom_base] < database/schema.sql
   ```

4. Configurez les paramètres de connexion dans `app/config.php`

5. Accédez à l'application via votre navigateur

### Déploiement Docker

Pour un déploiement rapide avec Docker :

1. Clonez ce dépôt :
   ```bash
   git clone https://github.com/votre-username/MusiTeach.git
   cd MusiTeach
   ```

2. Exécutez le script de déploiement :
   ```bash
   ./deploy.sh
   ```

3. Accédez à l'application :
   - Interface web : [http://localhost:8000](http://localhost:8000)
   - PhpMyAdmin : [http://localhost:8080](http://localhost:8080)

Pour plus d'informations sur le déploiement Docker, consultez le [guide Docker](README_DOCKER.md).

## 📝 Structure du projet

```
musicteach/
├── app/               # Code métier et fonctionnalités
│   ├── models/        # Modèles de données
│   └── services/      # Services (logique métier)
├── database/          # Scripts SQL
├── public/            # Point d'entrée de l'application
│   ├── resources/     # Assets (CSS, JS, images)
│   └── *.php          # Pages accessibles publiquement
└── resources/         # Ressources partagées
    ├── css/           # Feuilles de style
    ├── js/            # Scripts JavaScript
    └── views/         # Vues partagées (header, footer)
```

## 🔧 Personnalisation

### Thème et apparence

Vous pouvez personnaliser le thème de l'application en modifiant les variables CSS dans `resources/css/style.css`. L'application supporte nativement un mode clair et un mode sombre.

### Configuration de la base de données

Modifiez les paramètres de connexion dans `app/config.php` ou utilisez les variables d'environnement via Docker.

## 📜 Licence

© 2025 MusiTeach - Tous droits réservés

---

<p align="center">
  Développé avec ❤️ par MusiTeach Team
</p>