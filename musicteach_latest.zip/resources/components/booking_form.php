<?php
/**
 * Formulaire de réservation de cours
 * 
 * @param array $teacher Données du professeur
 * @return string Le HTML du formulaire
 */
function renderBookingForm($teacher) {
    $csrfToken = generateCsrfToken();
    
    return <<<HTML
    <form action="process_booking.php" method="post">
        <input type="hidden" name="csrf_token" value="{$csrfToken}">
        <input type="hidden" name="teacher_id" value="{$teacher['id']}">
        
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="booking_date" class="form-label">Date</label>
                <input type="date" class="form-control" id="booking_date" name="booking_date" required 
                       min="<?= date('Y-m-d') ?>">
            </div>
            <div class="col-md-6">
                <label for="booking_time" class="form-label">Heure</label>
                <select class="form-select" id="booking_time" name="booking_time" required>
                    <option value="">Choisir un horaire</option>
                    <option value="09:00">09:00</option>
                    <option value="10:00">10:00</option>
                    <option value="11:00">11:00</option>
                    <option value="14:00">14:00</option>
                    <option value="15:00">15:00</option>
                    <option value="16:00">16:00</option>
                    <option value="17:00">17:00</option>
                    <option value="18:00">18:00</option>
                </select>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="message" class="form-label">Message au professeur (optionnel)</label>
            <textarea class="form-control" id="message" name="message" rows="3"></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Confirmer la réservation</button>
    </form>
HTML;
}

/**
 * Tableau des réservations
 * 
 * @param array $bookings Liste des réservations
 * @param string $userType Type d'utilisateur (student ou teacher)
 * @return string Le HTML du tableau
 */
function renderBookingsTable($bookings, $userType = 'student') {
    if (empty($bookings)) {
        return '<div class="alert alert-info">Aucune réservation trouvée.</div>';
    }
    
    $html = <<<HTML
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Date et heure</th>
                    <th>{$userType === 'student' ? 'Professeur' : 'Élève'}</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
HTML;
    
    foreach ($bookings as $booking) {
        $bookingDate = new DateTime($booking['date']);
        $now = new DateTime();
        $statusBadge = '';
        
        if ($bookingDate < $now && $booking['status'] === 'confirmed') {
            $statusBadge = '<span class="badge bg-success ms-2">Terminé</span>';
        } elseif ($bookingDate > $now && $booking['status'] === 'confirmed') {
            $statusBadge = '<span class="badge bg-primary ms-2">À venir</span>';
        }
        
        $statusLabel = '';
        switch ($booking['status']) {
            case 'pending':
                $statusLabel = '<span class="badge bg-warning">En attente</span>';
                break;
            case 'confirmed':
                $statusLabel = '<span class="badge bg-success">Confirmé</span>';
                break;
            case 'canceled':
                $statusLabel = '<span class="badge bg-danger">Annulé</span>';
                break;
        }
        
        $actions = '';
        if ($booking['status'] !== 'canceled') {
            $interval = $now->diff($bookingDate);
            $hoursUntilClass = ($interval->days * 24) + $interval->h;
            
            if ($userType === 'teacher' && $booking['status'] === 'pending') {
                $actions = <<<HTML
                <div class="d-flex gap-2">
                    <a href="confirm_booking.php?id={$booking['id']}" class="btn btn-sm btn-success">
                        Confirmer
                    </a>
                    <a href="cancel_booking.php?id={$booking['id']}" 
                       class="btn btn-sm btn-danger"
                       onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ? Cette action est irréversible.');">
                        Refuser
                    </a>
                </div>
HTML;
            } elseif ($bookingDate > $now && $hoursUntilClass >= 24) {
                $actions = <<<HTML
                <a href="cancel_booking.php?id={$booking['id']}" 
                   class="btn btn-sm btn-outline-danger"
                   onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ? Cette action est irréversible.');">
                    Annuler
                </a>
HTML;
            } else {
                $actions = '<span class="text-muted small">Annulation impossible<br>(moins de 24h)</span>';
            }
        }
        
        $name = $userType === 'student' ? $booking['teacher_name'] : $booking['student_name'];
        $nameHtml = $userType === 'student' 
            ? "<a href='profile.php?id={$booking['teacher_id']}'>{$name}</a>"
            : $name;
        
        $html .= <<<HTML
        <tr>
            <td>
                {$booking['date']}
                {$statusBadge}
            </td>
            <td>{$nameHtml}</td>
            <td>{$statusLabel}</td>
            <td>{$actions}</td>
        </tr>
HTML;
    }
    
    $html .= <<<HTML
            </tbody>
        </table>
    </div>
HTML;
    
    return $html;
}