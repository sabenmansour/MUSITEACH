<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Booking.php';

// Vérifier si l'utilisateur est connecté et est un étudiant
requireLogin();
if (!isStudent()) {
    setFlashMessage('error', 'Accès réservé aux élèves.');
    redirect('dashboard.php');
}

// Paramètres de pagination
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10;

// Récupérer les réservations de l'élève
$bookings = Booking::findByStudent($_SESSION['user_id'], $page, $perPage);
$totalBookings = Booking::countByStudent($_SESSION['user_id']);
$totalPages = ceil($totalBookings / $perPage);

// Titre de la page
$pageTitle = "Mes cours réservés";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Mes cours réservés</h1>
    
    <?php if (empty($bookings)): ?>
        <div class="alert alert-info">
            <p>Vous n'avez pas encore réservé de cours.</p>
            <a href="teachers.php" class="btn btn-primary mt-2">Trouver un professeur</a>
        </div>
    <?php else: ?>
        <div class="card mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title mb-0">Vos cours</h5>
                    <a href="teachers.php" class="btn btn-primary">Réserver un nouveau cours</a>
                </div>
                
                <!-- Filtres -->
                <div class="mb-4">
                    <form action="student_bookings.php" method="get" class="row g-3">
                        <div class="col-md-4">
                            <select class="form-select" name="status" id="status">
                                <option value="">Tous les statuts</option>
                                <option value="pending" <?= isset($_GET['status']) && $_GET['status'] === 'pending' ? 'selected' : '' ?>>En attente</option>
                                <option value="confirmed" <?= isset($_GET['status']) && $_GET['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmés</option>
                                <option value="canceled" <?= isset($_GET['status']) && $_GET['status'] === 'canceled' ? 'selected' : '' ?>>Annulés</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <input type="date" class="form-control" name="date" id="date" value="<?= isset($_GET['date']) ? htmlspecialchars($_GET['date']) : '' ?>">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-outline-primary w-100">Filtrer</button>
                        </div>
                    </form>
                </div>
                
                <!-- Liste des réservations -->
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date et heure</th>
                                <th>Professeur</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td>
                                        <?= formatDate($booking['date']) ?>
                                        <?php 
                                        $bookingDate = new DateTime($booking['date']);
                                        $now = new DateTime();
                                        if ($bookingDate < $now && $booking['status'] === 'confirmed') {
                                            echo '<span class="badge bg-success ms-2">Terminé</span>';
                                        } elseif ($bookingDate > $now && $booking['status'] === 'confirmed') {
                                            echo '<span class="badge bg-primary ms-2">À venir</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <a href="profile.php?id=<?= $booking['teacher_id'] ?>"><?= htmlspecialchars($booking['teacher_name']) ?></a>
                                    </td>
                                    <td>
                                        <?php
                                        switch ($booking['status']) {
                                            case 'pending':
                                                echo '<span class="badge bg-warning">En attente</span>';
                                                break;
                                            case 'confirmed':
                                                echo '<span class="badge bg-success">Confirmé</span>';
                                                break;
                                            case 'canceled':
                                                echo '<span class="badge bg-danger">Annulé</span>';
                                                break;
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($booking['status'] !== 'canceled'): ?>
                                            <?php 
                                            $bookingDate = new DateTime($booking['date']);
                                            $now = new DateTime();
                                            $interval = $now->diff($bookingDate);
                                            $hoursUntilClass = ($interval->days * 24) + $interval->h;
                                            
                                            // Permettre l'annulation jusqu'à 24h avant le cours
                                            if ($bookingDate > $now && $hoursUntilClass >= 24): 
                                            ?>
                                                <a href="cancel_booking.php?id=<?= $booking['id'] ?>" 
                                                   class="btn btn-sm btn-outline-danger"
                                                   onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ? Cette action est irréversible.');">
                                                    Annuler
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted small">Annulation impossible<br>(moins de 24h)</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?= generatePagination($page, $totalPages, 'student_bookings.php?page=%d') ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Statistiques -->
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card bg-primary text-white h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-check fa-3x mb-3"></i>
                        <h3 class="card-title h4">Total de cours</h3>
                        <p class="card-text display-4"><?= $totalBookings ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card bg-success text-white h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-check-circle fa-3x mb-3"></i>
                        <h3 class="card-title h4">Cours terminés</h3>
                        <p class="card-text display-4">
                            <?php
                            // Dans un environnement réel, cette information viendrait de la base de données
                            $completedLessons = 0;
                            foreach ($bookings as $booking) {
                                $bookingDate = new DateTime($booking['date']);
                                $now = new DateTime();
                                if ($bookingDate < $now && $booking['status'] === 'confirmed') {
                                    $completedLessons++;
                                }
                            }
                            echo $completedLessons;
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card bg-warning text-white h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-3x mb-3"></i>
                        <h3 class="card-title h4">À venir</h3>
                        <p class="card-text display-4">
                            <?php
                            // Dans un environnement réel, cette information viendrait de la base de données
                            $upcomingLessons = 0;
                            foreach ($bookings as $booking) {
                                $bookingDate = new DateTime($booking['date']);
                                $now = new DateTime();
                                if ($bookingDate > $now && $booking['status'] === 'confirmed') {
                                    $upcomingLessons++;
                                }
                            }
                            echo $upcomingLessons;
                            ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>