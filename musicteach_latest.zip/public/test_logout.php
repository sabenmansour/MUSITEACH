<?php
// Afficher toutes les erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclure les fichiers nécessaires
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';

// Déconnecter l'utilisateur
logoutUser();

// Rediriger vers la page de test de connexion
header("Location: test_login.php");
exit;