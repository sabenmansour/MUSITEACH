<?php
/**
 * Composant de pagination
 * 
 * @param int $currentPage Page actuelle
 * @param int $totalPages Nombre total de pages
 * @param string $urlPattern Modèle d'URL (avec %d pour le numéro de page)
 * @param array $params Paramètres supplémentaires à inclure dans l'URL
 * @return string Le HTML de la pagination
 */
function renderPagination($currentPage, $totalPages, $urlPattern, $params = []) {
    if ($totalPages <= 1) {
        return '';
    }
    
    // Construire la chaîne de requête pour les paramètres supplémentaires
    $queryString = '';
    if (!empty($params)) {
        foreach ($params as $key => $value) {
            if (strpos($urlPattern, '?') === false) {
                $urlPattern .= '?';
            } else {
                $urlPattern .= '&';
            }
            $urlPattern .= $key . '=' . urlencode($value);
        }
    }
    
    $html = '<nav aria-label="Pagination"><ul class="pagination">';
    
    // Bouton précédent
    if ($currentPage > 1) {
        $html .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $currentPage - 1) . '">Précédent</a></li>';
    } else {
        $html .= '<li class="page-item disabled"><span class="page-link">Précédent</span></li>';
    }
    
    // Pages numérotées
    for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++) {
        if ($i === $currentPage) {
            $html .= '<li class="page-item active"><span class="page-link">' . $i . '</span></li>';
        } else {
            $html .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $i) . '">' . $i . '</a></li>';
        }
    }
    
    // Bouton suivant
    if ($currentPage < $totalPages) {
        $html .= '<li class="page-item"><a class="page-link" href="' . sprintf($urlPattern, $currentPage + 1) . '">Suivant</a></li>';
    } else {
        $html .= '<li class="page-item disabled"><span class="page-link">Suivant</span></li>';
    }
    
    $html .= '</ul></nav>';
    return $html;
}