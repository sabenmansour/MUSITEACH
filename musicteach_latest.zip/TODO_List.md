# TODO List - Projet Technologies Web

##  1. Fonctionnalités

### 🔹 1.1 Fonctionnalités de Base (MVP)

#### 🎨 **Front-End**
1. [ ] **Page d'Accueil**  
   - [ ] Barre de navigation simple (Bootstrap/Nginx routing)  
   - [ ] Présentation du service (HTML/CSS)  
2. [ ] **Formulaires d'Inscription et Connexion**  
   - [ ] Formulaire d'inscription (nom, email, mot de passe) (HTML/CSS/JS)  
   - [ ] Connexion avec vérification email/password (Jetstream/Fortify)  
3. [ ] **Affichage de la Liste des Professeurs**  
   - [ ] Liste des professeurs avec nom et description (HTML/CSS, récupération via AJAX)  
4. [ ] **Profil Professeur**  
   - [ ] Affichage du profil avec nom, description, matières enseignées (HTML/CSS)  
   - [ ] Calendrier statique affichant des disponibilités  
5. [ ] **Réservation de Cours**  
   - [ ] Sélection d'une date et heure via formulaire basique  

#### ⚙️ **Back-End**
6. [ ] **Gestion des Comptes et Authentification**  
   - [ ] Profils Élève et Professeur (tables `users`, `profiles`)  
   - [ ] Authentification et sessions (Laravel/Symfony)  
7. [ ] **Gestion des Réservations**  
   - [ ] Stockage des réservations (`bookings` en MariaDB)  
   - [ ] API pour récupérer/modifier/supprimer les réservations  
8. [ ] **Panel d’Administration**  
   - [ ] Liste des utilisateurs avec possibilité de suppression  

#### 🗄 **Base de Données**
9. [ ] **Modèle de Données (MariaDB)**  
   - [ ] Table `users` (id, nom, email, mot de passe, rôle)  
   - [ ] Table `profiles` (user_id, type (élève/professeur), description)  
   - [ ] Table `bookings` (id, professeur_id, élève_id, date, statut)  

---

###  1.2 Fonctionnalités Bonus (Évolutions Futures)

#### 🎨 **Front-End**
10. [ ] **Recherche avancée** (Filtres : instruments, niveaux, avis, tarifs)  
    - 📌 **Technos** : Algolia, Elasticsearch  
11. [ ] **Carte interactive des professeurs**  
    - 📌 **Technos** : Leaflet, Google Maps API  
12. [ ] **Profil Professeur amélioré**  
    - [ ] Téléversement de photo et vidéo  
    - 📌 **Technos** : FFmpeg, Cloudinary  

#### ⚙️ **Back-End**
13. [ ] **Paiements et Facturation**  
    - [ ] Intégration Stripe/PayPal  
    - 📌 **Technos** : Stripe API, PayPal SDK  
14. [ ] **Tableaux de Bord (Élève & Professeur)**  
    - [ ] Gestion des cours réservés  
    - [ ] Communication entre élèves et professeurs  
    - 📌 **Technos** : Laravel Livewire, WebSockets  
15. [ ] **Système de Notation et Commentaires**  
    - [ ] Notation avec étoiles et commentaires  
    - 📌 **Technos** : Chart.js, Laravel Nova  

#### 🗄 **Base de Données**
16. [ ] **Extension des Modèles de Données**  
    - [ ] Table `reviews` (id, professeur_id, élève_id, note, commentaire)  
    - [ ] Table `payments` (id, user_id, montant, statut, transaction_id)  
    - [ ] Table `messages` (communication élève/professeur)  

---

## 🔒 2. Sécurité et RGPD
17. [ ] Chiffrement des mots de passe (bcrypt ou Argon2)  
18. [ ] Sécurisation des paiements (SSL, 3D Secure)  
19. [ ] Protection contre XSS et injections SQL  
20. [ ] Gestion des rôles et permissions (ACL)  
21. [ ] Authentification renforcée (2FA, JWT)  

## 🏗 3. Infrastructure et Déploiement
22. [ ] **Configuration du Serveur**  
    - [ ] Installation et configuration de Debian, Nginx, PHP, MariaDB  
    - [ ] Sécurisation du serveur (firewall, fail2ban, HTTPS)  
23. [ ] **Automatisation du Déploiement**  
    - [ ] Intégration continue et déploiement via GitHub Actions  
    - [ ] Utilisation de Docker  
24. [ ] **Monitoring et Maintenance**
