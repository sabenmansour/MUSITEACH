<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';

// Traitement du formulaire
$formSubmitted = false;
$formSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
    // En production, on enverrait réellement l'email
    // Pour l'instant, on simule juste l'envoi
    $formSubmitted = true;
    $formSuccess = true;
    
    // En situation réelle, on ferait ceci :
    /*
    $name = sanitizeInput($_POST['name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $subject = sanitizeInput($_POST['subject'] ?? '');
    $message = sanitizeInput($_POST['message'] ?? '');
    
    // Validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $formSuccess = false;
    } elseif (!isValidEmail($email)) {
        $formSuccess = false;
    } else {
        // Envoi d'email
        $to = MAIL_FROM;
        $headers = "From: " . $email . "\r\n";
        $headers .= "Reply-To: " . $email . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        $mailContent = "<h2>Nouveau message de contact</h2>";
        $mailContent .= "<p><strong>Nom :</strong> " . $name . "</p>";
        $mailContent .= "<p><strong>Email :</strong> " . $email . "</p>";
        $mailContent .= "<p><strong>Sujet :</strong> " . $subject . "</p>";
        $mailContent .= "<p><strong>Message :</strong></p>";
        $mailContent .= "<p>" . nl2br($message) . "</p>";
        
        $formSuccess = mail($to, "Contact MusiTeach: " . $subject, $mailContent, $headers);
    }
    */
}

// Titre de la page
$pageTitle = "Contact";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<!-- Section principale -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="mb-4">Contactez-nous</h1>
            
            <?php if ($formSubmitted): ?>
                <?php if ($formSuccess): ?>
                    <div class="alert alert-success">
                        <h4 class="alert-heading">Message envoyé avec succès!</h4>
                        <p>Merci de nous avoir contactés. Notre équipe vous répondra dans les plus brefs délais.</p>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger">
                        <h4 class="alert-heading">Erreur lors de l'envoi du message</h4>
                        <p>Une erreur est survenue lors de l'envoi de votre message. Veuillez réessayer plus tard ou nous contacter directement par téléphone.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <div class="card mb-5">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <h2 class="h4 mb-3">Informations de contact</h2>
                            <p><i class="fas fa-map-marker-alt me-2 text-primary"></i> 123 Avenue de la Musique, 75001 Paris</p>
                            <p><i class="fas fa-phone me-2 text-primary"></i> +33 1 23 45 67 89</p>
                            <p><i class="fas fa-envelope me-2 text-primary"></i> contact@musicteach.com</p>
                            <p><i class="fas fa-clock me-2 text-primary"></i> Lun-Ven: 9h-18h</p>
                            
                            <h3 class="h5 mt-4 mb-3">Suivez-nous</h3>
                            <div class="d-flex">
                                <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-facebook-f"></i></a>
                                <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-twitter"></i></a>
                                <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-instagram"></i></a>
                                <a href="#" class="btn btn-outline-primary"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h2 class="h4 mb-3">Formulaire de contact</h2>
                            <form action="contact.php" method="post">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Nom complet</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="subject" class="form-label">Sujet</label>
                                    <select class="form-select" id="subject" name="subject" required>
                                        <option value="">Choisir un sujet</option>
                                        <option value="Question générale">Question générale</option>
                                        <option value="Support technique">Support technique</option>
                                        <option value="Devenir professeur">Devenir professeur</option>
                                        <option value="Partenariat">Partenariat</option>
                                        <option value="Autre">Autre</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="message" class="form-label">Message</label>
                                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                                </div>
                                <button type="submit" name="contact_submit" class="btn btn-primary">Envoyer le message</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h2 class="h4 mb-3">Localisation</h2>
                    <!-- En production, on aurait une vraie carte Google Maps -->
                    <div class="bg-light p-3 text-center rounded">
                        <p class="mb-0"><i class="fas fa-map-marked-alt fa-3x mb-3 text-primary"></i></p>
                        <p class="mb-0">Carte interactive non disponible en version démo.<br>Nous sommes situés au 123 Avenue de la Musique, 75001 Paris.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- FAQ Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5">Questions fréquentes</h2>
        
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item mb-3">
                        <h3 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Comment réserver un cours ?
                            </button>
                        </h3>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Pour réserver un cours, vous devez d'abord créer un compte élève. Ensuite, parcourez la liste des professeurs, consultez leurs profils et cliquez sur "Réserver un cours" sur la page du professeur qui vous intéresse. Choisissez une date et une heure disponibles, puis confirmez votre réservation.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item mb-3">
                        <h3 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Comment devenir professeur sur MusiTeach ?
                            </button>
                        </h3>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Pour devenir professeur, créez un compte en sélectionnant l'option "Professeur" lors de l'inscription. Complétez votre profil avec vos qualifications, votre expérience et les instruments que vous enseignez. Une fois votre profil validé, vous pourrez définir vos disponibilités et commencer à recevoir des réservations de cours.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item mb-3">
                        <h3 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Comment annuler ou reporter un cours ?
                            </button>
                        </h3>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Vous pouvez annuler ou reporter un cours depuis votre tableau de bord. Accédez à la section "Mes cours réservés" (pour les élèves) ou "Mes réservations" (pour les professeurs), puis cliquez sur le bouton "Annuler" à côté du cours concerné. Pour reporter un cours, annulez d'abord le cours actuel, puis effectuez une nouvelle réservation.
                            </div>
                        </div>
                    </div>
                    
                    <div class="accordion-item">
                        <h3 class="accordion-header" id="headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Comment contacter mon professeur ou mon élève ?
                            </button>
                        </h3>
                        <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Après une réservation de cours, vous pouvez communiquer avec votre professeur ou votre élève via la messagerie intégrée de MusiTeach. Accédez à votre tableau de bord, sélectionnez la réservation concernée, puis utilisez l'option "Envoyer un message". Dans la version actuelle, les coordonnées sont également partagées après confirmation d'une réservation.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>