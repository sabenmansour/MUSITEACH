# MusiTeach - Guide de déploiement Docker

Ce guide explique comment déployer l'application MusiTeach à l'aide de Docker et Docker Compose.

## Prérequis

- Docker et Docker Compose installés sur votre machine
- Git pour cloner le dépôt (optionnel)

## Déploiement de l'application

### Installation et démarrage rapide

1. Clonez ce dépôt ou téléchargez-le sous forme d'archive
2. Naviguez vers le dossier de l'application :
   ```bash
   cd MusiTeach
   ```
3. Utilisez le script de déploiement :
   ```bash
   ./deploy.sh
   ```
   Et choisissez l'option 1 pour faire une sauvegarde et déployer l'application

4. L'application sera accessible sur :
   - Interface web : [http://localhost:8000](http://localhost:8000)
   - PhpMyAdmin : [http://localhost:8080](http://localhost:8080) (utilisateur: root, mot de passe: root)

### Utilisation du script de déploiement

Le script `deploy.sh` offre plusieurs options :

1. **Sauvegarde et déploiement** : Crée une sauvegarde de l'application dans le dossier BACKUP, puis démarre les conteneurs Docker
2. **Sauvegarde uniquement** : Crée une sauvegarde sans modifier le déploiement actuel
3. **Déploiement uniquement** : Démarre ou redémarre les conteneurs sans créer de sauvegarde
4. **Arrêter les conteneurs** : Arrête les conteneurs en cours d'exécution
5. **Quitter** : Quitte le script

### Structure des conteneurs

- **webserver** : Serveur web Apache avec PHP 8.1
- **mysql** : Base de données MariaDB 10.6
- **phpmyadmin** : Interface d'administration de la base de données

### Sauvegardes

Les sauvegardes sont stockées dans le dossier `BACKUP` avec un horodatage. Pour restaurer une sauvegarde :

1. Arrêtez les conteneurs en cours d'exécution
2. Extrayez l'archive de sauvegarde dans un nouveau dossier
3. Déployez l'application depuis ce dossier

## Nouvelles fonctionnalités ajoutées

- **Mode sombre/clair** : Interface utilisateur adaptative avec possibilité de basculer entre les modes sombre et clair
- **Page FAQ** : Nouvelles sections FAQ organisées par catégories (général, élèves, professeurs, paiement)
- **Ressources pédagogiques** : Nouvelle section avec théorie musicale, exercices, blog musical et vidéos pédagogiques
- **Interface améliorée** : Design modernisé pour la page d'accueil, le tableau de bord, les profils de professeurs et le système de réservation
- **Menu de navigation enrichi** : Ajout d'un menu déroulant pour accéder facilement aux ressources

## Personnalisation

### Configuration de la base de données

Les paramètres de la base de données peuvent être modifiés dans le fichier `docker-compose.yml` :

```yaml
environment:
  MYSQL_ROOT_PASSWORD: root
  MYSQL_DATABASE: musicteach
  MYSQL_USER: musicteach
  MYSQL_PASSWORD: musicteach
```

### Ports

Par défaut, l'application utilise les ports suivants :
- Port 8000 : Interface web
- Port 8080 : PhpMyAdmin

Vous pouvez les modifier dans le fichier `docker-compose.yml` si nécessaire.

## Informations additionnelles

Pour plus d'informations sur l'application MusiTeach, consultez le fichier README.md principal.