<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';

// Vérifier si l'utilisateur est connecté
requireLogin();

// Récupérer l'utilisateur
$user = User::findById($_SESSION['user_id']);

// Traitement du formulaire si soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
        redirect('change_password.php');
    }
    
    // Récupérer les données du formulaire
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    // Validation
    $errors = [];
    
    if (empty($currentPassword)) {
        $errors[] = 'Le mot de passe actuel est requis.';
    } elseif (!verifyPassword($currentPassword, $user['password'])) {
        $errors[] = 'Le mot de passe actuel est incorrect.';
    }
    
    if (empty($newPassword)) {
        $errors[] = 'Le nouveau mot de passe est requis.';
    } elseif (strlen($newPassword) < 8) {
        $errors[] = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
    }
    
    if ($newPassword !== $confirmPassword) {
        $errors[] = 'Les nouveaux mots de passe ne correspondent pas.';
    }
    
    // S'il y a des erreurs, afficher un message d'erreur
    if (!empty($errors)) {
        setFlashMessage('error', implode(' ', $errors));
    } else {
        // Mettre à jour le mot de passe
        try {
            if (User::updatePassword($_SESSION['user_id'], $newPassword)) {
                setFlashMessage('success', 'Votre mot de passe a été modifié avec succès.');
                redirect('dashboard.php');
            } else {
                setFlashMessage('error', 'Une erreur est survenue lors de la modification de votre mot de passe.');
            }
        } catch (Exception $e) {
            setFlashMessage('error', 'Une erreur est survenue lors de la modification de votre mot de passe.');
        }
    }
}

// Titre de la page
$pageTitle = "Changer mon mot de passe";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h1 class="card-title h3 mb-4">Changer mon mot de passe</h1>
                    
                    <form action="change_password.php" method="post">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="change_password" value="1">
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Mot de passe actuel</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">Nouveau mot de passe</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <div class="form-text">Le mot de passe doit contenir au moins 8 caractères.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirmer le nouveau mot de passe</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="profile_edit.php" class="btn btn-secondary">Annuler</a>
                            <button type="submit" class="btn btn-primary">Changer le mot de passe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>