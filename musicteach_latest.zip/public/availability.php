<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';
require_once __DIR__ . '/../app/models/Availability.php';
require_once __DIR__ . '/../app/db_connect.php';

// Vérifier si l'utilisateur est connecté et est un professeur
requireLogin();
if (!isTeacher()) {
    setFlashMessage('error', 'Accès réservé aux professeurs.');
    redirect('dashboard.php');
}

// Vérifier si la table availability_slots existe
$db = getDbConnection();
$stmt = $db->prepare("SHOW TABLES LIKE 'availability_slots'");
$stmt->execute();
$tableExists = $stmt->fetchColumn();

// Si la table n'existe pas, créer la table à partir du script SQL
if (!$tableExists) {
    $sqlFile = __DIR__ . '/../database/instruments.sql';
    if (file_exists($sqlFile)) {
        $sql = file_get_contents($sqlFile);
        $db->exec($sql);
        
        // Vérifier à nouveau si la table a été créée
        $stmt = $db->prepare("SHOW TABLES LIKE 'availability_slots'");
        $stmt->execute();
        $tableExists = $stmt->fetchColumn();
    }
}

$teacherId = $_SESSION['user_id'];

// Récupérer les disponibilités actuelles du professeur
$availabilities = $tableExists ? Availability::findByTeacher($teacherId) : [];

// Traitement du formulaire d'ajout de disponibilité
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_availability'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Une erreur de sécurité est survenue. Veuillez réessayer.';
    } else {
        $dayOfWeek = isset($_POST['day_of_week']) && is_numeric($_POST['day_of_week']) && $_POST['day_of_week'] >= 0 && $_POST['day_of_week'] <= 6
            ? (int)$_POST['day_of_week']
            : null;
        
        $startTime = isset($_POST['start_time']) ? $_POST['start_time'] : null;
        $endTime = isset($_POST['end_time']) ? $_POST['end_time'] : null;
        $isRecurring = isset($_POST['is_recurring']) ? (bool)$_POST['is_recurring'] : true;
        $specificDate = isset($_POST['specific_date']) && !empty($_POST['specific_date']) ? $_POST['specific_date'] : null;
        
        if ($dayOfWeek === null) {
            $error = 'Veuillez sélectionner un jour de la semaine.';
        } elseif (empty($startTime)) {
            $error = 'Veuillez sélectionner une heure de début.';
        } elseif (empty($endTime)) {
            $error = 'Veuillez sélectionner une heure de fin.';
        } elseif ($startTime >= $endTime) {
            $error = 'L\'heure de début doit être antérieure à l\'heure de fin.';
        } elseif (!$isRecurring && empty($specificDate)) {
            $error = 'Veuillez sélectionner une date spécifique pour une disponibilité non récurrente.';
        } else {
            try {
                $result = Availability::create(
                    $teacherId,
                    $dayOfWeek,
                    $startTime,
                    $endTime,
                    $isRecurring,
                    !$isRecurring ? $specificDate : null
                );
                
                if ($result) {
                    $success = true;
                    setFlashMessage('success', 'La disponibilité a été ajoutée avec succès.');
                    redirect('availability.php');
                } else {
                    $error = 'Une erreur est survenue lors de l\'ajout de la disponibilité.';
                }
            } catch (Exception $e) {
                $error = 'Une erreur est survenue : ' . $e->getMessage();
            }
        }
    }
}

// Traitement de la suppression d'une disponibilité
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $slotId = (int)$_GET['id'];
    
    try {
        // Vérifier que la disponibilité appartient bien au professeur
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM availability_slots 
             WHERE id = :id AND teacher_id = :teacher_id"
        );
        $stmt->execute(['id' => $slotId, 'teacher_id' => $teacherId]);
        
        if ($stmt->fetchColumn() > 0) {
            $result = Availability::delete($slotId);
            if ($result) {
                setFlashMessage('success', 'La disponibilité a été supprimée avec succès.');
            } else {
                setFlashMessage('error', 'Une erreur est survenue lors de la suppression de la disponibilité.');
            }
        } else {
            setFlashMessage('error', 'Vous n\'avez pas le droit de supprimer cette disponibilité.');
        }
        
        redirect('availability.php');
    } catch (Exception $e) {
        setFlashMessage('error', 'Une erreur est survenue : ' . $e->getMessage());
        redirect('availability.php');
    }
}

// Titre de la page
$pageTitle = "Gérer mes disponibilités";

// Javascript pour la gestion du formulaire
$extraJs = <<<JS
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gestion du champ de date spécifique
    const isRecurringCheckbox = document.getElementById('is_recurring');
    const specificDateContainer = document.getElementById('specific_date_container');
    
    function toggleSpecificDate() {
        specificDateContainer.style.display = isRecurringCheckbox.checked ? 'none' : 'block';
    }
    
    isRecurringCheckbox.addEventListener('change', toggleSpecificDate);
    toggleSpecificDate();
    
    // Configuration du calendrier
    const currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();
    
    // Fonction pour afficher le calendrier
    function showCalendar(month, year) {
        // Mettre à jour le titre du mois
        const monthNames = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
                            "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
        document.getElementById("currentMonth").textContent = `\${monthNames[month]} \${year}`;
        
        // Premier jour du mois (0 = Dimanche, 1 = Lundi, ...)
        const firstDay = new Date(year, month, 1).getDay();
        // Nombre de jours dans le mois
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        // Ajuster pour commencer la semaine le lundi (transforme 0-6 en 1-7 où 1 = Lundi)
        const adjustedFirstDay = firstDay === 0 ? 6 : firstDay - 1;
        
        // Tableau des jours
        const calendarDays = document.getElementById("calendarDays");
        calendarDays.innerHTML = "";
        
        // Ajouter les noms des jours
        const dayNames = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
        for (let i = 0; i < 7; i++) {
            const dayHeader = document.createElement("div");
            dayHeader.className = "fw-bold";
            dayHeader.textContent = dayNames[i];
            calendarDays.appendChild(dayHeader);
        }
        
        // Ajouter des cases vides pour les jours avant le premier jour du mois
        for (let i = 0; i < adjustedFirstDay; i++) {
            const emptyDay = document.createElement("div");
            calendarDays.appendChild(emptyDay);
        }
        
        // Ajouter les jours du mois
        for (let i = 1; i <= daysInMonth; i++) {
            const day = document.createElement("div");
            day.className = "calendar-day";
            day.textContent = i;
            
            // Ne pas permettre la sélection des dates passées
            const dayDate = new Date(year, month, i);
            if (dayDate < new Date().setHours(0, 0, 0, 0)) {
                day.classList.add("disabled");
            } else {
                day.addEventListener("click", function() {
                    this.classList.toggle("selected");
                    updateSelectedDates();
                });
            }
            
            calendarDays.appendChild(day);
        }
    }
    
    // Navigation dans le calendrier
    if (document.getElementById("prevMonth")) {
        document.getElementById("prevMonth").addEventListener("click", function() {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            showCalendar(currentMonth, currentYear);
        });
    }
    
    if (document.getElementById("nextMonth")) {
        document.getElementById("nextMonth").addEventListener("click", function() {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            showCalendar(currentMonth, currentYear);
        });
    }
    
    // Afficher le mois actuel si le calendrier existe
    if (document.getElementById("calendarDays")) {
        showCalendar(currentMonth, currentYear);
    }
});
</script>
JS;

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Gérer mes disponibilités</h1>
    
    <?php if (!$tableExists): ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle me-2"></i>
            La fonctionnalité de gestion des disponibilités n'est pas disponible actuellement. Veuillez contacter l'administrateur.
        </div>
    <?php else: ?>
        <div class="row">
            <!-- Disponibilités actuelles -->
            <div class="col-lg-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Mes disponibilités</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($availabilities)): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Vous n'avez pas encore défini de disponibilités. Ajoutez-en à l'aide du formulaire ci-contre.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Jour</th>
                                            <th>Horaire</th>
                                            <th>Type</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $dayNames = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
                                        
                                        foreach ($availabilities as $slot): 
                                            $dayName = $dayNames[$slot['day_of_week']];
                                            $startTime = date('H:i', strtotime($slot['start_time']));
                                            $endTime = date('H:i', strtotime($slot['end_time']));
                                            $isRecurring = (bool)$slot['is_recurring'];
                                            $specificDate = $slot['specific_date'] ? date('d/m/Y', strtotime($slot['specific_date'])) : null;
                                        ?>
                                            <tr>
                                                <td>
                                                    <?= $dayName ?>
                                                    <?php if (!$isRecurring && $specificDate): ?>
                                                        <br><small class="text-muted"><?= $specificDate ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= $startTime ?> - <?= $endTime ?></td>
                                                <td>
                                                    <?php if ($isRecurring): ?>
                                                        <span class="badge bg-primary">Récurrent</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-info">Ponctuel</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="edit_availability.php?id=<?= $slot['id'] ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="availability.php?action=delete&id=<?= $slot['id'] ?>" 
                                                       class="btn btn-sm btn-danger"
                                                       onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette disponibilité ?');">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Calendrier des disponibilités -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Calendrier des disponibilités</h5>
                    </div>
                    <div class="card-body">
                        <div class="calendar">
                            <div class="calendar-header d-flex justify-content-between align-items-center mb-4">
                                <button id="prevMonth" class="btn btn-outline-secondary">
                                    <i class="fas fa-chevron-left"></i> Mois précédent
                                </button>
                                <h5 id="currentMonth" class="mb-0">Avril 2025</h5>
                                <button id="nextMonth" class="btn btn-outline-secondary">
                                    Mois suivant <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                            
                            <div id="calendarDays" class="calendar-days">
                                <!-- Les jours du calendrier seront injectés ici par JavaScript -->
                            </div>
                            
                            <div class="mt-4">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="calendar-day-example"></div>
                                    <span class="ms-2">Jour disponible</span>
                                </div>
                                <div class="d-flex align-items-center mb-2">
                                    <div class="calendar-day-example selected"></div>
                                    <span class="ms-2">Jour sélectionné</span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="calendar-day-example disabled"></div>
                                    <span class="ms-2">Jour passé (non disponible)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Ajouter une disponibilité -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ajouter une disponibilité</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger mb-3">
                                <i class="fas fa-exclamation-circle me-2"></i>
                                <?= $error ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success mb-3">
                                <i class="fas fa-check-circle me-2"></i>
                                La disponibilité a été ajoutée avec succès.
                            </div>
                        <?php endif; ?>
                        
                        <form action="availability.php" method="post">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <input type="hidden" name="add_availability" value="1">
                            
                            <div class="mb-3">
                                <label for="day_of_week" class="form-label">Jour de la semaine</label>
                                <select class="form-select" id="day_of_week" name="day_of_week" required>
                                    <option value="">Sélectionner un jour</option>
                                    <option value="1">Lundi</option>
                                    <option value="2">Mardi</option>
                                    <option value="3">Mercredi</option>
                                    <option value="4">Jeudi</option>
                                    <option value="5">Vendredi</option>
                                    <option value="6">Samedi</option>
                                    <option value="0">Dimanche</option>
                                </select>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <label for="start_time" class="form-label">Heure de début</label>
                                    <input type="time" class="form-control" id="start_time" name="start_time" required>
                                </div>
                                <div class="col-6">
                                    <label for="end_time" class="form-label">Heure de fin</label>
                                    <input type="time" class="form-control" id="end_time" name="end_time" required>
                                </div>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="is_recurring" name="is_recurring" value="1" checked>
                                <label class="form-check-label" for="is_recurring">Disponibilité récurrente</label>
                                <div class="form-text">
                                    Si activé, cette disponibilité s'appliquera chaque semaine au jour sélectionné.
                                </div>
                            </div>
                            
                            <div class="mb-3" id="specific_date_container" style="display: none;">
                                <label for="specific_date" class="form-label">Date spécifique</label>
                                <input type="date" class="form-control" id="specific_date" name="specific_date" 
                                       min="<?= date('Y-m-d') ?>">
                                <div class="form-text">
                                    Pour une disponibilité ponctuelle, sélectionnez une date spécifique.
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Ajouter cette disponibilité</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Conseils</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary me-2"></i>
                                Définissez vos disponibilités régulières en utilisant l'option "récurrente".
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary me-2"></i>
                                Pour des disponibilités exceptionnelles, désactivez l'option "récurrente" et choisissez une date spécifique.
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary me-2"></i>
                                Vous pouvez ajouter plusieurs plages horaires pour un même jour.
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary me-2"></i>
                                Les élèves ne pourront réserver que sur les plages horaires que vous avez définies.
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="mt-4">
        <a href="teacher_bookings.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i>Retour à mes réservations
        </a>
    </div>
</div>

<style>
.calendar-days {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 5px;
    margin-bottom: 20px;
}

.calendar-day, .calendar-day-example {
    padding: 10px;
    text-align: center;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
}

.calendar-day-example {
    width: 40px;
    height: 40px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: default;
}

.calendar-day:hover:not(.disabled) {
    background-color: #f8f9fa;
    border-color: #dee2e6;
}

.calendar-day.selected, .calendar-day-example.selected {
    background-color: #0d6efd;
    color: white;
    border-color: #0d6efd;
}

.calendar-day.disabled, .calendar-day-example.disabled {
    background-color: #f8f9fa;
    color: #adb5bd;
    cursor: not-allowed;
}

.fw-bold {
    text-align: center;
    margin-bottom: 10px;
}
</style>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>