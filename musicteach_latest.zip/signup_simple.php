<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fonction simple de redirection
function redirect($url) {
    header("Location: $url");
    exit;
}

// Fonction simple pour générer un token CSRF
function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Démarrer une session
session_start();

// Titre de la page
$pageTitle = "Inscription";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="card-title text-center mb-4">Créer un compte</h1>
                
                <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?= $_SESSION['flash_message']['type'] ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['flash_message']['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['flash_message']); ?>
                <?php endif; ?>
                
                <form action="process_signup.php" method="post">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Nom complet</label>
                        <input type="text" class="form-control" id="name" name="name" required 
                               value="<?= isset($_SESSION['form_data']['name']) ? htmlspecialchars($_SESSION['form_data']['name']) : '' ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Adresse email</label>
                        <input type="email" class="form-control" id="email" name="email" required
                               value="<?= isset($_SESSION['form_data']['email']) ? htmlspecialchars($_SESSION['form_data']['email']) : '' ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Mot de passe</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="form-text">Le mot de passe doit contenir au moins 8 caractères.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password_confirm" class="form-label">Confirmer le mot de passe</label>
                        <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label">Je souhaite m'inscrire en tant que :</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="role" id="role_student" value="student" 
                                   <?= (!isset($_SESSION['form_data']['role']) || $_SESSION['form_data']['role'] === 'student') ? 'checked' : '' ?>>
                            <label class="form-check-label" for="role_student">
                                Élève - Je cherche un professeur de musique
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="role" id="role_teacher" value="teacher"
                                   <?= (isset($_SESSION['form_data']['role']) && $_SESSION['form_data']['role'] === 'teacher') ? 'checked' : '' ?>>
                            <label class="form-check-label" for="role_teacher">
                                Professeur - Je souhaite donner des cours
                            </label>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">S'inscrire</button>
                    </div>
                </form>
                
                <div class="text-center mt-3">
                    <p>Vous avez déjà un compte ? <a href="login.php">Connectez-vous</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Nettoyer les données de formulaire stockées en session
if (isset($_SESSION['form_data'])) {
    unset($_SESSION['form_data']);
}

// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>