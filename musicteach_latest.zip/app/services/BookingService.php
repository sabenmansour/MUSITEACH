<?php
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../utils.php';

/**
 * Service de gestion des réservations
 */
class BookingService {
    /**
     * Crée une nouvelle réservation
     * 
     * @param int $teacherId ID du professeur
     * @param int $studentId ID de l'élève
     * @param string $date Date et heure au format Y-m-d H:i:s
     * @param string $message Message optionnel
     * @return int|false ID de la réservation créée ou false en cas d'erreur
     */
    public static function createBooking($teacherId, $studentId, $date, $message = null) {
        // Vérifier si le professeur existe et est bien un professeur
        $teacher = User::findById($teacherId);
        if (!$teacher || $teacher['role'] !== 'teacher') {
            return false;
        }
        
        // Vérifier si l'élève existe et est bien un élève
        $student = User::findById($studentId);
        if (!$student || $student['role'] !== 'student') {
            return false;
        }
        
        // Vérifier si le professeur est disponible à cette date
        if (!Booking::isTeacherAvailable($teacherId, $date)) {
            return false;
        }
        
        // Créer la réservation
        return Booking::create($teacherId, $studentId, $date, 'pending');
    }
    
    /**
     * Confirme une réservation
     * 
     * @param int $bookingId ID de la réservation
     * @param int $userId ID de l'utilisateur qui effectue l'action
     * @return bool Succès de l'opération
     */
    public static function confirmBooking($bookingId, $userId) {
        // Récupérer la réservation
        $booking = Booking::findById($bookingId);
        if (!$booking) {
            return false;
        }
        
        // Vérifier si l'utilisateur a le droit de confirmer la réservation
        if ($booking['teacher_id'] !== $userId && !self::isUserAdmin($userId)) {
            return false;
        }
        
        // Vérifier si la réservation est en attente
        if ($booking['status'] !== 'pending') {
            return false;
        }
        
        // Confirmer la réservation
        return Booking::update($bookingId, ['status' => 'confirmed']);
    }
    
    /**
     * Annule une réservation
     * 
     * @param int $bookingId ID de la réservation
     * @param int $userId ID de l'utilisateur qui effectue l'action
     * @return bool Succès de l'opération
     */
    public static function cancelBooking($bookingId, $userId) {
        // Récupérer la réservation
        $booking = Booking::findById($bookingId);
        if (!$booking) {
            return false;
        }
        
        // Vérifier si l'utilisateur a le droit d'annuler la réservation
        $isTeacher = $booking['teacher_id'] === $userId;
        $isStudent = $booking['student_id'] === $userId;
        $isAdmin = self::isUserAdmin($userId);
        
        if (!$isTeacher && !$isStudent && !$isAdmin) {
            return false;
        }
        
        // Vérifier si la réservation est déjà annulée
        if ($booking['status'] === 'canceled') {
            return false;
        }
        
        // Vérifier la date de la réservation (24h avant la date prévue)
        $bookingDate = new DateTime($booking['date']);
        $now = new DateTime();
        $interval = $now->diff($bookingDate);
        $hoursUntilClass = ($interval->days * 24) + $interval->h;
        
        // Si moins de 24h avant le cours et ce n'est pas un admin qui annule
        if ($bookingDate > $now && $hoursUntilClass < 24 && !$isAdmin) {
            return false;
        }
        
        // Annuler la réservation
        return Booking::update($bookingId, ['status' => 'canceled']);
    }
    
    /**
     * Vérifie si un utilisateur est administrateur
     * 
     * @param int $userId ID de l'utilisateur
     * @return bool True si l'utilisateur est admin, false sinon
     */
    private static function isUserAdmin($userId) {
        $user = User::findById($userId);
        return $user && $user['role'] === 'admin';
    }
    
    /**
     * Récupère les prochaines réservations d'un élève
     * 
     * @param int $studentId ID de l'élève
     * @param int $limit Nombre maximum de réservations à récupérer
     * @return array Liste des réservations
     */
    public static function getUpcomingStudentBookings($studentId, $limit = 5) {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "SELECT b.*, u.name as teacher_name, u.email as teacher_email
             FROM bookings b
             JOIN users u ON b.teacher_id = u.id
             WHERE b.student_id = :student_id
             AND b.date > NOW()
             AND b.status = 'confirmed'
             ORDER BY b.date ASC
             LIMIT :limit"
        );
        
        $stmt->bindValue(':student_id', $studentId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Récupère les prochaines réservations d'un professeur
     * 
     * @param int $teacherId ID du professeur
     * @param int $limit Nombre maximum de réservations à récupérer
     * @return array Liste des réservations
     */
    public static function getUpcomingTeacherBookings($teacherId, $limit = 5) {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "SELECT b.*, u.name as student_name, u.email as student_email
             FROM bookings b
             JOIN users u ON b.student_id = u.id
             WHERE b.teacher_id = :teacher_id
             AND b.date > NOW()
             AND b.status = 'confirmed'
             ORDER BY b.date ASC
             LIMIT :limit"
        );
        
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
}