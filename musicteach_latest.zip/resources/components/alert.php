<?php
/**
 * Composant d'alerte
 * 
 * @param string $type Type d'alerte (success, danger, warning, info)
 * @param string $message Message à afficher
 * @param bool $dismissible Si l'alerte peut être fermée
 * @param bool $icon Afficher une icône
 * @return string Le HTML de l'alerte
 */
function renderAlert($type, $message, $dismissible = true, $icon = true) {
    $alertClass = 'alert alert-' . $type;
    if ($dismissible) {
        $alertClass .= ' alert-dismissible fade show';
    }

    $iconHtml = '';
    if ($icon) {
        switch ($type) {
            case 'success':
                $iconHtml = '<i class="fas fa-check-circle me-2"></i>';
                break;
            case 'danger':
                $iconHtml = '<i class="fas fa-exclamation-circle me-2"></i>';
                break;
            case 'warning':
                $iconHtml = '<i class="fas fa-exclamation-triangle me-2"></i>';
                break;
            case 'info':
                $iconHtml = '<i class="fas fa-info-circle me-2"></i>';
                break;
        }
    }

    $closeButton = $dismissible ? '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' : '';

    return <<<HTML
    <div class="{$alertClass}" role="alert">
        {$iconHtml}{$message}
        {$closeButton}
    </div>
HTML;
}