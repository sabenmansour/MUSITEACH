<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';

// Titre de la page
$pageTitle = "À propos";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<!-- Section principale -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="mb-4">À propos de MusiTeach</h1>
            
            <div class="card mb-5">
                <div class="card-body">
                    <h2 class="h4 mb-3">Notre mission</h2>
                    <p>MusiTeach est né d'une passion pour la musique et l'éducation. Notre mission est de connecter les professeurs de musique qualifiés avec des élèves motivés, facilitant ainsi l'accès à un enseignement musical de qualité pour tous.</p>
                    
                    <p>Nous croyons que l'apprentissage de la musique devrait être accessible, flexible et adapté aux besoins de chacun. C'est pourquoi nous avons créé une plateforme qui simplifie la recherche, la réservation et la gestion des cours de musique.</p>
                </div>
            </div>
            
            <div class="card mb-5">
                <div class="card-body">
                    <h2 class="h4 mb-3">Notre histoire</h2>
                    <p>Fondée en 2025, MusiTeach est le fruit de la collaboration entre des musiciens passionnés et des experts en technologie. Face aux difficultés rencontrées par de nombreux professeurs pour trouver des élèves et par les élèves pour trouver le bon professeur, nous avons décidé de créer une solution innovante.</p>
                    
                    <p>Après des mois de développement et de tests avec des professeurs et des élèves, nous avons lancé la plateforme MusiTeach avec l'ambition de révolutionner l'enseignement musical.</p>
                </div>
            </div>
            
            <div class="card mb-5">
                <div class="card-body">
                    <h2 class="h4 mb-3">Notre équipe</h2>
                    <p>Derrière MusiTeach se cache une équipe passionnée de musiciens, d'éducateurs et de développeurs. Chaque membre apporte son expertise unique pour créer une plateforme qui répond aux besoins réels des professeurs et des élèves.</p>
                    
                    <div class="row mt-4">
                        <div class="col-md-4 text-center mb-4">
                            <img src="/resources/img/team-1.jpg" alt="Thomas Durand" class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <h3 class="h5">Thomas Durand</h3>
                            <p class="text-muted">Fondateur & Directeur</p>
                        </div>
                        <div class="col-md-4 text-center mb-4">
                            <img src="/resources/img/team-2.jpg" alt="Sophie Martin" class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <h3 class="h5">Sophie Martin</h3>
                            <p class="text-muted">Directrice Pédagogique</p>
                        </div>
                        <div class="col-md-4 text-center mb-4">
                            <img src="/resources/img/team-3.jpg" alt="Lucas Petit" class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <h3 class="h5">Lucas Petit</h3>
                            <p class="text-muted">Développeur en Chef</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h2 class="h4 mb-3">Nos valeurs</h2>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-star text-primary fa-2x me-3"></i>
                                </div>
                                <div>
                                    <h3 class="h5">Excellence</h3>
                                    <p>Nous nous engageons à offrir un service de la plus haute qualité à tous nos utilisateurs.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-handshake text-primary fa-2x me-3"></i>
                                </div>
                                <div>
                                    <h3 class="h5">Confiance</h3>
                                    <p>Nous construisons des relations durables basées sur la transparence et l'honnêteté.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-users text-primary fa-2x me-3"></i>
                                </div>
                                <div>
                                    <h3 class="h5">Communauté</h3>
                                    <p>Nous favorisons un environnement d'apprentissage collaboratif et bienveillant.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-lightbulb text-primary fa-2x me-3"></i>
                                </div>
                                <div>
                                    <h3 class="h5">Innovation</h3>
                                    <p>Nous cherchons constamment à améliorer notre plateforme et à intégrer de nouvelles technologies.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Call to Action -->
<section class="cta text-center py-5">
    <div class="container py-4">
        <h2 class="mb-4">Rejoignez l'aventure MusiTeach</h2>
        <p class="mb-4">Que vous soyez professeur ou élève, devenez membre de notre communauté grandissante.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="signup.php" class="btn btn-light btn-lg">S'inscrire gratuitement</a>
            <a href="contact.php" class="btn btn-outline-light btn-lg">Nous contacter</a>
        </div>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>