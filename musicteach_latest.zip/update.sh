#\!/bin/bash

# Définition des couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== MusiTeach Update Tool ===${NC}"

# Fonction pour pull les dernières modifications
pull_changes() {
    echo -e "${YELLOW}Pulling latest changes...${NC}"
    if [ -d ".git" ]; then
        git pull
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}Successfully pulled latest changes${NC}"
        else
            echo -e "${RED}Failed to pull changes${NC}"
            return 1
        fi
    else
        echo -e "${RED}Not a git repository. Please update files manually.${NC}"
        return 1
    fi
}

# Fonction pour redémarrer les containers
restart_containers() {
    echo -e "${YELLOW}Restarting containers...${NC}"
    ./restart.sh
}

# Fonction pour créer une sauvegarde
create_backup() {
    BACKUP_DIR="./BACKUP"
    TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
    BACKUP_FILE="${BACKUP_DIR}/musicteach_backup_${TIMESTAMP}.tar.gz"
    
    echo -e "${YELLOW}Creating backup...${NC}"
    mkdir -p "$BACKUP_DIR"
    
    tar -czf "${BACKUP_FILE}" --exclude="BACKUP" --exclude="node_modules" --exclude=".git" .
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Backup created: ${BACKUP_FILE}${NC}"
    else
        echo -e "${RED}Failed to create backup${NC}"
        return 1
    fi
}

# Menu principal
echo
echo -e "${BLUE}Select an option:${NC}"
echo "1) Create backup and update (recommended)"
echo "2) Just update without backup"
echo "3) Exit"
echo
read -p "Enter your choice [1-3]: " choice

case $choice in
    1)
        create_backup && restart_containers
        ;;
    2)
        restart_containers
        ;;
    3)
        echo -e "${GREEN}Exiting...${NC}"
        exit 0
        ;;
    *)
        echo -e "${RED}Invalid choice.${NC}"
        ;;
esac

echo -e "${GREEN}Update process completed\!${NC}"
