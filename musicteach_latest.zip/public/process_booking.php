<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Booking.php';

// Vérifier si l'utilisateur est connecté
requireLogin();

// Vérifier si l'utilisateur est un étudiant
if (!isStudent()) {
    setFlashMessage('error', 'Seuls les élèves peuvent réserver des cours.');
    redirect('index.php');
}

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('teachers.php');
}

// Vérifier le token CSRF
if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
    setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
    redirect('teachers.php');
}

// Récupérer et nettoyer les données du formulaire
$teacherId = isset($_POST['teacher_id']) ? (int)$_POST['teacher_id'] : 0;
$bookingDate = sanitizeInput($_POST['booking_date'] ?? '');
$bookingTime = sanitizeInput($_POST['booking_time'] ?? '');
$message = sanitizeInput($_POST['message'] ?? '');

// Vérifier si le professeur existe
$teacher = User::findById($teacherId);
if (!$teacher || $teacher['role'] !== 'teacher') {
    setFlashMessage('error', 'Professeur non trouvé.');
    redirect('teachers.php');
}

// Valider la date et l'heure
if (empty($bookingDate) || empty($bookingTime)) {
    setFlashMessage('error', 'Veuillez sélectionner une date et une heure pour votre cours.');
    redirect('booking.php?teacher_id=' . $teacherId);
}

// Combiner la date et l'heure
$bookingDateTime = $bookingDate . ' ' . $bookingTime . ':00';

// Vérifier si le professeur est disponible à cette date/heure
if (!Booking::isTeacherAvailable($teacherId, $bookingDateTime)) {
    setFlashMessage('error', 'Le professeur n\'est pas disponible à cette date et heure. Veuillez choisir un autre créneau.');
    redirect('booking.php?teacher_id=' . $teacherId);
}

// Créer la réservation
try {
    $bookingId = Booking::create($teacherId, $_SESSION['user_id'], $bookingDateTime);
    
    // Définir un message de succès
    setFlashMessage('success', 'Votre cours a été réservé avec succès !');
    
    // Rediriger vers la page de détails de la réservation ou le tableau de bord
    redirect('student_bookings.php');
} catch (Exception $e) {
    setFlashMessage('error', 'Une erreur est survenue lors de la réservation du cours. Veuillez réessayer.');
    redirect('booking.php?teacher_id=' . $teacherId);
}