<?php
require_once __DIR__ . '/../db_connect.php';

class Profile {
    /**
     * Récupérer un profil par l'ID utilisateur
     */
    public static function findByUserId($userId) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM profiles WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetch();
    }
    
    /**
     * Créer un nouveau profil
     */
    public static function create($userId, $type, $description = null, $instrument = null, $experience = null) {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "INSERT INTO profiles (user_id, type, description, instrument, experience, created_at, updated_at) 
             VALUES (:user_id, :type, :description, :instrument, :experience, NOW(), NOW())"
        );
        
        $stmt->execute([
            'user_id' => $userId,
            'type' => $type,
            'description' => $description,
            'instrument' => $instrument,
            'experience' => $experience
        ]);
        
        return $db->lastInsertId();
    }
    
    /**
     * Mettre à jour un profil
     */
    public static function update($userId, $data) {
        $db = getDbConnection();
        
        $allowedFields = ['type', 'description', 'instrument', 'experience'];
        $fields = [];
        $params = ['user_id' => $userId];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $fields[] = "$key = :$key";
                $params[$key] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $sql = "UPDATE profiles SET " . implode(', ', $fields) . " WHERE user_id = :user_id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }
    
    /**
     * Supprimer un profil
     */
    public static function delete($userId) {
        $db = getDbConnection();
        $stmt = $db->prepare("DELETE FROM profiles WHERE user_id = :user_id");
        return $stmt->execute(['user_id' => $userId]);
    }
    
    /**
     * Créer ou mettre à jour un profil (upsert)
     */
    public static function createOrUpdate($userId, $data) {
        $profile = self::findByUserId($userId);
        
        if ($profile) {
            return self::update($userId, $data);
        } else {
            $type = $data['type'] ?? 'student';
            $description = $data['description'] ?? null;
            $instrument = $data['instrument'] ?? null;
            $experience = $data['experience'] ?? null;
            
            return self::create($userId, $type, $description, $instrument, $experience);
        }
    }
}