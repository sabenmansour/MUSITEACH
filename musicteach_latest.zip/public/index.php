<?php
// Afficher les erreurs directement
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session et inclure les dépendances avant d'envoyer des en-têtes HTTP
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/db_connect.php';

// Titre de la page
$pageTitle = "Accueil";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <div class="alert alert-success">
                <h4><i class="fas fa-check-circle"></i> MusiTeach est en ligne!</h4>
                <p>Le site fonctionne correctement. Vous pouvez maintenant profiter de toutes les fonctionnalités.</p>
            </div>
        </div>
    </div>
</div>

<!-- Hero Section -->
<section class="hero">
    <div class="container text-center">
        <div data-aos="fade-up" data-aos-delay="100">
            <h1 class="display-4 fw-bold">Trouvez le prof de musique parfait en quelques clics</h1>
            <p class="mx-auto lead">Cours particuliers avec des professeurs qualifiés, en présentiel ou en ligne, pour tous niveaux et tous instruments.</p>
            <div class="mt-5">
                <a href="teachers.php" class="btn btn-primary btn-lg me-3">Découvrir les professeurs</a>
                <a href="signup.php" class="btn btn-outline-light btn-lg">Inscription gratuite</a>
            </div>
        </div>
    </div>
</section>

<!-- Comment ça marche -->
<section class="how-it-works my-5">
    <div class="container">
        <h2 class="text-center mb-5" data-aos="fade-up">Comment ça marche ?</h2>
        <div class="row">
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3>Recherchez</h3>
                    <p>Trouvez facilement le professeur de musique idéal parmi nos nombreux profils vérifiés.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <h3>Réservez</h3>
                    <p>Choisissez une date et un horaire qui vous conviennent et réservez votre cours en quelques clics.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-music"></i>
                    </div>
                    <h3>Apprenez</h3>
                    <p>Profitez de cours de qualité et progressez à votre rythme avec un suivi personnalisé.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include_once __DIR__ . '/../resources/views/footer.php'; ?>

<!-- Comment ça marche -->
<section class="how-it-works my-5">
    <div class="container">
        <h2 class="text-center mb-5" data-aos="fade-up">Comment ça marche ?</h2>
        <div class="row">
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3>Recherchez</h3>
                    <p>Trouvez facilement le professeur de musique idéal parmi nos nombreux profils vérifiés.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <h3>Réservez</h3>
                    <p>Choisissez une date et un horaire qui vous conviennent et réservez votre cours en quelques clics.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-music"></i>
                    </div>
                    <h3>Apprenez</h3>
                    <p>Profitez de cours de qualité et progressez à votre rythme avec un suivi personnalisé.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Pourquoi choisir MusiTeach -->
<section class="bg-light py-5">
    <div class="container">
        <h2 class="text-center mb-5" data-aos="fade-up">Pourquoi choisir MusiTeach ?</h2>
        
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-right">
                <img src="/resources/img/teacher-placeholder.jpg" alt="Professeurs qualifiés" class="img-fluid rounded-4 shadow-lg">
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <h3 class="mb-4">Des professeurs qualifiés et passionnés</h3>
                <p>Tous nos professeurs sont rigoureusement sélectionnés pour leur expertise, leur pédagogie et leur passion pour l'enseignement musical.</p>
                <ul class="list-unstyled mb-0">
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Formés dans les meilleures écoles</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Expérience pédagogique prouvée</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Adaptés à tous les niveaux et âges</li>
                    <li><i class="fas fa-check-circle text-success me-2"></i> Profils vérifiés et évalués</li>
                </ul>
            </div>
        </div>
        
        <div class="row align-items-center flex-row-reverse">
            <div class="col-lg-6 mb-4 mb-lg-0" data-aos="fade-left">
                <img src="/resources/img/hero-bg.jpg" alt="Flexibilité maximale" class="img-fluid rounded-4 shadow-lg">
            </div>
            <div class="col-lg-6" data-aos="fade-right">
                <h3 class="mb-4">Une flexibilité maximale</h3>
                <p>MusiTeach s'adapte à votre emploi du temps et à vos préférences pour vous offrir une expérience d'apprentissage sans contraintes.</p>
                <ul class="list-unstyled mb-0">
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Cours en présentiel ou en ligne</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Réservation simple et intuitive</li>
                    <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Horaires adaptés à vos disponibilités</li>
                    <li><i class="fas fa-check-circle text-success me-2"></i> Annulation gratuite jusqu'à 24h avant</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Statistiques -->
<section class="stats-section py-5">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3 col-6 mb-4 mb-md-0" data-aos="zoom-in" data-aos-delay="100">
                <div class="dashboard-stats">
                    <h3><span class="stat-value" data-target="450">0</span>+</h3>
                    <p>Professeurs</p>
                </div>
            </div>
            <div class="col-md-3 col-6 mb-4 mb-md-0" data-aos="zoom-in" data-aos-delay="200">
                <div class="dashboard-stats">
                    <h3><span class="stat-value" data-target="10000">0</span>+</h3>
                    <p>Élèves satisfaits</p>
                </div>
            </div>
            <div class="col-md-3 col-6" data-aos="zoom-in" data-aos-delay="300">
                <div class="dashboard-stats">
                    <h3><span class="stat-value" data-target="35000">0</span>+</h3>
                    <p>Cours donnés</p>
                </div>
            </div>
            <div class="col-md-3 col-6" data-aos="zoom-in" data-aos-delay="400">
                <div class="dashboard-stats">
                    <h3><span class="stat-value" data-target="25">0</span></h3>
                    <p>Instruments enseignés</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Témoignages -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center mb-5" data-aos="fade-up">Ce que disent nos élèves</h2>
        
        <div class="row">
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="card-text">« J'ai commencé le piano à 35 ans sans aucune base, grâce à MusiTeach j'ai trouvé un professeur patient et pédagogue qui m'a permis de progresser rapidement. »</p>
                    </div>
                    <div class="card-footer border-0 bg-transparent">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <img src="/resources/img/user-placeholder.jpg" alt="Sophie L." class="rounded-circle" width="50" height="50">
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-0">Sophie L.</h6>
                                <small class="text-muted">Élève en piano, Paris</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="card-text">« Ma fille a découvert le violon grâce à MusiTeach. La réservation est simple et nous avons pu facilement trouver un professeur proche de chez nous avec des horaires adaptés. »</p>
                    </div>
                    <div class="card-footer border-0 bg-transparent">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <img src="/resources/img/user-placeholder.jpg" alt="Thomas D." class="rounded-circle" width="50" height="50">
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-0">Thomas D.</h6>
                                <small class="text-muted">Parent d'élève, Lyon</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star-half-alt text-warning"></i>
                        </div>
                        <p class="card-text">« En tant que professeur sur MusiTeach, j'apprécie la flexibilité et la simplicité pour gérer mon planning. La plateforme me permet de me concentrer sur l'enseignement. »</p>
                    </div>
                    <div class="card-footer border-0 bg-transparent">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <img src="/resources/img/teacher-placeholder.jpg" alt="Marc B." class="rounded-circle" width="50" height="50">
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-0">Marc B.</h6>
                                <small class="text-muted">Professeur de guitare, Bordeaux</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4" data-aos="fade-up">
            <a href="teachers.php" class="btn btn-primary">Découvrir nos professeurs</a>
        </div>
    </div>
</section>

<!-- Newsletter -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center" data-aos="fade-up">
                <h3>Restez informé de nos actualités</h3>
                <p class="mb-4">Inscrivez-vous à notre newsletter pour recevoir nos conseils, actualités et offres exclusives</p>
                <form class="row g-3 justify-content-center">
                    <div class="col-md-8">
                        <input type="email" class="form-control form-control-lg" placeholder="Votre adresse email" required>
                    </div>
                    <div class="col-md-auto">
                        <button type="submit" class="btn btn-primary btn-lg w-100">S'inscrire</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>