<?php
require_once __DIR__ . '/../db_connect.php';

/**
 * Modèle pour la gestion des instruments des professeurs
 */
class TeacherInstrument {
    /**
     * Associer un instrument à un professeur
     * 
     * @param int $teacherId ID du professeur
     * @param int $instrumentId ID de l'instrument
     * @param string $level Niveau d'enseignement (débutant, intermédiaire, avancé)
     * @param string $description Description optionnelle
     * @return int|false ID de l'association créée ou false en cas d'erreur
     */
    public static function create($teacherId, $instrumentId, $level = 'all', $description = null) {
        $db = getDbConnection();
        
        // Vérifier si l'association existe déjà
        $stmt = $db->prepare(
            "SELECT id FROM teacher_instruments 
             WHERE teacher_id = :teacher_id AND instrument_id = :instrument_id"
        );
        $stmt->execute(['teacher_id' => $teacherId, 'instrument_id' => $instrumentId]);
        
        if ($stmt->fetch()) {
            // L'association existe déjà, on la met à jour
            $stmt = $db->prepare(
                "UPDATE teacher_instruments 
                 SET level = :level, description = :description, updated_at = NOW()
                 WHERE teacher_id = :teacher_id AND instrument_id = :instrument_id"
            );
            
            $stmt->execute([
                'teacher_id' => $teacherId,
                'instrument_id' => $instrumentId,
                'level' => $level,
                'description' => $description
            ]);
            
            return true;
        } else {
            // Nouvelle association
            $stmt = $db->prepare(
                "INSERT INTO teacher_instruments (teacher_id, instrument_id, level, description, created_at, updated_at)
                 VALUES (:teacher_id, :instrument_id, :level, :description, NOW(), NOW())"
            );
            
            $stmt->execute([
                'teacher_id' => $teacherId,
                'instrument_id' => $instrumentId,
                'level' => $level,
                'description' => $description
            ]);
            
            return $db->lastInsertId();
        }
    }
    
    /**
     * Supprimer l'association entre un professeur et un instrument
     * 
     * @param int $teacherId ID du professeur
     * @param int $instrumentId ID de l'instrument
     * @return bool Succès de l'opération
     */
    public static function delete($teacherId, $instrumentId) {
        $db = getDbConnection();
        $stmt = $db->prepare(
            "DELETE FROM teacher_instruments 
             WHERE teacher_id = :teacher_id AND instrument_id = :instrument_id"
        );
        return $stmt->execute(['teacher_id' => $teacherId, 'instrument_id' => $instrumentId]);
    }
    
    /**
     * Récupérer tous les instruments d'un professeur
     * 
     * @param int $teacherId ID du professeur
     * @return array Liste des instruments du professeur avec leurs détails
     */
    public static function findByTeacher($teacherId) {
        $db = getDbConnection();
        $stmt = $db->prepare(
            "SELECT ti.*, i.name as instrument_name, i.category as instrument_category
             FROM teacher_instruments ti
             JOIN instruments i ON ti.instrument_id = i.id
             WHERE ti.teacher_id = :teacher_id
             ORDER BY i.category, i.name"
        );
        $stmt->execute(['teacher_id' => $teacherId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Récupérer tous les professeurs qui enseignent un instrument spécifique
     * 
     * @param int $instrumentId ID de l'instrument
     * @return array Liste des professeurs avec leurs détails
     */
    public static function findByInstrument($instrumentId) {
        $db = getDbConnection();
        $stmt = $db->prepare(
            "SELECT ti.*, u.id as user_id, u.name as teacher_name, p.description as teacher_description
             FROM teacher_instruments ti
             JOIN users u ON ti.teacher_id = u.id
             LEFT JOIN profiles p ON u.id = p.user_id
             WHERE ti.instrument_id = :instrument_id AND u.role = 'teacher'
             ORDER BY u.name"
        );
        $stmt->execute(['instrument_id' => $instrumentId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Mettre à jour les détails d'une association professeur-instrument
     * 
     * @param int $teacherId ID du professeur
     * @param int $instrumentId ID de l'instrument
     * @param array $data Données à mettre à jour
     * @return bool Succès de l'opération
     */
    public static function update($teacherId, $instrumentId, $data) {
        $db = getDbConnection();
        
        $allowedFields = ['level', 'description'];
        $fields = [];
        $params = [
            'teacher_id' => $teacherId,
            'instrument_id' => $instrumentId
        ];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $fields[] = "$key = :$key";
                $params[$key] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $sql = "UPDATE teacher_instruments SET " . implode(', ', $fields) . " 
                WHERE teacher_id = :teacher_id AND instrument_id = :instrument_id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }
}