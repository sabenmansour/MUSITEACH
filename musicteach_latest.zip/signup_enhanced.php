<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

// Fonction simple de redirection
function redirect($url) {
    header("Location: $url");
    exit;
}

// Fonction simple pour générer un token CSRF
function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - MusiTeach</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4F5D95;
            --secondary-color: #FF9933;
            --accent-color: #8E44AD;
            --text-color: #333;
            --light-color: #f8f9fa;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f2f5;
            color: var(--text-color);
        }
        
        .signup-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .signup-card {
            width: 100%;
            max-width: 600px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            position: relative;
        }
        
        .signup-header {
            background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
            padding: 2rem 2rem 3rem;
            text-align: center;
            color: white;
            border-radius: 0 0 30% 30%;
            margin-bottom: -1.5rem;
        }
        
        .signup-logo {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
            letter-spacing: 1px;
        }
        
        .signup-form {
            padding: 2.5rem 2rem 2rem;
        }
        
        .form-control {
            padding: 0.75rem 1.25rem;
            border-radius: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(79, 93, 149, 0.25);
        }
        
        .input-group-text {
            background-color: white;
            border-right: none;
            border-radius: 10px 0 0 10px;
            color: #6c757d;
        }
        
        .input-group .form-control {
            border-left: none;
            border-radius: 0 10px 10px 0;
        }
        
        .signup-button {
            background: linear-gradient(to right, var(--primary-color), var(--accent-color));
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: 10px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s;
        }
        
        .signup-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            background: linear-gradient(to right, var(--accent-color), var(--primary-color));
        }
        
        .role-selector {
            display: flex;
            margin-bottom: 1.5rem;
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #ddd;
        }
        
        .role-option {
            flex: 1;
            padding: 1rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
        }
        
        .role-option input[type="radio"] {
            position: absolute;
            opacity: 0;
        }
        
        .role-option label {
            display: block;
            cursor: pointer;
            font-weight: 500;
            margin-bottom: 0;
        }
        
        .role-option i {
            display: block;
            font-size: 2rem;
            margin-bottom: 0.5rem;
            color: #6c757d;
        }
        
        .role-option input[type="radio"]:checked + label {
            color: var(--primary-color);
        }
        
        .role-option input[type="radio"]:checked + label i {
            color: var(--primary-color);
        }
        
        .role-option.selected {
            background-color: rgba(79, 93, 149, 0.1);
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 1.5rem 0;
            color: #6c757d;
        }
        
        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #ddd;
        }
        
        .divider::before {
            margin-right: 1rem;
        }
        
        .divider::after {
            margin-left: 1rem;
        }
        
        .footer-links {
            text-align: center;
            margin-top: 1.5rem;
        }
        
        .footer-links a {
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: var(--accent-color);
            text-decoration: underline;
        }
        
        .alert {
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }
        
        .alert-dismissible .btn-close {
            padding: 1.25rem;
        }
        
        .password-strength {
            height: 5px;
            border-radius: 2.5px;
            margin-top: 5px;
            transition: all 0.3s;
        }
        
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
        }
        
        .step {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #e9ecef;
            color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 0.5rem;
            position: relative;
            font-weight: bold;
        }
        
        .step.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .step.completed {
            background-color: #28a745;
            color: white;
        }
        
        .step::after {
            content: "";
            position: absolute;
            width: 100%;
            height: 3px;
            background-color: #e9ecef;
            top: 50%;
            left: 100%;
            transform: translateY(-50%);
        }
        
        .step:last-child::after {
            display: none;
        }
        
        .step.active::after,
        .step.completed::after {
            background-color: var(--primary-color);
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .signup-card {
            animation: fadeIn 0.5s ease-out;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <div class="signup-card">
            <div class="signup-header">
                <div class="signup-logo">MusiTeach</div>
                <p>Créez votre compte et rejoignez notre communauté musicale</p>
            </div>
            
            <div class="signup-form">
                <?php if (isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?= $_SESSION['flash_message']['type'] ?> alert-dismissible fade show" role="alert">
                    <?= $_SESSION['flash_message']['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['flash_message']); ?>
                <?php endif; ?>
                
                <h2 class="text-center mb-4">Créer un compte</h2>
                
                <form action="process_signup.php" method="post" id="signupForm">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="role-selector mb-4">
                        <div class="role-option" id="student-option">
                            <input type="radio" id="role_student" name="role" value="student" <?= (!isset($_SESSION['form_data']['role']) || $_SESSION['form_data']['role'] === 'student') ? 'checked' : '' ?>>
                            <label for="role_student">
                                <i class="fas fa-user-graduate"></i>
                                Élève
                            </label>
                        </div>
                        <div class="role-option" id="teacher-option">
                            <input type="radio" id="role_teacher" name="role" value="teacher" <?= (isset($_SESSION['form_data']['role']) && $_SESSION['form_data']['role'] === 'teacher') ? 'checked' : '' ?>>
                            <label for="role_teacher">
                                <i class="fas fa-chalkboard-teacher"></i>
                                Professeur
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Nom complet" required
                                value="<?= isset($_SESSION['form_data']['name']) ? htmlspecialchars($_SESSION['form_data']['name']) : '' ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Adresse email" required
                                value="<?= isset($_SESSION['form_data']['email']) ? htmlspecialchars($_SESSION['form_data']['email']) : '' ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" required>
                        </div>
                        <div class="password-strength bg-light" id="passwordStrength"></div>
                        <small class="form-text text-muted">Le mot de passe doit contenir au moins 8 caractères, incluant majuscules, minuscules et chiffres.</small>
                    </div>
                    
                    <div class="mb-4">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="Confirmer le mot de passe" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn signup-button w-100 mb-3">S'inscrire</button>
                    
                    <div class="divider">ou inscrivez-vous avec</div>
                    
                    <div class="d-grid gap-2 mb-3">
                        <button type="button" class="btn btn-outline-primary">
                            <i class="fab fa-facebook-f me-2"></i> Facebook
                        </button>
                        <button type="button" class="btn btn-outline-danger">
                            <i class="fab fa-google me-2"></i> Google
                        </button>
                    </div>
                    
                    <div class="footer-links">
                        <p>Vous avez déjà un compte ? <a href="login.php">Se connecter</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Sélection du rôle (élève/professeur)
        document.addEventListener('DOMContentLoaded', function() {
            const studentOption = document.getElementById('student-option');
            const teacherOption = document.getElementById('teacher-option');
            const studentRadio = document.getElementById('role_student');
            const teacherRadio = document.getElementById('role_teacher');
            
            function updateRoleSelection() {
                if (studentRadio.checked) {
                    studentOption.classList.add('selected');
                    teacherOption.classList.remove('selected');
                } else {
                    teacherOption.classList.add('selected');
                    studentOption.classList.remove('selected');
                }
            }
            
            // Initialisation
            updateRoleSelection();
            
            // Événements de clic
            studentOption.addEventListener('click', function() {
                studentRadio.checked = true;
                updateRoleSelection();
            });
            
            teacherOption.addEventListener('click', function() {
                teacherRadio.checked = true;
                updateRoleSelection();
            });
            
            // Force de mot de passe
            const passwordInput = document.getElementById('password');
            const strengthIndicator = document.getElementById('passwordStrength');
            
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                
                if (password.length >= 8) strength += 25;
                if (password.match(/[A-Z]/)) strength += 25;
                if (password.match(/[a-z]/)) strength += 25;
                if (password.match(/[0-9]/)) strength += 25;
                
                strengthIndicator.style.width = strength + '%';
                
                if (strength <= 25) {
                    strengthIndicator.style.backgroundColor = '#dc3545'; // Rouge
                } else if (strength <= 50) {
                    strengthIndicator.style.backgroundColor = '#ffc107'; // Jaune
                } else if (strength <= 75) {
                    strengthIndicator.style.backgroundColor = '#fd7e14'; // Orange
                } else {
                    strengthIndicator.style.backgroundColor = '#28a745'; // Vert
                }
            });
        });
    </script>
</body>
</html>
<?php
// Nettoyer les données de formulaire stockées en session
if (isset($_SESSION['form_data'])) {
    unset($_SESSION['form_data']);
}
?>