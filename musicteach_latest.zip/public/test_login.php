<?php
// Afficher toutes les erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclure les fichiers nécessaires
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';

// Vérifier si l'utilisateur est déjà connecté
if (isLoggedIn()) {
    echo "<h1>Test d'authentification</h1>";
    echo "<p>Vous êtes déjà connecté en tant que: " . htmlspecialchars($_SESSION['user_name']) . " (ID: " . $_SESSION['user_id'] . ")</p>";
    echo "<p>Rôle: " . htmlspecialchars($_SESSION['user_role']) . "</p>";
    echo "<p><a href='test_logout.php'>Se déconnecter</a></p>";
    exit;
}

// Traiter le formulaire de connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = "Veuillez saisir un email et un mot de passe.";
    } else {
        // Tenter de récupérer l'utilisateur
        $user = User::findByEmail($email);
        
        if ($user && verifyPassword($password, $user['password'])) {
            // Connecter l'utilisateur
            loginUser($user);
            
            // Rediriger vers cette même page pour voir les informations de connexion
            header("Location: test_login.php");
            exit;
        } else {
            $error = "Email ou mot de passe incorrect.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test d'authentification</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        h1 { color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input[type="email"], input[type="password"] { width: 100%; padding: 8px; box-sizing: border-box; }
        button { background: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        .error { color: red; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h1>Test d'authentification</h1>
    
    <?php if (isset($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <form method="post" action="test_login.php">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="password">Mot de passe:</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <button type="submit">Se connecter</button>
    </form>
    
    <p>Pour créer un nouvel utilisateur pour les tests, <a href="test_create_user.php">cliquez ici</a>.</p>
</body>
</html>