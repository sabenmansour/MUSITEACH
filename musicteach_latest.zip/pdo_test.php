<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo '<h1>Test de connexion PDO à la base de données</h1>';

// Extensions PHP
echo '<h2>Extensions PHP chargées</h2>';
echo '<pre>';
print_r(get_loaded_extensions());
echo '</pre>';

// Test de connexion PDO directe
echo '<h2>Test de connexion PDO directe</h2>';
try {
    $dsn = 'mysql:host=mysql;dbname=musicteach;charset=utf8mb4';
    $pdo = new PDO($dsn, 'musicteach', 'musicteach');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo '<p style="color:green">Connexion directe réussie!</p>';
    
    // Lister les tables
    $stmt = $pdo->query('SHOW TABLES');
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo '<h3>Tables dans la base de données:</h3>';
    echo '<ul>';
    foreach ($tables as $table) {
        echo '<li>' . $table . '</li>';
    }
    echo '</ul>';
} catch (PDOException $e) {
    echo '<p style="color:red">Erreur de connexion PDO: ' . $e->getMessage() . '</p>';
}
