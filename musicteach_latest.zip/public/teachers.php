<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Titre de la page
$pageTitle = "Nos professeurs";

// Paramètres de pagination
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 9; // Nombre de professeurs par page

// Récupérer les professeurs
$teachers = User::findAllTeachers($page, $perPage);
$totalTeachers = User::countTeachers();
$totalPages = ceil($totalTeachers / $perPage);

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<!-- Hero Section pour la recherche -->
<section class="bg-light py-5">
    <div class="container">
        <h1 class="text-center mb-4">Trouvez le professeur idéal</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="teachers.php" method="get" class="d-flex">
                    <input type="text" name="search" class="form-control me-2" placeholder="Rechercher par nom ou instrument..." 
                           value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    <button type="submit" class="btn btn-primary">Rechercher</button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Liste des professeurs -->
<section class="py-5">
    <div class="container">
        <h2 class="mb-4">Nos professeurs de musique</h2>
        
        <?php if (empty($teachers)): ?>
            <div class="alert alert-info">
                Aucun professeur trouvé. Veuillez réessayer avec d'autres critères de recherche.
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($teachers as $teacher): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="/resources/img/teacher-placeholder.jpg" class="card-img-top" alt="<?= htmlspecialchars($teacher['name']) ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($teacher['name']) ?></h5>
                                
                                <?php if (isset($teacher['instrument']) && !empty($teacher['instrument'])): ?>
                                    <p class="card-text">
                                        <span class="badge bg-primary mb-2"><?= htmlspecialchars($teacher['instrument']) ?></span>
                                    </p>
                                <?php endif; ?>
                                
                                <p class="card-text">
                                    <?= isset($teacher['description']) && !empty($teacher['description']) 
                                        ? htmlspecialchars(substr($teacher['description'], 0, 100)) . '...' 
                                        : 'Professeur de musique passionné prêt à partager son savoir.' ?>
                                </p>
                                
                                <a href="profile.php?id=<?= $teacher['id'] ?>" class="btn btn-primary">Voir le profil</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?= generatePagination($page, $totalPages, 'teachers.php?page=%d') ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>