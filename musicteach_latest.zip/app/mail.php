<?php
/**
 * Gestion des emails
 */

require_once __DIR__ . '/config.php';

/**
 * Envoyer un email
 * 
 * @param string $to Adresse email du destinataire
 * @param string $subject Sujet de l'email
 * @param string $body Corps de l'email (HTML)
 * @param string $altBody Corps alternatif (texte brut)
 * @return bool Succès de l'envoi
 */
function sendEmail($to, $subject, $body, $altBody = '') {
    // Utilisation de PHPMailer si disponible
    if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        return sendEmailPhpMailer($to, $subject, $body, $altBody);
    }
    
    // Fallback vers la fonction mail() native
    $headers = [
        'From: ' . MAIL_NAME . ' <' . MAIL_FROM . '>',
        'Reply-To: ' . MAIL_FROM,
        'X-Mailer: PHP/' . phpversion(),
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8'
    ];
    
    return mail($to, $subject, $body, implode("\r\n", $headers));
}

/**
 * Envoyer un email avec PHPMailer
 */
function sendEmailPhpMailer($to, $subject, $body, $altBody = '') {
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        // Configuration du serveur
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';
        
        // Destinataires
        $mail->setFrom(MAIL_FROM, MAIL_NAME);
        $mail->addAddress($to);
        $mail->addReplyTo(MAIL_FROM, MAIL_NAME);
        
        // Contenu
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = $altBody ?: strip_tags($body);
        
        return $mail->send();
    } catch (Exception $e) {
        if (defined('DEBUG') && DEBUG) {
            error_log('Erreur d\'envoi d\'email : ' . $e->getMessage());
        }
        return false;
    }
}

/**
 * Envoyer un email de vérification de compte
 * 
 * @param string $email Adresse email de l'utilisateur
 * @param string $name Nom de l'utilisateur
 * @param string $token Token d'activation
 * @return bool Succès de l'envoi
 */
function sendVerificationEmail($email, $name, $token) {
    $subject = APP_NAME . ' - Activation de votre compte';
    
    // URL d'activation
    $activationUrl = APP_URL . '/verify_email.php?token=' . $token;
    
    // Corps du message HTML
    $body = '
    <html>
    <head>
        <title>Activation de votre compte ' . APP_NAME . '</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 20px;">
                <h1 style="color: #4F5D95;">' . APP_NAME . '</h1>
            </div>
            <div style="background-color: #f9f9f9; padding: 20px; border-radius: 5px;">
                <h2>Bonjour ' . htmlspecialchars($name) . ',</h2>
                <p>Merci de vous être inscrit sur ' . APP_NAME . '. Pour activer votre compte, veuillez cliquer sur le bouton ci-dessous :</p>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="' . $activationUrl . '" style="background-color: #4F5D95; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Activer mon compte</a>
                </div>
                <p>Ou copiez et collez le lien suivant dans votre navigateur :</p>
                <p><a href="' . $activationUrl . '">' . $activationUrl . '</a></p>
                <p>Ce lien expirera dans ' . EMAIL_VERIFICATION_EXPIRY . ' heures.</p>
                <p>Si vous n\'avez pas créé de compte sur notre site, veuillez ignorer cet email.</p>
            </div>
            <div style="margin-top: 20px; font-size: 12px; color: #777; text-align: center;">
                <p>Cet email a été envoyé automatiquement, merci de ne pas y répondre.</p>
                <p>&copy; ' . date('Y') . ' ' . APP_NAME . '. Tous droits réservés.</p>
            </div>
        </div>
    </body>
    </html>';
    
    // Corps alternatif (texte brut)
    $altBody = "Bonjour " . $name . ",\n\n" .
               "Merci de vous être inscrit sur " . APP_NAME . ". Pour activer votre compte, veuillez cliquer sur le lien ci-dessous :\n\n" .
               $activationUrl . "\n\n" .
               "Ce lien expirera dans " . EMAIL_VERIFICATION_EXPIRY . " heures.\n\n" .
               "Si vous n'avez pas créé de compte sur notre site, veuillez ignorer cet email.\n\n" .
               "Cet email a été envoyé automatiquement, merci de ne pas y répondre.\n\n" .
               "© " . date('Y') . " " . APP_NAME . ". Tous droits réservés.";
    
    return sendEmail($email, $subject, $body, $altBody);
}