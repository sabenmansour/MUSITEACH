<?php
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';

// Déconnecter l'utilisateur
logoutUser();

// Rediriger vers la page d'accueil avec un message
setFlashMessage('success', 'Vous avez été déconnecté avec succès.');
redirect('index.php');