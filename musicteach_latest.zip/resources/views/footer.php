    <!-- Footer -->
    <footer class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>MusiTeach</h5>
                    <p>La plateforme qui connecte les professeurs de musique et les élèves pour un apprentissage musical personnalisé et efficace.</p>
                    <div class="social-icons">
                        <a href="#" class="me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="me-3"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h5>Liens utiles</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Accueil</a></li>
                        <li><a href="teachers.php">Professeurs</a></li>
                        <li><a href="about.php">À propos</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4">
                    <h5>Apprendre</h5>
                    <ul class="list-unstyled">
                        <li><a href="resources.php">Ressources musicales</a></li>
                        <li><a href="resources.php#theory">Théorie musicale</a></li>
                        <li><a href="resources.php#exercises">Exercices pratiques</a></li>
                        <li><a href="resources.php#blog">Blog musical</a></li>
                        <li><a href="videos.php"><i class="fas fa-video me-1"></i> Vidéos musicales</a></li>
                        <li><a href="resources.php#videos">Vidéos pédagogiques</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4">
                    <h5>Besoin d'aide ?</h5>
                    <ul class="list-unstyled">
                        <li><a href="contact.php">Centre d'aide</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="terms.php">Conditions d'utilisation</a></li>
                        <li><a href="privacy.php">Politique de confidentialité</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> MusiTeach - Tous droits réservés</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- AOS Animation JS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            AOS.init({
                duration: 800,
                once: true
            });
        });
    </script>
    
    <!-- Notre JS -->
    <script src="/resources/js/main.js"></script>
    
    <?php if (isset($extraJs)): ?>
        <?= $extraJs ?>
    <?php endif; ?>
    
    <!-- Mode Switch Button -->
    <div class="mode-switch" id="mode-switch" title="Options d'affichage (clair, sombre, sepia...)">
        <i class="fas fa-palette me-2"></i> Thèmes
    </div>
</body>
</html>