<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Vérifier si l'ID de l'utilisateur est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Utilisateur non trouvé.');
    redirect('admin_users.php');
}

$userId = (int)$_GET['id'];

// Récupérer l'utilisateur
$user = User::findById($userId);

// Vérifier si l'utilisateur existe
if (!$user) {
    setFlashMessage('error', 'Utilisateur non trouvé.');
    redirect('admin_users.php');
}

// Récupérer le profil
$profile = Profile::findByUserId($userId);

// Traitement du formulaire si soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
        redirect('admin_user_edit.php?id=' . $userId);
    }
    
    // Récupérer et nettoyer les données du formulaire
    $name = sanitizeInput($_POST['name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $role = sanitizeInput($_POST['role'] ?? '');
    
    // Validation
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Le nom est requis.';
    }
    
    if (empty($email) || !isValidEmail($email)) {
        $errors[] = 'L\'adresse email est invalide.';
    } elseif (User::emailExists($email, $userId)) {
        $errors[] = 'Cette adresse email est déjà utilisée par un autre utilisateur.';
    }
    
    if (!in_array($role, ['student', 'teacher', 'admin'])) {
        $errors[] = 'Le rôle sélectionné est invalide.';
    }
    
    // Empêcher un administrateur de changer son propre rôle
    if ($userId === (int)$_SESSION['user_id'] && $role !== 'admin') {
        $errors[] = 'Vous ne pouvez pas changer votre propre rôle d\'administrateur.';
    }
    
    // S'il y a des erreurs, afficher un message d'erreur
    if (!empty($errors)) {
        setFlashMessage('error', implode(' ', $errors));
    } else {
        // Mettre à jour l'utilisateur
        try {
            $userData = [
                'name' => $name,
                'email' => $email
            ];
            
            // Ne pas modifier le rôle si l'utilisateur modifie son propre compte et qu'il est admin
            if (!($userId === (int)$_SESSION['user_id'] && $user['role'] === 'admin')) {
                $userData['role'] = $role;
            }
            
            if (User::update($userId, $userData)) {
                // Mettre à jour le profil
                $profileData = [];
                
                if (isset($_POST['description'])) {
                    $profileData['description'] = sanitizeInput($_POST['description']);
                }
                
                if (isset($_POST['instrument'])) {
                    $profileData['instrument'] = sanitizeInput($_POST['instrument']);
                }
                
                if (isset($_POST['experience'])) {
                    $profileData['experience'] = sanitizeInput($_POST['experience']);
                }
                
                // Ne mettre à jour le type de profil que si le rôle a changé
                if ($role !== $user['role'] && !($userId === (int)$_SESSION['user_id'] && $user['role'] === 'admin')) {
                    $profileData['type'] = $role === 'admin' ? 'teacher' : $role; // Les admins ont un profil de type 'teacher'
                }
                
                if (!empty($profileData)) {
                    Profile::createOrUpdate($userId, $profileData);
                }
                
                setFlashMessage('success', 'Les informations de l\'utilisateur ont été mises à jour avec succès.');
                redirect('admin_users.php');
            } else {
                setFlashMessage('error', 'Une erreur est survenue lors de la mise à jour de l\'utilisateur.');
            }
        } catch (Exception $e) {
            setFlashMessage('error', 'Une erreur est survenue lors de la mise à jour de l\'utilisateur.');
        }
    }
}

// Titre de la page
$pageTitle = "Modifier l'utilisateur";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Modifier l'utilisateur</h1>
    
    <div class="card">
        <div class="card-body">
            <form action="admin_user_edit.php?id=<?= $userId ?>" method="post">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <input type="hidden" name="update_user" value="1">
                
                <div class="mb-3">
                    <label for="name" class="form-label">Nom</label>
                    <input type="text" class="form-control" id="name" name="name" required 
                           value="<?= htmlspecialchars($user['name']) ?>">
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required 
                           value="<?= htmlspecialchars($user['email']) ?>">
                </div>
                
                <div class="mb-3">
                    <label for="role" class="form-label">Rôle</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="student" <?= $user['role'] === 'student' ? 'selected' : '' ?>>Élève</option>
                        <option value="teacher" <?= $user['role'] === 'teacher' ? 'selected' : '' ?>>Professeur</option>
                        <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                    </select>
                    <?php if ($userId === (int)$_SESSION['user_id'] && $user['role'] === 'admin'): ?>
                        <div class="form-text text-warning">
                            Vous ne pouvez pas changer votre propre rôle d'administrateur.
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Champs spécifiques au profil -->
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?= isset($profile['description']) ? htmlspecialchars($profile['description']) : '' ?></textarea>
                </div>
                
                <div class="mb-3">
                    <label for="instrument" class="form-label">Instrument (pour les professeurs)</label>
                    <input type="text" class="form-control" id="instrument" name="instrument" 
                           value="<?= isset($profile['instrument']) ? htmlspecialchars($profile['instrument']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="experience" class="form-label">Expérience (pour les professeurs)</label>
                    <textarea class="form-control" id="experience" name="experience" rows="3"><?= isset($profile['experience']) ? htmlspecialchars($profile['experience']) : '' ?></textarea>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="admin_users.php" class="btn btn-secondary">Annuler</a>
                    <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>