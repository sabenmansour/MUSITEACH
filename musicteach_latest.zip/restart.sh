#!/bin/bash

# Définition des couleurs
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Arrêt des containers existants...${NC}"
docker-compose down

# Supprimer les volumes si demandé
if [ "$1" == "--clean" ]; then
    echo -e "${RED}Suppression des volumes...${NC}"
    docker-compose down -v
    docker volume rm musicteach_data 2>/dev/null || true
fi

echo -e "${YELLOW}Démarrage des containers...${NC}"
docker-compose up -d

# Attendre que les conteneurs soient prêts
echo -e "${BLUE}Attente du démarrage complet des services...${NC}"
sleep 10

# Vérifier le statut des conteneurs
echo -e "${BLUE}Statut des conteneurs:${NC}"
docker-compose ps

# Vérifier la santé des conteneurs
echo -e "${BLUE}Vérification de la santé de la base de données...${NC}"
docker exec musicteach_db mysqladmin ping -u musicteach -pmusicteach >/dev/null 2>&1 && echo -e "${GREEN}La base de données est prête${NC}" || echo -e "${RED}La base de données n'est pas encore prête${NC}"

echo -e "${BLUE}Vérification de l'accès au serveur web...${NC}"
curl -s http://localhost:8000/ > /dev/null 2>&1 && echo -e "${GREEN}Le serveur web répond correctement${NC}" || echo -e "${RED}Le serveur web ne répond pas${NC}"

echo -e "${GREEN}MusiTeach est maintenant disponible sur:${NC}"
echo -e "${GREEN}- Application: http://localhost:8000${NC}"
echo -e "${GREEN}- PhpMyAdmin: http://localhost:8181${NC}"
echo -e "${YELLOW}Utilisateur MySQL: musicteach / Mot de passe: musicteach${NC}"
