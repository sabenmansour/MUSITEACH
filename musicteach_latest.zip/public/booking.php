<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';
require_once __DIR__ . '/../app/models/Booking.php';

// Vérifier si l'utilisateur est connecté
requireLogin();

// Vérifier si l'utilisateur est un étudiant
if (!isStudent()) {
    setFlashMessage('error', 'Seuls les élèves peuvent réserver des cours.');
    redirect('index.php');
}

// Vérifier si l'ID du professeur est fourni
if (!isset($_GET['teacher_id']) || !is_numeric($_GET['teacher_id'])) {
    setFlashMessage('error', 'Professeur non trouvé.');
    redirect('teachers.php');
}

$teacherId = (int)$_GET['teacher_id'];

// Récupérer les informations du professeur
$teacher = User::findById($teacherId);

// Vérifier si le professeur existe et est bien un professeur
if (!$teacher || $teacher['role'] !== 'teacher') {
    setFlashMessage('error', 'Professeur non trouvé.');
    redirect('teachers.php');
}

// Récupérer le profil du professeur
$profile = Profile::findByUserId($teacherId);

// Titre de la page
$pageTitle = "Réserver un cours avec " . $teacher['name'];

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';

// Ajouter un CSS personnalisé pour le calendrier de réservation
$extraCss = <<<CSS
<style>
    .selected-date-header {
        background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
        border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 2rem;
        color: white;
    }
    
    .booking-progress {
        position: relative;
        display: flex;
        justify-content: space-between;
        margin-bottom: 3rem;
    }
    
    .booking-progress::before {
        content: '';
        position: absolute;
        top: 24px;
        left: 0;
        right: 0;
        height: 3px;
        background-color: var(--border-color);
        z-index: 0;
    }
    
    .booking-step {
        position: relative;
        z-index: 1;
        background-color: var(--card-bg);
        text-align: center;
        width: 150px;
    }
    
    .booking-step-icon {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: var(--card-bg);
        color: var(--muted-color);
        border: 3px solid var(--border-color);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 10px;
        font-size: 1.5rem;
        transition: all 0.3s ease;
    }
    
    .booking-step.active .booking-step-icon {
        background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
        color: white;
        border-color: var(--primary-color);
        box-shadow: 0 5px 15px var(--shadow-color);
    }
    
    .booking-step.completed .booking-step-icon {
        background-color: var(--success-color);
        color: white;
        border-color: var(--success-color);
    }
    
    .booking-step-title {
        font-weight: 600;
        font-size: 0.9rem;
        color: var(--text-color);
    }
    
    .booking-step.active .booking-step-title {
        color: var(--primary-color);
        font-weight: 700;
    }
    
    .booking-option {
        border: 2px solid var(--border-color);
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .booking-option:hover {
        border-color: var(--primary-color);
        transform: translateY(-5px);
        box-shadow: 0 10px 20px var(--shadow-color);
    }
    
    .booking-option.selected {
        border-color: var(--primary-color);
        background-color: rgba(79, 93, 149, 0.1);
    }
    
    .booking-option-header {
        display: flex;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    .booking-option-icon {
        margin-right: 1rem;
        font-size: 1.5rem;
        color: var(--primary-color);
    }
    
    .booking-step-content {
        display: none;
    }
    
    .booking-step-content.active {
        display: block;
        animation: fadeIn 0.5s ease;
    }
    
    @media (max-width: 768px) {
        .booking-progress {
            flex-wrap: wrap;
        }
        
        .booking-step {
            margin-bottom: 1.5rem;
            width: 30%;
        }
        
        .booking-progress::before {
            display: none;
        }
    }
    
    @media (max-width: 576px) {
        .booking-step {
            width: 100%;
        }
    }
</style>
CSS;
?>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                    <li class="breadcrumb-item"><a href="teachers.php">Professeurs</a></li>
                    <li class="breadcrumb-item"><a href="profile.php?id=<?= $teacher['id'] ?>"><?= htmlspecialchars($teacher['name']) ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Réservation</li>
                </ol>
            </nav>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12 mb-4" data-aos="fade-up">
            <h1 class="mb-4">Réserver un cours avec <?= htmlspecialchars($teacher['name']) ?></h1>
            
            <!-- Étapes de réservation -->
            <div class="booking-progress">
                <div class="booking-step active" data-step="1">
                    <div class="booking-step-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="booking-step-title">Choisir une date</div>
                </div>
                <div class="booking-step" data-step="2">
                    <div class="booking-step-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="booking-step-title">Choisir un horaire</div>
                </div>
                <div class="booking-step" data-step="3">
                    <div class="booking-step-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="booking-step-title">Confirmer</div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Informations du professeur -->
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card h-100">
                <div class="card-body text-center p-4">
                    <img src="/resources/img/teacher-placeholder.jpg" alt="<?= htmlspecialchars($teacher['name']) ?>" 
                         class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
                    <h4><?= htmlspecialchars($teacher['name']) ?></h4>
                    
                    <?php if (isset($profile['instrument']) && !empty($profile['instrument'])): ?>
                        <p class="badge bg-primary px-3 py-2 mb-3"><?= htmlspecialchars($profile['instrument']) ?></p>
                    <?php endif; ?>
                    
                    <div class="d-flex justify-content-center mb-3">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star-half-alt text-warning"></i>
                        <span class="ms-2">4.8 (24 avis)</span>
                    </div>
                    
                    <p><a href="profile.php?id=<?= $teacher['id'] ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-user me-1"></i> Voir le profil complet
                    </a></p>
                </div>
                
                <div class="card-footer p-4">
                    <h5 class="mb-3">Informations pratiques</h5>
                    
                    <div class="d-flex align-items-center mb-3">
                        <i class="fas fa-euro-sign text-primary fa-fw me-2"></i>
                        <div>
                            <div class="fw-bold">Tarif horaire</div>
                            <div><?= isset($profile['hourly_rate']) ? htmlspecialchars($profile['hourly_rate']) . ' €/heure' : '30-45 €/heure' ?></div>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center mb-3">
                        <i class="fas fa-graduation-cap text-primary fa-fw me-2"></i>
                        <div>
                            <div class="fw-bold">Niveaux enseignés</div>
                            <div><?= isset($profile['levels']) ? htmlspecialchars($profile['levels']) : 'Débutant, Intermédiaire, Avancé' ?></div>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center mb-3">
                        <i class="fas fa-map-marker-alt text-primary fa-fw me-2"></i>
                        <div>
                            <div class="fw-bold">Localisation</div>
                            <div><?= isset($profile['location']) ? htmlspecialchars($profile['location']) : 'Paris' ?></div>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center">
                        <i class="fas fa-users text-primary fa-fw me-2"></i>
                        <div>
                            <div class="fw-bold">Types de cours</div>
                            <div><?= isset($profile['lesson_types']) ? htmlspecialchars($profile['lesson_types']) : 'En présentiel, En ligne' ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Formulaire de réservation -->
        <div class="col-md-8" data-aos="fade-left">
            <form action="process_booking.php" method="post" id="booking-form">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <input type="hidden" name="teacher_id" value="<?= $teacher['id'] ?>">
                <input type="hidden" name="booking_date" id="booking_date" required>
                <input type="hidden" name="booking_time" id="booking_time" required>
                
                <!-- Étape 1: Sélection de la date -->
                <div class="booking-step-content active" id="step-1">
                    <div class="card mb-4">
                        <div class="card-body p-4">
                            <h4 class="card-title mb-4">1. Choisissez une date</h4>
                            
                            <div class="calendar mb-4">
                                <div class="calendar-header mb-4">
                                    <button type="button" class="btn btn-outline-primary" id="prev-month">
                                        <i class="fas fa-chevron-left"></i>
                                    </button>
                                    <h5 class="mb-0 mx-3">Avril 2025</h5>
                                    <button type="button" class="btn btn-outline-primary" id="next-month">
                                        <i class="fas fa-chevron-right"></i>
                                    </button>
                                </div>
                                
                                <div class="calendar-days">
                                    <!-- Noms des jours de la semaine -->
                                    <div class="fw-bold">Lun</div>
                                    <div class="fw-bold">Mar</div>
                                    <div class="fw-bold">Mer</div>
                                    <div class="fw-bold">Jeu</div>
                                    <div class="fw-bold">Ven</div>
                                    <div class="fw-bold">Sam</div>
                                    <div class="fw-bold">Dim</div>
                                    
                                    <!-- Jours du mois (exemple) -->
                                    <div></div>
                                    <div></div>
                                    <div class="calendar-day">1</div>
                                    <div class="calendar-day">2</div>
                                    <div class="calendar-day">3</div>
                                    <div class="calendar-day">4</div>
                                    <div class="calendar-day">5</div>
                                    
                                    <div class="calendar-day">6</div>
                                    <div class="calendar-day">7</div>
                                    <div class="calendar-day">8</div>
                                    <div class="calendar-day">9</div>
                                    <div class="calendar-day">10</div>
                                    <div class="calendar-day">11</div>
                                    <div class="calendar-day">12</div>
                                    
                                    <div class="calendar-day">13</div>
                                    <div class="calendar-day">14</div>
                                    <div class="calendar-day">15</div>
                                    <div class="calendar-day">16</div>
                                    <div class="calendar-day">17</div>
                                    <div class="calendar-day">18</div>
                                    <div class="calendar-day">19</div>
                                    
                                    <div class="calendar-day">20</div>
                                    <div class="calendar-day">21</div>
                                    <div class="calendar-day">22</div>
                                    <div class="calendar-day">23</div>
                                    <div class="calendar-day">24</div>
                                    <div class="calendar-day">25</div>
                                    <div class="calendar-day">26</div>
                                    
                                    <div class="calendar-day">27</div>
                                    <div class="calendar-day">28</div>
                                    <div class="calendar-day">29</div>
                                    <div class="calendar-day">30</div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                </div>
                                
                                <div class="mt-3">
                                    <p class="small text-muted">
                                        <i class="fas fa-circle text-primary me-2" style="font-size: 0.7em;"></i> Dates disponibles
                                    </p>
                                </div>
                            </div>
                            
                            <div class="text-end">
                                <button type="button" class="btn btn-primary next-step" data-next="2" disabled>
                                    Étape suivante <i class="fas fa-arrow-right ms-1"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Étape 2: Sélection de l'heure -->
                <div class="booking-step-content" id="step-2">
                    <div class="card mb-4">
                        <div class="card-body p-4">
                            <h4 class="card-title mb-4">2. Choisissez un horaire</h4>
                            
                            <div class="selected-date-header mb-4">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-day fa-2x"></i>
                                    </div>
                                    <div class="col">
                                        <h5 class="mb-0">Date sélectionnée :</h5>
                                        <div class="fs-4 fw-bold" id="selected-date-display">15 avril 2025</div>
                                    </div>
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-outline-light prev-step" data-prev="1">
                                            <i class="fas fa-edit me-1"></i> Modifier
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <p class="mb-4">Sélectionnez l'horaire qui vous convient parmi les créneaux disponibles :</p>
                            
                            <div class="row" id="visual-time-slots">
                                <!-- Les créneaux horaires seront générés dynamiquement par JavaScript -->
                            </div>
                            
                            <div class="mt-3 d-flex justify-content-between">
                                <button type="button" class="btn btn-outline-primary prev-step" data-prev="1">
                                    <i class="fas fa-arrow-left me-1"></i> Retour
                                </button>
                                <button type="button" class="btn btn-primary next-step" data-next="3" disabled>
                                    Étape suivante <i class="fas fa-arrow-right ms-1"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Étape 3: Confirmation -->
                <div class="booking-step-content" id="step-3">
                    <div class="card mb-4">
                        <div class="card-body p-4">
                            <h4 class="card-title mb-4">3. Confirmez votre réservation</h4>
                            
                            <div class="alert alert-info mb-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <i class="fas fa-info-circle fa-2x me-3"></i>
                                    </div>
                                    <div>
                                        <h5 class="alert-heading">Rappel important</h5>
                                        <p class="mb-0">Vous pouvez annuler gratuitement jusqu'à 24 heures avant le cours. Passé ce délai, le cours sera facturé.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0">Résumé de votre réservation</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-md-4 fw-bold">Professeur :</div>
                                        <div class="col-md-8"><?= htmlspecialchars($teacher['name']) ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 fw-bold">Instrument :</div>
                                        <div class="col-md-8"><?= isset($profile['instrument']) ? htmlspecialchars($profile['instrument']) : 'Non spécifié' ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 fw-bold">Date :</div>
                                        <div class="col-md-8" id="summary-date">15 avril 2025</div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 fw-bold">Heure :</div>
                                        <div class="col-md-8" id="summary-time">10:00</div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4 fw-bold">Durée :</div>
                                        <div class="col-md-8">1 heure</div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 fw-bold">Tarif :</div>
                                        <div class="col-md-8"><?= isset($profile['hourly_rate']) ? htmlspecialchars($profile['hourly_rate']) . ' €' : '35 €' ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="message" class="form-label fw-bold">Message au professeur (optionnel)</label>
                                <textarea class="form-control" id="message" name="message" rows="3" placeholder="Informations complémentaires, niveau, objectifs spécifiques..."></textarea>
                            </div>
                            
                            <div class="form-check mb-4">
                                <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                                <label class="form-check-label" for="terms">
                                    J'accepte les <a href="#" target="_blank">conditions générales</a> de MusiTeach
                                </label>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <button type="button" class="btn btn-outline-primary prev-step" data-prev="2">
                                    <i class="fas fa-arrow-left me-1"></i> Retour
                                </button>
                                <button type="submit" class="btn btn-success" id="confirm-booking">
                                    <i class="fas fa-check-circle me-1"></i> Confirmer la réservation
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Variables pour les étapes
    const bookingSteps = document.querySelectorAll('.booking-step');
    const bookingStepContents = document.querySelectorAll('.booking-step-content');
    const nextButtons = document.querySelectorAll('.next-step');
    const prevButtons = document.querySelectorAll('.prev-step');
    
    // Fonctions pour naviguer entre les étapes
    function goToStep(stepNumber) {
        // Mise à jour des indicateurs d'étape
        bookingSteps.forEach(step => {
            const stepNum = parseInt(step.dataset.step);
            step.classList.remove('active', 'completed');
            if (stepNum < stepNumber) {
                step.classList.add('completed');
            } else if (stepNum === stepNumber) {
                step.classList.add('active');
            }
        });
        
        // Affichage du contenu de l'étape
        bookingStepContents.forEach(content => {
            content.classList.remove('active');
            if (content.id === `step-${stepNumber}`) {
                content.classList.add('active');
            }
        });
        
        // Faire défiler vers le haut
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    // Écouteurs pour les boutons suivant/précédent
    nextButtons.forEach(button => {
        button.addEventListener('click', function() {
            const nextStep = parseInt(this.dataset.next);
            goToStep(nextStep);
        });
    });
    
    prevButtons.forEach(button => {
        button.addEventListener('click', function() {
            const prevStep = parseInt(this.dataset.prev);
            goToStep(prevStep);
        });
    });
    
    // Gestion du calendrier
    const calendarDays = document.querySelectorAll('.calendar-day');
    const nextStepBtn1 = document.querySelector('[data-next="2"]');
    const selectedDateDisplay = document.getElementById('selected-date-display');
    const summaryDate = document.getElementById('summary-date');
    const bookingDateInput = document.getElementById('booking_date');
    
    calendarDays.forEach(function(day) {
        day.addEventListener('click', function() {
            // Supprimer la classe active de tous les jours
            calendarDays.forEach(function(d) {
                d.classList.remove('active');
            });
            
            // Ajouter la classe active au jour cliqué
            day.classList.add('active');
            
            // Mettre à jour le champ caché
            const dayNum = parseInt(day.textContent);
            if (!isNaN(dayNum)) {
                const formattedDate = `2025-04-${dayNum.toString().padStart(2, '0')}`;
                bookingDateInput.value = formattedDate;
                
                // Mettre à jour l'affichage de la date sélectionnée
                const displayDate = `${dayNum} avril 2025`;
                selectedDateDisplay.textContent = displayDate;
                summaryDate.textContent = displayDate;
                
                // Activer le bouton suivant
                nextStepBtn1.disabled = false;
            }
        });
    });
    
    // Gestion des créneaux horaires
    const nextStepBtn2 = document.querySelector('[data-next="3"]');
    const bookingTimeInput = document.getElementById('booking_time');
    const summaryTime = document.getElementById('summary-time');
    
    function updateTimeSlots() {
        const timeSlotsContainer = document.getElementById('visual-time-slots');
        if (timeSlotsContainer) {
            // Vider le conteneur
            timeSlotsContainer.innerHTML = '';
            
            // Simuler les créneaux disponibles en fonction de la date
            const timeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
            
            // Simuler des créneaux indisponibles pour certains jours
            const selectedDay = parseInt(bookingDateInput.value.split('-')[2]);
            const unavailableSlots = selectedDay % 2 === 0 ? ['10:00', '15:00'] : ['11:00', '17:00'];
            
            timeSlots.forEach(time => {
                const isAvailable = !unavailableSlots.includes(time);
                const col = document.createElement('div');
                col.className = 'col-md-3 col-6 mb-3';
                
                const slot = document.createElement('div');
                slot.className = `time-slot ${isAvailable ? '' : 'unavailable'}`;
                slot.dataset.time = time;
                slot.innerHTML = `
                    <i class="far fa-clock me-2"></i> ${time}
                    ${isAvailable ? '' : '<span class="badge bg-secondary ms-2">Indisponible</span>'}
                `;
                
                col.appendChild(slot);
                timeSlotsContainer.appendChild(col);
                
                // Ajouter l'événement click aux créneaux disponibles
                if (isAvailable) {
                    slot.addEventListener('click', function() {
                        document.querySelectorAll('.time-slot').forEach(s => {
                            s.classList.remove('selected');
                        });
                        
                        slot.classList.add('selected');
                        bookingTimeInput.value = time;
                        summaryTime.textContent = time;
                        nextStepBtn2.disabled = false;
                    });
                }
            });
        }
    }
    
    // Mettre à jour les créneaux horaires quand on passe à l'étape 2
    nextStepBtn1.addEventListener('click', updateTimeSlots);
    
    // Validation du formulaire
    const bookingForm = document.getElementById('booking-form');
    const termsCheckbox = document.getElementById('terms');
    const confirmButton = document.getElementById('confirm-booking');
    
    termsCheckbox.addEventListener('change', function() {
        confirmButton.disabled = !this.checked;
    });
    
    // Initialiser l'état du bouton
    confirmButton.disabled = !termsCheckbox.checked;
    
    // Gestion des boutons mois précédent/suivant
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');
    
    prevMonthBtn.addEventListener('click', function() {
        alert('Fonctionnalité de navigation entre les mois à implémenter');
    });
    
    nextMonthBtn.addEventListener('click', function() {
        alert('Fonctionnalité de navigation entre les mois à implémenter');
    });
});
</script>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>