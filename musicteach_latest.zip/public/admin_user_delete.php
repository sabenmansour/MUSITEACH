<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Vérifier si l'ID de l'utilisateur est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Utilisateur non trouvé.');
    redirect('admin_users.php');
}

$userId = (int)$_GET['id'];

// Empêcher la suppression de son propre compte
if ($userId === (int)$_SESSION['user_id']) {
    setFlashMessage('error', 'Vous ne pouvez pas supprimer votre propre compte.');
    redirect('admin_users.php');
}

// Récupérer l'utilisateur
$user = User::findById($userId);

// Vérifier si l'utilisateur existe
if (!$user) {
    setFlashMessage('error', 'Utilisateur non trouvé.');
    redirect('admin_users.php');
}

// Supprimer le profil associé (la suppression de l'utilisateur supprimera automatiquement le profil grâce à la contrainte ON DELETE CASCADE)
try {
    // Supprimer l'utilisateur
    if (User::delete($userId)) {
        setFlashMessage('success', 'L\'utilisateur a été supprimé avec succès.');
    } else {
        setFlashMessage('error', 'Une erreur est survenue lors de la suppression de l\'utilisateur.');
    }
} catch (Exception $e) {
    setFlashMessage('error', 'Une erreur est survenue lors de la suppression de l\'utilisateur.');
}

// Rediriger vers la liste des utilisateurs
redirect('admin_users.php');