<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Vérifier si l'ID du professeur est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Professeur non trouvé.');
    redirect('teachers.php');
}

$teacherId = (int)$_GET['id'];

// Récupérer les informations du professeur
$teacher = User::findById($teacherId);

// Vérifier si le professeur existe et est bien un professeur
if (!$teacher || $teacher['role'] !== 'teacher') {
    setFlashMessage('error', 'Professeur non trouvé.');
    redirect('teachers.php');
}

// Récupérer le profil du professeur
$profile = Profile::findByUserId($teacherId);

// Titre de la page
$pageTitle = "Profil de " . $teacher['name'];

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row mb-5">
        <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                    <li class="breadcrumb-item"><a href="teachers.php">Professeurs</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($teacher['name']) ?></li>
                </ol>
            </nav>
        </div>
    </div>
    
    <div class="row">
        <!-- Photo et informations du professeur -->
        <div class="col-lg-4 mb-4" data-aos="fade-right">
            <div class="card teacher-profile h-100">
                <div class="text-center p-4">
                    <div class="position-relative mx-auto mb-4">
                        <img src="/resources/img/teacher-placeholder.jpg" alt="<?= htmlspecialchars($teacher['name']) ?>" 
                             class="teacher-avatar">
                        <?php if (isset($profile['verified']) && $profile['verified']): ?>
                            <span class="position-absolute bottom-0 end-0 badge bg-success p-2 border border-white border-3 rounded-circle">
                                <i class="fas fa-check"></i>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <h2 class="mb-2"><?= htmlspecialchars($teacher['name']) ?></h2>
                    
                    <?php if (isset($profile['instrument']) && !empty($profile['instrument'])): ?>
                        <div class="mb-3">
                            <span class="badge bg-primary px-3 py-2 rounded-pill"><?= htmlspecialchars($profile['instrument']) ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="teacher-rating mb-3">
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star text-warning"></i>
                        <i class="fas fa-star-half-alt text-warning"></i>
                        <span class="ms-2 fw-bold">4.8</span>
                        <span class="text-muted">(24 avis)</span>
                    </div>
                    
                    <?php if (isset($profile['location']) && !empty($profile['location'])): ?>
                        <p class="mb-3">
                            <i class="fas fa-map-marker-alt me-2 text-muted"></i>
                            <?= htmlspecialchars($profile['location']) ?>
                        </p>
                    <?php endif; ?>
                    
                    <div class="teacher-stats d-flex justify-content-center text-center mt-4 mb-4">
                        <div class="px-3">
                            <div class="h4 mb-0">150+</div>
                            <div class="small text-muted">Cours donnés</div>
                        </div>
                        <div class="px-3 border-start border-end">
                            <div class="h4 mb-0">3</div>
                            <div class="small text-muted">Années d'exp.</div>
                        </div>
                        <div class="px-3">
                            <div class="h4 mb-0">45</div>
                            <div class="small text-muted">Élèves</div>
                        </div>
                    </div>
                    
                    <?php if (isLoggedIn() && !isTeacher()): ?>
                        <a href="booking.php?teacher_id=<?= $teacher['id'] ?>" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-calendar-plus me-2"></i>Réserver un cours
                        </a>
                    <?php elseif (!isLoggedIn()): ?>
                        <a href="login.php" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-sign-in-alt me-2"></i>Connectez-vous pour réserver
                        </a>
                    <?php endif; ?>
                </div>
                
                <!-- Informations de contact et tarifs -->
                <div class="card-footer p-4">
                    <h5 class="mb-3">Informations pratiques</h5>
                    
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0 text-center me-3" style="width: 40px;">
                            <i class="fas fa-euro-sign text-primary fa-fw fa-lg"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold">Tarif horaire</div>
                            <div><?= isset($profile['hourly_rate']) ? htmlspecialchars($profile['hourly_rate']) . ' €/heure' : '30-45 €/heure' ?></div>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0 text-center me-3" style="width: 40px;">
                            <i class="fas fa-graduation-cap text-primary fa-fw fa-lg"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold">Niveaux enseignés</div>
                            <div><?= isset($profile['levels']) ? htmlspecialchars($profile['levels']) : 'Débutant, Intermédiaire, Avancé' ?></div>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0 text-center me-3" style="width: 40px;">
                            <i class="fas fa-users text-primary fa-fw fa-lg"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold">Types de cours</div>
                            <div><?= isset($profile['lesson_types']) ? htmlspecialchars($profile['lesson_types']) : 'En présentiel, En ligne' ?></div>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0 text-center me-3" style="width: 40px;">
                            <i class="fas fa-language text-primary fa-fw fa-lg"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold">Langues parlées</div>
                            <div><?= isset($profile['languages']) ? htmlspecialchars($profile['languages']) : 'Français, Anglais' ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Description, expérience et disponibilités -->
        <div class="col-lg-8" data-aos="fade-left">
            <!-- À propos -->
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h3 class="card-title mb-4">À propos de moi</h3>
                    <div class="card-text">
                        <?php if (isset($profile['description']) && !empty($profile['description'])): ?>
                            <p><?= nl2br(htmlspecialchars($profile['description'])) ?></p>
                        <?php else: ?>
                            <p>Je suis un professeur passionné par l'enseignement de la musique. Mon approche pédagogique est centrée sur l'élève, avec un équilibre entre technique et plaisir de jouer. Je m'adapte au niveau et aux objectifs de chacun pour proposer un apprentissage sur mesure.</p>
                            <p>Que vous soyez débutant ou musicien confirmé, je serais ravi de vous accompagner dans votre parcours musical. N'hésitez pas à me contacter pour plus d'informations ou pour réserver un premier cours.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Expérience et formation -->
            <div class="card mb-4">
                <div class="card-body p-4">
                    <h3 class="card-title mb-4">Expérience et formation</h3>
                    
                    <?php if (isset($profile['experience']) && !empty($profile['experience'])): ?>
                        <div class="card-text">
                            <?= nl2br(htmlspecialchars($profile['experience'])) ?>
                        </div>
                    <?php else: ?>
                        <div class="timeline">
                            <div class="timeline-item mb-4">
                                <div class="d-flex mb-2">
                                    <div class="flex-shrink-0">
                                        <span class="badge bg-primary rounded-pill p-2"><i class="fas fa-briefcase"></i></span>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="mb-1">Professeur de musique indépendant</h5>
                                        <div class="text-muted">2020 - Aujourd'hui</div>
                                    </div>
                                </div>
                                <p>Cours particuliers pour élèves de tous niveaux. Développement de programmes personnalisés adaptés aux objectifs de chaque élève.</p>
                            </div>
                            
                            <div class="timeline-item mb-4">
                                <div class="d-flex mb-2">
                                    <div class="flex-shrink-0">
                                        <span class="badge bg-primary rounded-pill p-2"><i class="fas fa-music"></i></span>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="mb-1">École de musique municipale</h5>
                                        <div class="text-muted">2018 - 2020</div>
                                    </div>
                                </div>
                                <p>Enseignement en groupe et cours individuels. Organisation de représentations et de concerts d'élèves.</p>
                            </div>
                            
                            <div class="timeline-item">
                                <div class="d-flex mb-2">
                                    <div class="flex-shrink-0">
                                        <span class="badge bg-primary rounded-pill p-2"><i class="fas fa-graduation-cap"></i></span>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="mb-1">Conservatoire National Supérieur de Musique</h5>
                                        <div class="text-muted">2014 - 2018</div>
                                    </div>
                                </div>
                                <p>Diplôme d'études musicales spécialisation performance et pédagogie. Formation complète incluant théorie musicale, histoire de la musique et techniques d'enseignement.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Calendrier de disponibilités -->
            <div class="card">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h3 class="card-title mb-0">Disponibilités</h3>
                        <?php if (isLoggedIn() && !isTeacher()): ?>
                            <a href="booking.php?teacher_id=<?= $teacher['id'] ?>" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-plus me-2"></i>Réserver un créneau
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="calendar">
                        <div class="calendar-header mb-4">
                            <button class="btn btn-outline-primary" id="prev-month"><i class="fas fa-chevron-left"></i></button>
                            <h5 class="mb-0 mx-3">Avril 2025</h5>
                            <button class="btn btn-outline-primary" id="next-month"><i class="fas fa-chevron-right"></i></button>
                        </div>
                        
                        <div class="calendar-days">
                            <!-- Noms des jours de la semaine -->
                            <div class="fw-bold">Lun</div>
                            <div class="fw-bold">Mar</div>
                            <div class="fw-bold">Mer</div>
                            <div class="fw-bold">Jeu</div>
                            <div class="fw-bold">Ven</div>
                            <div class="fw-bold">Sam</div>
                            <div class="fw-bold">Dim</div>
                            
                            <!-- Jours du mois (exemple) -->
                            <div></div>
                            <div></div>
                            <div class="calendar-day">1</div>
                            <div class="calendar-day">2</div>
                            <div class="calendar-day">3</div>
                            <div class="calendar-day">4</div>
                            <div class="calendar-day">5</div>
                            
                            <div class="calendar-day">6</div>
                            <div class="calendar-day">7</div>
                            <div class="calendar-day">8</div>
                            <div class="calendar-day">9</div>
                            <div class="calendar-day">10</div>
                            <div class="calendar-day active">11</div>
                            <div class="calendar-day">12</div>
                            
                            <div class="calendar-day">13</div>
                            <div class="calendar-day">14</div>
                            <div class="calendar-day">15</div>
                            <div class="calendar-day">16</div>
                            <div class="calendar-day">17</div>
                            <div class="calendar-day">18</div>
                            <div class="calendar-day">19</div>
                            
                            <div class="calendar-day">20</div>
                            <div class="calendar-day">21</div>
                            <div class="calendar-day">22</div>
                            <div class="calendar-day active">23</div>
                            <div class="calendar-day">24</div>
                            <div class="calendar-day">25</div>
                            <div class="calendar-day">26</div>
                            
                            <div class="calendar-day">27</div>
                            <div class="calendar-day">28</div>
                            <div class="calendar-day">29</div>
                            <div class="calendar-day">30</div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        
                        <div class="mt-4">
                            <p class="mb-1"><i class="fas fa-circle text-primary me-2" style="font-size: 0.8em;"></i> <span class="fw-bold">Dates disponibles</span> - Cliquez pour voir les horaires</p>
                            
                            <div id="selected-date" class="mt-4 d-none">
                                <h5 class="mb-3">Horaires disponibles le <span id="selected-date-display">11 avril</span></h5>
                                <div class="row" id="time-slots">
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="time-slot">
                                            <i class="far fa-clock me-2"></i> 09:00
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="time-slot unavailable">
                                            <i class="far fa-clock me-2"></i> 10:00
                                            <span class="badge bg-secondary ms-1">Réservé</span>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="time-slot">
                                            <i class="far fa-clock me-2"></i> 11:00
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="time-slot">
                                            <i class="far fa-clock me-2"></i> 14:00
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="time-slot unavailable">
                                            <i class="far fa-clock me-2"></i> 15:00
                                            <span class="badge bg-secondary ms-1">Réservé</span>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="time-slot">
                                            <i class="far fa-clock me-2"></i> 16:00
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if (isLoggedIn() && !isTeacher()): ?>
                                    <div class="mt-3">
                                        <a href="booking.php?teacher_id=<?= $teacher['id'] ?>" class="btn btn-primary">
                                            Réserver un cours
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Avis des élèves -->
            <div class="card mt-4">
                <div class="card-body p-4">
                    <h3 class="card-title mb-4">Avis des élèves</h3>
                    
                    <div class="review-item mb-4 pb-4 border-bottom">
                        <div class="d-flex mb-3">
                            <img src="/resources/img/user-placeholder.jpg" alt="Julie D." class="rounded-circle me-3" width="50" height="50">
                            <div>
                                <h5 class="mb-1">Julie D.</h5>
                                <div class="mb-2">
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <span class="ms-2 text-muted">Il y a 2 semaines</span>
                                </div>
                            </div>
                        </div>
                        <p>Un excellent professeur qui sait s'adapter au niveau de l'élève. Les cours sont bien structurés et sa pédagogie est remarquable. Je recommande vivement !</p>
                    </div>
                    
                    <div class="review-item mb-4 pb-4 border-bottom">
                        <div class="d-flex mb-3">
                            <img src="/resources/img/user-placeholder.jpg" alt="Thomas L." class="rounded-circle me-3" width="50" height="50">
                            <div>
                                <h5 class="mb-1">Thomas L.</h5>
                                <div class="mb-2">
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="far fa-star text-warning"></i>
                                    <span class="ms-2 text-muted">Il y a 1 mois</span>
                                </div>
                            </div>
                        </div>
                        <p>J'ai beaucoup progressé grâce à ses conseils et sa méthode d'enseignement. Les exercices sont adaptés à mon niveau et il est très patient.</p>
                    </div>
                    
                    <div class="review-item">
                        <div class="d-flex mb-3">
                            <img src="/resources/img/user-placeholder.jpg" alt="Émilie F." class="rounded-circle me-3" width="50" height="50">
                            <div>
                                <h5 class="mb-1">Émilie F.</h5>
                                <div class="mb-2">
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star text-warning"></i>
                                    <i class="fas fa-star-half-alt text-warning"></i>
                                    <span class="ms-2 text-muted">Il y a 2 mois</span>
                                </div>
                            </div>
                        </div>
                        <p>Professeur dynamique et motivant qui m'a donné envie de progresser. Ses explications sont claires et il prend le temps de corriger chaque erreur. Je suis très satisfaite de ses cours.</p>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="#" class="btn btn-outline-primary">Voir tous les avis</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gestion du calendrier
    const calendarDays = document.querySelectorAll('.calendar-day');
    const selectedDate = document.getElementById('selected-date');
    const selectedDateDisplay = document.getElementById('selected-date-display');
    
    calendarDays.forEach(function(day) {
        day.addEventListener('click', function() {
            // Supprimer la classe active de tous les jours
            calendarDays.forEach(function(d) {
                d.classList.remove('active');
            });
            
            // Ajouter la classe active au jour cliqué
            day.classList.add('active');
            
            // Afficher la section des horaires
            selectedDate.classList.remove('d-none');
            
            // Mettre à jour le texte de la date sélectionnée
            const dayNum = day.textContent;
            selectedDateDisplay.textContent = dayNum + ' avril';
            
            // Faire défiler jusqu'aux horaires
            selectedDate.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
    });
    
    // Gestion des boutons mois précédent/suivant
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');
    
    prevMonthBtn.addEventListener('click', function() {
        alert('Fonctionnalité de navigation entre les mois à implémenter');
    });
    
    nextMonthBtn.addEventListener('click', function() {
        alert('Fonctionnalité de navigation entre les mois à implémenter');
    });
    
    // Gestion des créneaux horaires
    const timeSlots = document.querySelectorAll('.time-slot:not(.unavailable)');
    
    timeSlots.forEach(function(slot) {
        slot.addEventListener('click', function() {
            // Supprimer la classe selected de tous les créneaux
            timeSlots.forEach(function(s) {
                s.classList.remove('selected');
            });
            
            // Ajouter la classe selected au créneau cliqué
            slot.classList.add('selected');
        });
    });
});
</script>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>