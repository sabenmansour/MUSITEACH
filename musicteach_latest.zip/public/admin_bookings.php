<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Booking.php';
require_once __DIR__ . '/../app/db_connect.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Paramètres de pagination
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 20; // Nombre de réservations par page

// Paramètres de filtrage
$where = [];
$params = [];

// Filtre par statut
if (isset($_GET['status']) && in_array($_GET['status'], ['pending', 'confirmed', 'canceled'])) {
    $where[] = "b.status = :status";
    $params['status'] = $_GET['status'];
}

// Filtre par date
if (isset($_GET['date']) && !empty($_GET['date'])) {
    $where[] = "DATE(b.date) = :date";
    $params['date'] = $_GET['date'];
}

// Filtre par professeur
if (isset($_GET['teacher_id']) && is_numeric($_GET['teacher_id'])) {
    $where[] = "b.teacher_id = :teacher_id";
    $params['teacher_id'] = (int)$_GET['teacher_id'];
}

// Filtre par élève
if (isset($_GET['student_id']) && is_numeric($_GET['student_id'])) {
    $where[] = "b.student_id = :student_id";
    $params['student_id'] = (int)$_GET['student_id'];
}

// Construire la clause WHERE
$whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

// Récupérer les réservations
$db = getDbConnection();
$offset = ($page - 1) * $perPage;

$sql = "
    SELECT b.*, 
    t.name as teacher_name, 
    s.name as student_name 
    FROM bookings b
    JOIN users t ON b.teacher_id = t.id
    JOIN users s ON b.student_id = s.id
    $whereClause
    ORDER BY b.date DESC
    LIMIT :offset, :limit
";

$stmt = $db->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);

foreach ($params as $key => $value) {
    $stmt->bindValue(':' . $key, $value);
}

$stmt->execute();
$bookings = $stmt->fetchAll();

// Compter le nombre total de réservations (pour la pagination)
$countSql = "
    SELECT COUNT(*) 
    FROM bookings b
    JOIN users t ON b.teacher_id = t.id
    JOIN users s ON b.student_id = s.id
    $whereClause
";

$countStmt = $db->prepare($countSql);
foreach ($params as $key => $value) {
    $countStmt->bindValue(':' . $key, $value);
}
$countStmt->execute();
$totalBookings = $countStmt->fetchColumn();
$totalPages = ceil($totalBookings / $perPage);

// Récupérer la liste des professeurs pour le filtre
$teachersStmt = $db->prepare("SELECT id, name FROM users WHERE role = 'teacher' ORDER BY name");
$teachersStmt->execute();
$teachers = $teachersStmt->fetchAll();

// Titre de la page
$pageTitle = "Gestion des réservations";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Administration - Gestion des réservations</h1>
    
    <!-- Actions rapides -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Actions rapides</h5>
                    <div class="d-flex gap-2">
                        <a href="admin_dashboard.php" class="btn btn-outline-primary">
                            <i class="fas fa-tachometer-alt me-2"></i>Tableau de bord
                        </a>
                        <a href="admin_users.php" class="btn btn-outline-primary">
                            <i class="fas fa-users me-2"></i>Utilisateurs
                        </a>
                        <a href="admin_bookings.php" class="btn btn-primary">
                            <i class="fas fa-calendar-alt me-2"></i>Réservations
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Liste des réservations -->
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="card-title mb-0">Liste des réservations</h5>
            </div>
            
            <!-- Formulaire de filtrage -->
            <form action="admin_bookings.php" method="get" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label for="status" class="form-label">Statut</label>
                        <select name="status" id="status" class="form-select">
                            <option value="">Tous les statuts</option>
                            <option value="pending" <?= isset($_GET['status']) && $_GET['status'] === 'pending' ? 'selected' : '' ?>>En attente</option>
                            <option value="confirmed" <?= isset($_GET['status']) && $_GET['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmé</option>
                            <option value="canceled" <?= isset($_GET['status']) && $_GET['status'] === 'canceled' ? 'selected' : '' ?>>Annulé</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="date" class="form-label">Date</label>
                        <input type="date" name="date" id="date" class="form-control" 
                               value="<?= isset($_GET['date']) ? htmlspecialchars($_GET['date']) : '' ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="teacher_id" class="form-label">Professeur</label>
                        <select name="teacher_id" id="teacher_id" class="form-select">
                            <option value="">Tous les professeurs</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?= $teacher['id'] ?>" <?= isset($_GET['teacher_id']) && $_GET['teacher_id'] == $teacher['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($teacher['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">Filtrer</button>
                    </div>
                </div>
            </form>
            
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Professeur</th>
                            <th>Élève</th>
                            <th>Statut</th>
                            <th>Créée le</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?= $booking['id'] ?></td>
                                <td><?= formatDate($booking['date']) ?></td>
                                <td>
                                    <a href="admin_user_edit.php?id=<?= $booking['teacher_id'] ?>">
                                        <?= htmlspecialchars($booking['teacher_name']) ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="admin_user_edit.php?id=<?= $booking['student_id'] ?>">
                                        <?= htmlspecialchars($booking['student_name']) ?>
                                    </a>
                                </td>
                                <td>
                                    <?php
                                    switch ($booking['status']) {
                                        case 'pending':
                                            echo '<span class="badge bg-warning">En attente</span>';
                                            break;
                                        case 'confirmed':
                                            echo '<span class="badge bg-success">Confirmé</span>';
                                            break;
                                        case 'canceled':
                                            echo '<span class="badge bg-danger">Annulé</span>';
                                            break;
                                    }
                                    ?>
                                </td>
                                <td><?= formatDate($booking['created_at']) ?></td>
                                <td>
                                    <div class="btn-group">
                                        <?php if ($booking['status'] === 'pending'): ?>
                                            <a href="admin_booking_confirm.php?id=<?= $booking['id'] ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($booking['status'] !== 'canceled'): ?>
                                            <a href="admin_booking_cancel.php?id=<?= $booking['id'] ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ?');">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <?php if (empty($bookings)): ?>
                            <tr>
                                <td colspan="7" class="text-center">Aucune réservation trouvée.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?= generatePagination($page, $totalPages, 'admin_bookings.php?page=%d' . 
                        (isset($_GET['status']) ? '&status=' . htmlspecialchars($_GET['status']) : '') . 
                        (isset($_GET['date']) ? '&date=' . htmlspecialchars($_GET['date']) : '') . 
                        (isset($_GET['teacher_id']) ? '&teacher_id=' . htmlspecialchars($_GET['teacher_id']) : '')
                    ) ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>