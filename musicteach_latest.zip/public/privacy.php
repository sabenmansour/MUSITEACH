<?php
// Titre de la page
$pageTitle = "Politique de confidentialité";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="mb-4">Politique de Confidentialité</h1>
            <p class="text-muted">Dernière mise à jour : <?= date('d/m/Y') ?></p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">1. Introduction</h3>
                    <p>Chez MusiTeach, nous accordons une grande importance à la protection de votre vie privée. Cette Politique de Confidentialité explique comment nous collectons, utilisons, divulguons et protégeons vos informations personnelles lorsque vous utilisez notre site web et nos services (collectivement désignés comme "le Service").</p>
                    <p>En utilisant le Service, vous consentez à la collecte et à l'utilisation de vos informations conformément à cette politique. Si vous n'acceptez pas cette politique, veuillez ne pas utiliser notre Service.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">2. Informations que nous collectons</h3>
                    <h5>2.1 Informations personnelles</h5>
                    <p>Nous pouvons collecter les informations personnelles suivantes :</p>
                    <ul>
                        <li><strong>Informations d'identification</strong> : nom, prénom, adresse e-mail, numéro de téléphone, photo de profil.</li>
                        <li><strong>Informations de compte</strong> : nom d'utilisateur, mot de passe (stocké de manière sécurisée).</li>
                        <li><strong>Informations de profil</strong> : pour les professeurs, cela peut inclure leur expérience, qualifications, instruments enseignés, tarifs et disponibilités.</li>
                        <li><strong>Informations de paiement</strong> : nous ne stockons pas directement vos informations de paiement complètes. Ces données sont traitées par nos prestataires de paiement sécurisés.</li>
                    </ul>
                    
                    <h5>2.2 Informations de navigation</h5>
                    <p>Nous collectons automatiquement certaines informations lorsque vous utilisez notre Service, notamment :</p>
                    <ul>
                        <li>Adresse IP</li>
                        <li>Type et version de navigateur</li>
                        <li>Système d'exploitation</li>
                        <li>Pages visitées et interactions avec ces pages</li>
                        <li>Date et heure de votre visite</li>
                        <li>Temps passé sur certaines pages</li>
                    </ul>
                    
                    <h5>2.3 Cookies et technologies similaires</h5>
                    <p>Nous utilisons des cookies et des technologies similaires pour collecter des informations sur votre activité, votre navigateur et votre appareil. Vous pouvez gérer vos préférences de cookies via les paramètres de votre navigateur.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">3. Utilisation des informations</h3>
                    <p>Nous utilisons les informations collectées pour :</p>
                    <ul>
                        <li>Fournir, maintenir et améliorer notre Service</li>
                        <li>Créer et gérer votre compte</li>
                        <li>Traiter les réservations et les paiements</li>
                        <li>Faciliter la communication entre élèves et professeurs</li>
                        <li>Vous envoyer des notifications importantes concernant votre compte ou nos services</li>
                        <li>Vous envoyer des communications marketing (avec votre consentement)</li>
                        <li>Analyser l'utilisation de notre service pour l'améliorer</li>
                        <li>Détecter, prévenir et résoudre les problèmes techniques ou de sécurité</li>
                        <li>Se conformer aux obligations légales</li>
                    </ul>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">4. Partage des informations</h3>
                    <p>Nous pouvons partager vos informations personnelles dans les situations suivantes :</p>
                    <ul>
                        <li><strong>Entre utilisateurs</strong> : Les professeurs et les élèves ont accès à certaines informations les uns des autres pour faciliter les réservations de cours et la communication.</li>
                        <li><strong>Prestataires de services</strong> : Nous partageons vos informations avec des prestataires de services tiers qui nous aident à fournir notre Service (hébergement, paiement, analyse, e-mail, etc.).</li>
                        <li><strong>Obligations légales</strong> : Nous pouvons divulguer vos informations si la loi l'exige ou en réponse à des demandes légales valides.</li>
                        <li><strong>Transfert d'entreprise</strong> : En cas de fusion, acquisition ou vente d'actifs, vos informations personnelles peuvent faire partie des actifs transférés.</li>
                        <li><strong>Avec votre consentement</strong> : Nous pouvons partager vos informations dans toute autre situation avec votre consentement explicite.</li>
                    </ul>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">5. Sécurité des données</h3>
                    <p>Nous mettons en œuvre des mesures de sécurité techniques et organisationnelles appropriées pour protéger vos informations personnelles contre la perte, l'accès non autorisé, la divulgation, l'altération et la destruction. Cependant, aucune méthode de transmission sur Internet ou méthode de stockage électronique n'est totalement sécurisée, et nous ne pouvons garantir une sécurité absolue.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">6. Conservation des données</h3>
                    <p>Nous conserverons vos informations personnelles aussi longtemps que nécessaire pour fournir notre Service et atteindre les objectifs définis dans cette Politique de Confidentialité, sauf si une période de conservation plus longue est requise ou permise par la loi.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">7. Vos droits</h3>
                    <p>Selon votre lieu de résidence, vous pouvez disposer de certains droits concernant vos informations personnelles :</p>
                    <ul>
                        <li>Accès à vos informations personnelles</li>
                        <li>Rectification des informations inexactes</li>
                        <li>Suppression de vos informations personnelles</li>
                        <li>Restriction ou opposition au traitement</li>
                        <li>Portabilité des données</li>
                        <li>Retrait du consentement (lorsque le traitement est basé sur le consentement)</li>
                    </ul>
                    <p>Pour exercer ces droits, veuillez nous contacter via les coordonnées fournies à la fin de cette politique.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">8. Modifications de cette politique</h3>
                    <p>Nous pouvons mettre à jour cette Politique de Confidentialité de temps à autre. Nous vous informerons de tout changement significatif par e-mail ou par une notification sur notre Service. Nous vous encourageons à consulter régulièrement cette politique pour rester informé des modifications.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">9. Transferts internationaux de données</h3>
                    <p>Vos informations peuvent être transférées et traitées dans des pays autres que celui où vous résidez. Ces pays peuvent avoir des lois sur la protection des données différentes de celles de votre pays. Nous prenons des mesures appropriées pour garantir que vos données bénéficient d'un niveau de protection adéquat, conformément à cette Politique de Confidentialité.</p>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">10. Nous contacter</h3>
                    <p>Si vous avez des questions, des préoccupations ou des demandes concernant cette Politique de Confidentialité ou le traitement de vos informations personnelles, veuillez nous contacter à :</p>
                    <p><strong>E-mail</strong> : privacy@musicteach.com</p>
                    <p><strong>Adresse postale</strong> : MusiTeach, 123 Avenue de la Musique, 75000 Paris, France</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>