<?php
require_once __DIR__ . '/../db_connect.php';

class Booking {
    /**
     * Récupérer une réservation par son ID
     */
    public static function findById($id) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM bookings WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
    
    /**
     * Créer une nouvelle réservation
     */
    public static function create($teacherId, $studentId, $date, $status = 'pending') {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "INSERT INTO bookings (teacher_id, student_id, date, status, created_at, updated_at) 
             VALUES (:teacher_id, :student_id, :date, :status, NOW(), NOW())"
        );
        
        $stmt->execute([
            'teacher_id' => $teacherId,
            'student_id' => $studentId,
            'date' => $date,
            'status' => $status
        ]);
        
        return $db->lastInsertId();
    }
    
    /**
     * Mettre à jour une réservation
     */
    public static function update($id, $data) {
        $db = getDbConnection();
        
        $allowedFields = ['date', 'status'];
        $fields = [];
        $params = ['id' => $id];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $fields[] = "$key = :$key";
                $params[$key] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $sql = "UPDATE bookings SET " . implode(', ', $fields) . " WHERE id = :id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }
    
    /**
     * Supprimer une réservation
     */
    public static function delete($id) {
        $db = getDbConnection();
        $stmt = $db->prepare("DELETE FROM bookings WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    /**
     * Récupérer les réservations d'un professeur
     */
    public static function findByTeacher($teacherId, $page = 1, $perPage = 10) {
        $db = getDbConnection();
        $offset = ($page - 1) * $perPage;
        
        $stmt = $db->prepare(
            "SELECT b.*, u.name as student_name, u.email as student_email
             FROM bookings b
             JOIN users u ON b.student_id = u.id
             WHERE b.teacher_id = :teacher_id
             ORDER BY b.date DESC
             LIMIT :offset, :limit"
        );
        
        $stmt->bindValue(':teacher_id', $teacherId, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Récupérer les réservations d'un étudiant
     */
    public static function findByStudent($studentId, $page = 1, $perPage = 10) {
        $db = getDbConnection();
        $offset = ($page - 1) * $perPage;
        
        $stmt = $db->prepare(
            "SELECT b.*, u.name as teacher_name, u.email as teacher_email
             FROM bookings b
             JOIN users u ON b.teacher_id = u.id
             WHERE b.student_id = :student_id
             ORDER BY b.date DESC
             LIMIT :offset, :limit"
        );
        
        $stmt->bindValue(':student_id', $studentId, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Compter le nombre total de réservations d'un professeur
     */
    public static function countByTeacher($teacherId) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT COUNT(*) FROM bookings WHERE teacher_id = :teacher_id");
        $stmt->execute(['teacher_id' => $teacherId]);
        return $stmt->fetchColumn();
    }
    
    /**
     * Compter le nombre total de réservations d'un étudiant
     */
    public static function countByStudent($studentId) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT COUNT(*) FROM bookings WHERE student_id = :student_id");
        $stmt->execute(['student_id' => $studentId]);
        return $stmt->fetchColumn();
    }
    
    /**
     * Vérifier la disponibilité d'un professeur à une date donnée
     */
    public static function isTeacherAvailable($teacherId, $date) {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM bookings 
             WHERE teacher_id = :teacher_id 
             AND date = :date 
             AND status != 'canceled'"
        );
        
        $stmt->execute([
            'teacher_id' => $teacherId,
            'date' => $date
        ]);
        
        return $stmt->fetchColumn() === 0;
    }
}