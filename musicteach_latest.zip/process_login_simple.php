<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

// Fonction de redirection
function redirect($url) {
    header("Location: $url");
    exit;
}

// Fonction flash message
function setFlashMessage($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}

// Fonction de validation CSRF
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && $_SESSION['csrf_token'] === $token;
}

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('login.php');
}

// Vérifier le token CSRF (simplifié)
if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
    setFlashMessage('danger', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
    redirect('login.php');
}

// Récupérer les données du formulaire
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']) ? (bool)$_POST['remember'] : false;

// Stocker l'email en session pour remplir à nouveau le champ en cas d'erreur
$_SESSION['login_email'] = $email;

// Valider les données
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($password)) {
    setFlashMessage('danger', 'Veuillez saisir une adresse email et un mot de passe valides.');
    redirect('login.php');
}

// Connexion à la base de données
try {
    $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    $pdo = new PDO($dsn, 'musicteach', 'musicteach', $options);
    
    // Récupérer l'utilisateur
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();
    
    // Vérifier si l'utilisateur existe et si le mot de passe est correct
    if (!$user || !password_verify($password, $user['password'])) {
        setFlashMessage('danger', 'Adresse email ou mot de passe incorrect.');
        redirect('login.php');
    }
    
    // Authentifier l'utilisateur
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['logged_in'] = true;
    
    // Regenerer l'ID de session
    session_regenerate_id(true);
    
    // Nettoyer l'email stocké en session
    unset($_SESSION['login_email']);
    
    // Si "Se souvenir de moi" est coché, créer un cookie
    if ($remember) {
        $token = bin2hex(random_bytes(32));
        $expiry = time() + (30 * 24 * 60 * 60); // 30 jours
        
        // Stocker le token en base de données
        $stmt = $pdo->prepare("
            INSERT INTO remember_tokens (user_id, token, expiry) 
            VALUES (:user_id, :token, FROM_UNIXTIME(:expiry))
        ");
        
        $stmt->execute([
            'user_id' => $user['id'],
            'token' => $token,
            'expiry' => $expiry
        ]);
        
        // Créer le cookie
        setcookie(
            'remember_token',
            $token,
            [
                'expires' => $expiry,
                'path' => '/',
                'domain' => '',
                'secure' => true,
                'httponly' => true,
                'samesite' => 'Lax'
            ]
        );
    }
    
    // Rediriger vers le tableau de bord
    setFlashMessage('success', 'Connexion réussie. Bienvenue, ' . htmlspecialchars($user['name']) . ' !');
    redirect('dashboard.php');
    
} catch (PDOException $e) {
    setFlashMessage('danger', 'Une erreur est survenue lors de la connexion à la base de données.');
    if (defined('DEBUG') && DEBUG) {
        error_log("Erreur PDO: " . $e->getMessage());
    }
    redirect('login.php');
}