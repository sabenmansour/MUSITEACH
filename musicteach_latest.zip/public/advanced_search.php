<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';
require_once __DIR__ . '/../app/models/Instrument.php';
require_once __DIR__ . '/../app/db_connect.php';

// Paramètres de recherche
$searchQuery = isset($_GET['q']) ? sanitizeInput($_GET['q']) : '';
$instrumentId = isset($_GET['instrument']) && is_numeric($_GET['instrument']) ? (int)$_GET['instrument'] : null;
$category = isset($_GET['category']) ? sanitizeInput($_GET['category']) : null;
$level = isset($_GET['level']) ? sanitizeInput($_GET['level']) : null;
$distance = isset($_GET['distance']) && is_numeric($_GET['distance']) ? (int)$_GET['distance'] : null;
$zipCode = isset($_GET['zip']) ? sanitizeInput($_GET['zip']) : null;

// Pagination
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 12;

// Construire la requête de recherche
$db = getDbConnection();
$whereClause = ["u.role = 'teacher'"]; // Uniquement les professeurs
$params = [];

// Recherche par nom ou description
if (!empty($searchQuery)) {
    $whereClause[] = "(u.name LIKE :query OR p.description LIKE :query OR p.instrument LIKE :query)";
    $params['query'] = '%' . $searchQuery . '%';
}

// Filtre par instrument (utilise la table teacher_instruments si disponible)
if ($instrumentId) {
    // Vérifie si la table teacher_instruments existe
    $stmt = $db->prepare("SHOW TABLES LIKE 'teacher_instruments'");
    $stmt->execute();
    $tableExists = $stmt->fetchColumn();
    
    if ($tableExists) {
        $fromClause = "FROM users u 
                      LEFT JOIN profiles p ON u.id = p.user_id
                      JOIN teacher_instruments ti ON u.id = ti.teacher_id";
        $whereClause[] = "ti.instrument_id = :instrument_id";
        $params['instrument_id'] = $instrumentId;
    } else {
        // Fallback: recherche dans le champ instrument du profil
        $fromClause = "FROM users u LEFT JOIN profiles p ON u.id = p.user_id";
        $instrumentInfo = Instrument::findById($instrumentId);
        if ($instrumentInfo) {
            $whereClause[] = "p.instrument LIKE :instrument_name";
            $params['instrument_name'] = '%' . $instrumentInfo['name'] . '%';
        }
    }
} else {
    $fromClause = "FROM users u LEFT JOIN profiles p ON u.id = p.user_id";
}

// Filtre par catégorie d'instrument
if ($category && !$instrumentId) {
    // Vérifie si la table teacher_instruments existe
    $stmt = $db->prepare("SHOW TABLES LIKE 'teacher_instruments'");
    $stmt->execute();
    $tableExists = $stmt->fetchColumn();
    
    if ($tableExists) {
        $fromClause = "FROM users u 
                      LEFT JOIN profiles p ON u.id = p.user_id
                      JOIN teacher_instruments ti ON u.id = ti.teacher_id
                      JOIN instruments i ON ti.instrument_id = i.id";
        $whereClause[] = "i.category = :category";
        $params['category'] = $category;
    } else {
        // Sans la table des instruments, on ne peut pas filtrer par catégorie efficacement
        // On pourrait implémenter une recherche textuelle mais ce serait moins précis
    }
}

// Filtre par niveau (débutant, intermédiaire, avancé)
if ($level && isset($_GET['instrument'])) {
    // Vérifie si la table teacher_instruments existe
    $stmt = $db->prepare("SHOW TABLES LIKE 'teacher_instruments'");
    $stmt->execute();
    $tableExists = $stmt->fetchColumn();
    
    if ($tableExists) {
        $whereClause[] = "(ti.level = :level OR ti.level = 'all')";
        $params['level'] = $level;
    }
}

// Filtre par distance/code postal (fonctionnalité avancée à implémenter ultérieurement)
// Nécessiterait une table avec les coordonnées géographiques ou une API externe

// Construire la requête SQL complète
$where = !empty($whereClause) ? "WHERE " . implode(" AND ", $whereClause) : "";
$limit = "LIMIT " . (($page - 1) * $perPage) . ", " . $perPage;

// Récupérer les professeurs
$sql = "SELECT DISTINCT u.*, p.description, p.instrument, p.experience $fromClause $where ORDER BY u.name $limit";
$stmt = $db->prepare($sql);
foreach ($params as $key => $value) {
    $stmt->bindValue(':' . $key, $value);
}
$stmt->execute();
$teachers = $stmt->fetchAll();

// Compter le nombre total de résultats
$countSql = "SELECT COUNT(DISTINCT u.id) $fromClause $where";
$countStmt = $db->prepare($countSql);
foreach ($params as $key => $value) {
    $countStmt->bindValue(':' . $key, $value);
}
$countStmt->execute();
$totalTeachers = $countStmt->fetchColumn();
$totalPages = ceil($totalTeachers / $perPage);

// Récupérer les instruments pour le filtre
$stmt = $db->prepare("SHOW TABLES LIKE 'instruments'");
$stmt->execute();
$hasInstrumentsTable = $stmt->fetchColumn();

if ($hasInstrumentsTable) {
    $instruments = Instrument::findAll();
    $categories = Instrument::getAllCategories();
} else {
    $instruments = [];
    $categories = [];
}

// Titre de la page
$pageTitle = "Recherche avancée de professeurs";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<!-- Section de recherche avancée -->
<section class="bg-light py-5">
    <div class="container">
        <h1 class="text-center mb-4">Recherche avancée de professeurs</h1>
        
        <div class="card mb-4">
            <div class="card-body">
                <form action="advanced_search.php" method="get">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="q" class="form-label">Recherche par nom ou mot-clé</label>
                            <input type="text" class="form-control" id="q" name="q" placeholder="Ex: piano, classique, jazz..."
                                   value="<?= htmlspecialchars($searchQuery) ?>">
                        </div>
                        
                        <?php if (!empty($instruments)): ?>
                            <div class="col-md-4">
                                <label for="instrument" class="form-label">Instrument</label>
                                <select class="form-select" id="instrument" name="instrument">
                                    <option value="">Tous les instruments</option>
                                    <?php foreach ($instruments as $instrument): ?>
                                        <option value="<?= $instrument['id'] ?>" <?= $instrumentId == $instrument['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($instrument['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($categories)): ?>
                            <div class="col-md-4">
                                <label for="category" class="form-label">Catégorie</label>
                                <select class="form-select" id="category" name="category">
                                    <option value="">Toutes les catégories</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?= $cat ?>" <?= $category == $cat ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($cat) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                        
                        <div class="col-md-4">
                            <label for="level" class="form-label">Niveau</label>
                            <select class="form-select" id="level" name="level">
                                <option value="">Tous les niveaux</option>
                                <option value="beginner" <?= $level == 'beginner' ? 'selected' : '' ?>>Débutant</option>
                                <option value="intermediate" <?= $level == 'intermediate' ? 'selected' : '' ?>>Intermédiaire</option>
                                <option value="advanced" <?= $level == 'advanced' ? 'selected' : '' ?>>Avancé</option>
                                <option value="all" <?= $level == 'all' ? 'selected' : '' ?>>Tous niveaux</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Rechercher</button>
                            <a href="advanced_search.php" class="btn btn-outline-secondary ms-2">Réinitialiser</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Liste des professeurs -->
<section class="py-5">
    <div class="container">
        <h2 class="mb-4">
            Résultats de recherche
            <?php if ($totalTeachers > 0): ?>
                <small class="text-muted">(<?= $totalTeachers ?> professeur<?= $totalTeachers > 1 ? 's' : '' ?> trouvé<?= $totalTeachers > 1 ? 's' : '' ?>)</small>
            <?php endif; ?>
        </h2>
        
        <?php if (empty($teachers)): ?>
            <div class="alert alert-info">
                Aucun professeur ne correspond à votre recherche. Veuillez essayer avec d'autres critères.
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($teachers as $teacher): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="/resources/img/teacher-placeholder.jpg" class="card-img-top" alt="<?= htmlspecialchars($teacher['name']) ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($teacher['name']) ?></h5>
                                
                                <?php if (isset($teacher['instrument']) && !empty($teacher['instrument'])): ?>
                                    <p class="card-text">
                                        <span class="badge bg-primary mb-2"><?= htmlspecialchars($teacher['instrument']) ?></span>
                                    </p>
                                <?php endif; ?>
                                
                                <p class="card-text">
                                    <?= isset($teacher['description']) && !empty($teacher['description']) 
                                        ? htmlspecialchars(substr($teacher['description'], 0, 100)) . '...' 
                                        : 'Professeur de musique passionné prêt à partager son savoir.' ?>
                                </p>
                                
                                <a href="profile.php?id=<?= $teacher['id'] ?>" class="btn btn-primary">Voir le profil</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="d-flex justify-content-center mt-4">
                    <nav aria-label="Pagination">
                        <ul class="pagination">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>&q=<?= urlencode($searchQuery) ?>&instrument=<?= $instrumentId ?>&category=<?= urlencode($category) ?>&level=<?= urlencode($level) ?>">
                                        Précédent
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Précédent</span>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <?php if ($i === $page): ?>
                                        <span class="page-link"><?= $i ?></span>
                                    <?php else: ?>
                                        <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($searchQuery) ?>&instrument=<?= $instrumentId ?>&category=<?= urlencode($category) ?>&level=<?= urlencode($level) ?>">
                                            <?= $i ?>
                                        </a>
                                    <?php endif; ?>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>&q=<?= urlencode($searchQuery) ?>&instrument=<?= $instrumentId ?>&category=<?= urlencode($category) ?>&level=<?= urlencode($level) ?>">
                                        Suivant
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Suivant</span>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>