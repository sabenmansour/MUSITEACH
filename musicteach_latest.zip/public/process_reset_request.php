<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/db_connect.php';

// Démarrer la session
startSession();

// Rediriger si déjà connecté
if (isLoggedIn()) {
    redirect('dashboard.php');
}

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('reset_password.php');
}

// Vérifier le token CSRF
if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
    setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
    redirect('reset_password.php');
}

// Récupérer et nettoyer l'email
$email = sanitizeInput($_POST['email'] ?? '');

// Stocker l'email en session pour remplir à nouveau le champ en cas d'erreur
$_SESSION['reset_email'] = $email;

// Valider l'email
if (empty($email) || !isValidEmail($email)) {
    setFlashMessage('error', 'Veuillez saisir une adresse email valide.');
    redirect('reset_password.php');
}

// Vérifier si l'utilisateur existe
$user = User::findByEmail($email);

if (!$user) {
    // Pour des raisons de sécurité, nous ne révélons pas si l'email existe ou non
    setFlashMessage('success', 'Si cette adresse email existe dans notre système, vous recevrez un lien de réinitialisation du mot de passe.');
    redirect('login.php');
}

// Générer un token unique
$token = bin2hex(random_bytes(32));
$expiry = date('Y-m-d H:i:s', strtotime('+1 hour')); // Expiration après 1 heure

// Stocker le token dans la base de données
try {
    $db = getDbConnection();
    
    // Vérifier si la table password_resets existe
    $stmt = $db->prepare("SHOW TABLES LIKE 'password_resets'");
    $stmt->execute();
    $tableExists = $stmt->fetchColumn();
    
    // Créer la table si elle n'existe pas
    if (!$tableExists) {
        $db->exec("
            CREATE TABLE password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) NOT NULL,
                token VARCHAR(100) NOT NULL,
                expiry DATETIME NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX(email),
                INDEX(token)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }
    
    // Supprimer les anciens tokens pour cet email
    $stmt = $db->prepare("DELETE FROM password_resets WHERE email = :email");
    $stmt->execute(['email' => $email]);
    
    // Insérer le nouveau token
    $stmt = $db->prepare("
        INSERT INTO password_resets (email, token, expiry) 
        VALUES (:email, :token, :expiry)
    ");
    $stmt->execute([
        'email' => $email,
        'token' => $token,
        'expiry' => $expiry
    ]);
    
    // Envoi d'email (en condition réelle)
    // En phase de développement, nous affichons simplement le lien
    if (DEBUG) {
        // Uniquement en mode développement
        $resetLink = APP_URL . "/reset_password.php?token=" . $token;
        setFlashMessage('info', "Lien de réinitialisation (pour développement uniquement) : <a href=\"$resetLink\">$resetLink</a>");
    } else {
        // En production, nous enverrions un email
        /*
        $to = $email;
        $subject = "Réinitialisation de votre mot de passe - " . APP_NAME;
        
        $resetLink = APP_URL . "/reset_password.php?token=" . $token;
        
        $message = "
        <html>
        <body>
            <h2>Réinitialisation de votre mot de passe</h2>
            <p>Bonjour,</p>
            <p>Vous recevez cet email car nous avons reçu une demande de réinitialisation de mot de passe pour votre compte.</p>
            <p>Veuillez cliquer sur le lien ci-dessous pour réinitialiser votre mot de passe :</p>
            <p><a href=\"$resetLink\">Réinitialiser mon mot de passe</a></p>
            <p>Ce lien expirera dans 1 heure.</p>
            <p>Si vous n'avez pas demandé de réinitialisation de mot de passe, aucune action n'est requise.</p>
            <p>Cordialement,<br>L'équipe " . APP_NAME . "</p>
        </body>
        </html>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: " . MAIL_FROM . "\r\n";
        
        mail($to, $subject, $message, $headers);
        */
        
        // Pour l'instant, simulons un envoi réussi
    }
    
    setFlashMessage('success', 'Si cette adresse email existe dans notre système, vous recevrez un lien de réinitialisation du mot de passe.');
    
} catch (Exception $e) {
    setFlashMessage('error', 'Une erreur est survenue lors de la demande de réinitialisation. Veuillez réessayer.');
    if (DEBUG) {
        setFlashMessage('error', 'Erreur : ' . $e->getMessage());
    }
}

// Nettoyer la session
unset($_SESSION['reset_email']);

// Rediriger vers la page de connexion
redirect('login.php');