#!/bin/bash

# Obtenir l'ID du conteneur webserver
WEBSERVER=$(docker ps | grep musicteach_webserver | awk '{print $1}')
if [ -z "$WEBSERVER" ]; then
    echo "Le conteneur webserver n'est pas en cours d'exécution"
    exit 1
fi

# Créer un fichier db_connect ultra simplifié
cat > /home/fennec/PROJECTS/MUSICTEACH/db_connect_ultra_simple.php << 'EOF'
<?php
/**
 * Connexion à la base de données avec PDO uniquement
 * Version ultra simple sans dépendances externes
 */

function getDbConnection() {
    try {
        // Paramètres de connexion codés en dur pour le dépannage
        $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
        $user = "musicteach";
        $pass = "musicteach";
        
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        
        $pdo = new PDO($dsn, $user, $pass, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Afficher l'erreur en clair pour le débogage
        die("Erreur de connexion à la base de données : " . $e->getMessage());
    }
}
EOF

# Copier le fichier dans le conteneur
docker cp /home/fennec/PROJECTS/MUSICTEACH/db_connect_ultra_simple.php ${WEBSERVER}:/var/www/html/app/db_connect.php
echo "Fichier de connexion ultra simple copié dans le conteneur"

# Créer une page d'accueil simplifiée
cat > /home/fennec/PROJECTS/MUSICTEACH/index_simple.php << 'EOF'
<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Titre de la page
$pageTitle = "Accueil";

// Pas de récupération de professeurs pour le moment
$featuredTeachers = [];

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container text-center">
        <h1>Trouvez le prof de musique parfait en quelques clics</h1>
        <p class="mx-auto">Cours particuliers avec des professeurs qualifiés, en présentiel ou en ligne, pour tous niveaux et tous instruments.</p>
        <a href="teachers.php" class="btn btn-primary btn-lg">Découvrir les professeurs</a>
    </div>
</section>

<!-- Comment ça marche -->
<section class="how-it-works my-5">
    <div class="container">
        <h2 class="text-center mb-5">Comment ça marche ?</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="text-center feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3>Recherchez</h3>
                    <p>Trouvez facilement le professeur de musique idéal parmi nos nombreux profils vérifiés.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="text-center feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <h3>Réservez</h3>
                    <p>Choisissez une date et un horaire qui vous conviennent et réservez votre cours en quelques clics.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="text-center feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-music"></i>
                    </div>
                    <h3>Apprenez</h3>
                    <p>Profitez de cours de qualité et progressez à votre rythme avec un suivi personnalisé.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>
EOF

# Copier la page d'accueil simplifiée
docker cp /home/fennec/PROJECTS/MUSICTEACH/index_simple.php ${WEBSERVER}:/var/www/html/public/index.php
echo "Page d'accueil simplifiée copiée dans le conteneur"

# Créer une page de test PDO
cat > /home/fennec/PROJECTS/MUSICTEACH/pdo_test.php << 'EOF'
<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo '<h1>Test de connexion PDO à la base de données</h1>';

// Extensions PHP
echo '<h2>Extensions PHP chargées</h2>';
echo '<pre>';
print_r(get_loaded_extensions());
echo '</pre>';

// Test de connexion PDO directe
echo '<h2>Test de connexion PDO directe</h2>';
try {
    $dsn = 'mysql:host=mysql;dbname=musicteach;charset=utf8mb4';
    $pdo = new PDO($dsn, 'musicteach', 'musicteach');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo '<p style="color:green">Connexion directe réussie!</p>';
    
    // Lister les tables
    $stmt = $pdo->query('SHOW TABLES');
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo '<h3>Tables dans la base de données:</h3>';
    echo '<ul>';
    foreach ($tables as $table) {
        echo '<li>' . $table . '</li>';
    }
    echo '</ul>';
} catch (PDOException $e) {
    echo '<p style="color:red">Erreur de connexion PDO: ' . $e->getMessage() . '</p>';
}
EOF

# Copier la page de test PDO
docker cp /home/fennec/PROJECTS/MUSICTEACH/pdo_test.php ${WEBSERVER}:/var/www/html/public/pdo_test.php
echo "Page de test PDO copiée dans le conteneur"

echo "Accédez maintenant à http://localhost:8000/pdo_test.php pour vérifier si PDO fonctionne correctement"