<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo '<h1>Test de fonctionnement de base</h1>';

// Vérifier si la session fonctionne
session_start();
echo '<h2>Session</h2>';
echo '<p>Session ID: ' . session_id() . '</p>';

// Vérifier les fonctions de base
echo '<h2>Fonctions de base</h2>';
echo '<ul>';
echo '<li>PHP version: ' . phpversion() . '</li>';
echo '<li>Session fonctionne: ' . (session_status() === PHP_SESSION_ACTIVE ? 'Oui' : 'Non') . '</li>';
echo '<li>password_hash disponible: ' . (function_exists('password_hash') ? 'Oui' : 'Non') . '</li>';
echo '</ul>';

// Vérifier si PDO est disponible
echo '<h2>PDO</h2>';
if (class_exists('PDO')) {
    echo '<p style="color:green">PDO est disponible</p>';
    echo '<p>Drivers PDO disponibles: ' . implode(', ', PDO::getAvailableDrivers()) . '</p>';
} else {
    echo '<p style="color:red">PDO n\'est pas disponible</p>';
}

// Tester la connexion à la base de données
echo '<h2>Test de connexion à la base de données</h2>';
try {
    $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
    $user = "musicteach";
    $pass = "musicteach";
    
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo '<p style="color:green">Connexion réussie à la base de données</p>';
    
    // Vérifier les tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo '<h3>Tables dans la base de données:</h3>';
    echo '<ul>';
    foreach ($tables as $table) {
        echo '<li>' . htmlspecialchars($table) . '</li>';
    }
    echo '</ul>';
    
} catch (PDOException $e) {
    echo '<p style="color:red">Erreur de connexion: ' . htmlspecialchars($e->getMessage()) . '</p>';
}

// Afficher le chemin du fichier actuel
echo '<h2>Informations système</h2>';
echo '<p>Chemin du fichier: ' . __FILE__ . '</p>';
echo '<p>Document Root: ' . $_SERVER['DOCUMENT_ROOT'] . '</p>';
echo '<p>URI: ' . $_SERVER['REQUEST_URI'] . '</p>';
?>