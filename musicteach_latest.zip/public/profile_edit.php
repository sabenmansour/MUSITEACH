<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Vérifier si l'utilisateur est connecté
requireLogin();

// Récupérer les informations de l'utilisateur
$user = User::findById($_SESSION['user_id']);
$profile = Profile::findByUserId($_SESSION['user_id']);

// Traitement du formulaire si soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
        redirect('profile_edit.php');
    }
    
    // Récupérer et nettoyer les données du formulaire
    $name = sanitizeInput($_POST['name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $instrument = sanitizeInput($_POST['instrument'] ?? '');
    $experience = sanitizeInput($_POST['experience'] ?? '');
    
    // Validation
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Le nom est requis.';
    }
    
    if (empty($email) || !isValidEmail($email)) {
        $errors[] = 'L\'adresse email est invalide.';
    } elseif (User::emailExists($email, $_SESSION['user_id'])) {
        $errors[] = 'Cette adresse email est déjà utilisée par un autre utilisateur.';
    }
    
    // S'il y a des erreurs, afficher un message d'erreur
    if (!empty($errors)) {
        setFlashMessage('error', implode(' ', $errors));
    } else {
        // Mettre à jour l'utilisateur
        try {
            $userData = [
                'name' => $name,
                'email' => $email
            ];
            
            if (User::update($_SESSION['user_id'], $userData)) {
                // Mettre à jour la session
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                
                // Mettre à jour le profil
                $profileData = [
                    'description' => $description
                ];
                
                if (isTeacher()) {
                    $profileData['instrument'] = $instrument;
                    $profileData['experience'] = $experience;
                }
                
                Profile::createOrUpdate($_SESSION['user_id'], $profileData);
                
                setFlashMessage('success', 'Votre profil a été mis à jour avec succès.');
                redirect('dashboard.php');
            } else {
                setFlashMessage('error', 'Une erreur est survenue lors de la mise à jour de votre profil.');
            }
        } catch (Exception $e) {
            setFlashMessage('error', 'Une erreur est survenue lors de la mise à jour de votre profil.');
        }
    }
}

// Titre de la page
$pageTitle = "Modifier mon profil";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Modifier mon profil</h1>
    
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <img src="/resources/img/user-placeholder.jpg" alt="<?= htmlspecialchars($user['name']) ?>" 
                             class="img-fluid rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
                    </div>
                    <h4 class="card-title text-center"><?= htmlspecialchars($user['name']) ?></h4>
                    <p class="text-center text-muted">
                        <?= $user['role'] === 'student' ? 'Élève' : ($user['role'] === 'teacher' ? 'Professeur' : 'Administrateur') ?>
                    </p>
                    
                    <div class="d-grid gap-2 mt-4">
                        <a href="change_password.php" class="btn btn-outline-primary">Changer mon mot de passe</a>
                        <a href="dashboard.php" class="btn btn-secondary">Retour au tableau de bord</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Informations personnelles</h5>
                    
                    <form action="profile_edit.php" method="post">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="update_profile" value="1">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Nom complet</label>
                            <input type="text" class="form-control" id="name" name="name" required 
                                   value="<?= htmlspecialchars($user['name']) ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Adresse email</label>
                            <input type="email" class="form-control" id="email" name="email" required 
                                   value="<?= htmlspecialchars($user['email']) ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">À propos de moi</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?= isset($profile['description']) ? htmlspecialchars($profile['description']) : '' ?></textarea>
                        </div>
                        
                        <?php if (isTeacher()): ?>
                            <div class="mb-3">
                                <label for="instrument" class="form-label">Instrument(s) enseigné(s)</label>
                                <input type="text" class="form-control" id="instrument" name="instrument" 
                                       value="<?= isset($profile['instrument']) ? htmlspecialchars($profile['instrument']) : '' ?>">
                                <div class="form-text">Vous pouvez séparer plusieurs instruments par des virgules.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="experience" class="form-label">Expérience</label>
                                <textarea class="form-control" id="experience" name="experience" rows="3"><?= isset($profile['experience']) ? htmlspecialchars($profile['experience']) : '' ?></textarea>
                                <div class="form-text">Détaillez votre expérience en tant que musicien et enseignant.</div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>