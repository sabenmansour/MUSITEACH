# Guide d'Installation de MusiTeach

Ce document détaille les étapes nécessaires pour installer et configurer l'application MusiTeach sur différents environnements.

## Prérequis

- PHP 7.4 ou supérieur
- MariaDB 10.3+ ou MySQL 5.7+
- Serveur web (Apache ou Nginx)
- Modules PHP requis:
  - PDO et PDO_MySQL
  - mbstring
  - json
  - session

## Installation en environnement de développement

### 1. Préparation du système

#### Pour Debian/Ubuntu:
```bash
sudo apt update
sudo apt install apache2 php php-mysql php-mbstring php-json mariadb-server git
```

#### Pour CentOS/RHEL:
```bash
sudo yum install httpd php php-mysql php-mbstring php-json mariadb-server git
```

#### Pour macOS (avec Homebrew):
```bash
brew install php mysql apache
```

#### Pour Windows:
Installez XAMPP ou WampServer qui incluent tous les composants nécessaires.

### 2. Configuration de la base de données

1. Connexion au serveur MariaDB/MySQL:
```bash
sudo mysql -u root -p
```

2. Création de la base de données et de l'utilisateur:
```sql
CREATE DATABASE musicteach CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'musicteach'@'localhost' IDENTIFIED BY 'votre_mot_de_passe';
GRANT ALL PRIVILEGES ON musicteach.* TO 'musicteach'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 3. Récupération du code source

1. Cloner le dépôt:
```bash
git clone <url-du-dépôt> musicteach
cd musicteach
```

### 4. Configuration de l'application

1. Copier et modifier le fichier de configuration:
```bash
cp app/config.php.example app/config.php
```

2. Éditez `app/config.php` pour configurer l'accès à la base de données:
```php
// Informations de connexion à la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'musicteach');
define('DB_USER', 'musicteach');
define('DB_PASS', 'votre_mot_de_passe');
```

### 5. Initialisation de la base de données

1. Importer le schéma principal:
```bash
mysql -u musicteach -p musicteach < database/schema.sql
```

2. Importer les données des instruments (optionnel):
```bash
mysql -u musicteach -p musicteach < database/instruments.sql
```

### 6. Configuration du serveur web

#### Pour Apache:

1. Créez un VirtualHost:
```apache
<VirtualHost *:80>
    ServerName musicteach.local
    DocumentRoot /chemin/vers/musicteach/public
    
    <Directory /chemin/vers/musicteach/public>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/musicteach_error.log
    CustomLog ${APACHE_LOG_DIR}/musicteach_access.log combined
</VirtualHost>
```

2. Activez le module rewrite:
```bash
sudo a2enmod rewrite
```

3. Redémarrez Apache:
```bash
sudo systemctl restart apache2
```

#### Pour Nginx:

1. Créez un fichier de configuration:
```nginx
server {
    listen 80;
    server_name musicteach.local;
    root /chemin/vers/musicteach/public;
    
    index index.php index.html;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
    }
    
    location ~ /\.ht {
        deny all;
    }
}
```

2. Redémarrez Nginx:
```bash
sudo systemctl restart nginx
```

### 7. Configuration du nom d'hôte local (optionnel)

Ajoutez cette ligne à votre fichier `/etc/hosts`:
```
127.0.0.1 musicteach.local
```

### 8. Création d'un compte administrateur

1. Accédez à l'application via votre navigateur (`http://musicteach.local` ou `http://localhost`)
2. Inscrivez-vous en créant un nouveau compte
3. Mettez à jour la base de données pour définir le rôle administrateur:
```bash
mysql -u musicteach -p musicteach
```
```sql
UPDATE users SET role = 'admin' WHERE email = 'votre_email@example.com';
EXIT;
```

## Installation en environnement de production

Pour un déploiement en production, suivez les mêmes étapes que pour le développement, mais avec quelques précautions supplémentaires:

1. Utilisez HTTPS avec un certificat SSL (Let's Encrypt est gratuit)
2. Désactivez le mode DEBUG dans `app/config.php`:
```php
define('DEBUG', false);
```
3. Choisissez un mot de passe fort pour la base de données
4. Configurez les permissions des fichiers de manière restrictive:
```bash
find /chemin/vers/musicteach -type f -exec chmod 644 {} \;
find /chemin/vers/musicteach -type d -exec chmod 755 {} \;
```
5. Assurez-vous que seul le dossier `public` est accessible depuis le web

## Dépannage

### Problèmes courants

1. **Erreur de connexion à la base de données**:
   - Vérifiez les paramètres dans `app/config.php`
   - Assurez-vous que le serveur MySQL/MariaDB est en cours d'exécution

2. **Erreur 404 pour toutes les pages**:
   - Vérifiez la configuration du VirtualHost/Server
   - Assurez-vous que le module rewrite est activé
   - Vérifiez les permissions des fichiers

3. **Erreur 500 Internal Server Error**:
   - Vérifiez les logs d'erreur du serveur web
   - Assurez-vous que les extensions PHP requises sont installées

## Support

Pour toute question supplémentaire, consultez notre documentation en ligne ou contactez l'équipe de développement à l'adresse support@musicteach.com.