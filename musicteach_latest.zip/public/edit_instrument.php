<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Instrument.php';
require_once __DIR__ . '/../app/models/TeacherInstrument.php';
require_once __DIR__ . '/../app/db_connect.php';

// Vérifier si l'utilisateur est connecté et est un professeur
requireLogin();
if (!isTeacher()) {
    setFlashMessage('error', 'Accès réservé aux professeurs.');
    redirect('dashboard.php');
}

$teacherId = $_SESSION['user_id'];

// Vérifier si l'ID de l'instrument est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Instrument non trouvé.');
    redirect('manage_instruments.php');
}

$instrumentId = (int)$_GET['id'];

// Vérifier si les tables nécessaires existent
$db = getDbConnection();
$stmt = $db->prepare("SHOW TABLES LIKE 'instruments'");
$stmt->execute();
$hasInstrumentsTable = $stmt->fetchColumn();

$stmt = $db->prepare("SHOW TABLES LIKE 'teacher_instruments'");
$stmt->execute();
$hasTeacherInstrumentsTable = $stmt->fetchColumn();

if (!$hasInstrumentsTable || !$hasTeacherInstrumentsTable) {
    setFlashMessage('error', 'La fonctionnalité de gestion des instruments n\'est pas disponible actuellement.');
    redirect('manage_instruments.php');
}

// Récupérer les informations de l'instrument du professeur
$stmt = $db->prepare(
    "SELECT ti.*, i.name as instrument_name, i.category as instrument_category
     FROM teacher_instruments ti
     JOIN instruments i ON ti.instrument_id = i.id
     WHERE ti.teacher_id = :teacher_id AND ti.instrument_id = :instrument_id"
);
$stmt->execute([
    'teacher_id' => $teacherId,
    'instrument_id' => $instrumentId
]);
$teacherInstrument = $stmt->fetch();

if (!$teacherInstrument) {
    setFlashMessage('error', 'Instrument non trouvé dans votre profil.');
    redirect('manage_instruments.php');
}

// Traitement du formulaire de mise à jour
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_instrument'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Une erreur de sécurité est survenue. Veuillez réessayer.';
    } else {
        $level = isset($_POST['level']) && in_array($_POST['level'], ['beginner', 'intermediate', 'advanced', 'all']) 
            ? $_POST['level'] 
            : 'all';
        
        $description = isset($_POST['description']) ? sanitizeInput($_POST['description']) : null;
        
        try {
            $result = TeacherInstrument::update($teacherId, $instrumentId, [
                'level' => $level,
                'description' => $description
            ]);
            
            if ($result) {
                setFlashMessage('success', 'Les informations de l\'instrument ont été mises à jour avec succès.');
                redirect('manage_instruments.php');
            } else {
                $error = 'Une erreur est survenue lors de la mise à jour de l\'instrument.';
            }
        } catch (Exception $e) {
            $error = 'Une erreur est survenue : ' . $e->getMessage();
        }
    }
}

// Titre de la page
$pageTitle = "Modifier l'instrument";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Modifier l'instrument</h1>
    
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <?= htmlspecialchars($teacherInstrument['instrument_name']) ?>
                        <span class="badge bg-secondary ms-2"><?= htmlspecialchars($teacherInstrument['instrument_category']) ?></span>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger mb-3">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?= $error ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success mb-3">
                            <i class="fas fa-check-circle me-2"></i>
                            Les informations de l'instrument ont été mises à jour avec succès.
                        </div>
                    <?php endif; ?>
                    
                    <form action="edit_instrument.php?id=<?= $instrumentId ?>" method="post">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="update_instrument" value="1">
                        
                        <div class="mb-3">
                            <label for="level" class="form-label">Niveau d'enseignement</label>
                            <select class="form-select" id="level" name="level">
                                <option value="all" <?= $teacherInstrument['level'] === 'all' ? 'selected' : '' ?>>Tous niveaux</option>
                                <option value="beginner" <?= $teacherInstrument['level'] === 'beginner' ? 'selected' : '' ?>>Débutant</option>
                                <option value="intermediate" <?= $teacherInstrument['level'] === 'intermediate' ? 'selected' : '' ?>>Intermédiaire</option>
                                <option value="advanced" <?= $teacherInstrument['level'] === 'advanced' ? 'selected' : '' ?>>Avancé</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4" placeholder="Ex: Spécialisation en jazz, 10 ans d'enseignement..."><?= htmlspecialchars($teacherInstrument['description'] ?? '') ?></textarea>
                            <div class="form-text">
                                Décrivez votre expérience avec cet instrument, votre approche pédagogique, vos spécialités, etc.
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="manage_instruments.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Retour
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Enregistrer les modifications
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>