<?php
// Afficher toutes les erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclure les fichiers nécessaires
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Désactiver la vérification par email pour les tests
define('REQUIRE_EMAIL_VERIFICATION', false);

// Traiter le formulaire de création d'utilisateur
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'student';
    
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Le nom est requis.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'email est invalide.";
    } elseif (User::emailExists($email)) {
        $errors[] = "Cet email est déjà utilisé.";
    }
    
    if (empty($password) || strlen($password) < 8) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères.";
    }
    
    if (empty($errors)) {
        try {
            // Créer l'utilisateur
            $userId = User::create($name, $email, $password, $role);
            
            // Créer le profil de base
            Profile::create($userId, $role);
            
            $success = "Utilisateur créé avec succès ! Vous pouvez maintenant vous connecter.";
        } catch (Exception $e) {
            $errors[] = "Une erreur est survenue: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un utilisateur de test</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        h1 { color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input[type="text"], input[type="email"], input[type="password"] { width: 100%; padding: 8px; box-sizing: border-box; }
        button { background: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        .error { color: red; margin-bottom: 15px; }
        .success { color: green; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h1>Créer un utilisateur de test</h1>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if (isset($success)): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    
    <form method="post" action="test_create_user.php">
        <div class="form-group">
            <label for="name">Nom:</label>
            <input type="text" id="name" name="name" required value="<?= isset($name) ? htmlspecialchars($name) : '' ?>">
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required value="<?= isset($email) ? htmlspecialchars($email) : '' ?>">
        </div>
        
        <div class="form-group">
            <label for="password">Mot de passe:</label>
            <input type="password" id="password" name="password" required>
            <small>Le mot de passe doit contenir au moins 8 caractères.</small>
        </div>
        
        <div class="form-group">
            <label for="role">Rôle:</label>
            <select id="role" name="role">
                <option value="student" <?= (isset($role) && $role === 'student') ? 'selected' : '' ?>>Élève</option>
                <option value="teacher" <?= (isset($role) && $role === 'teacher') ? 'selected' : '' ?>>Professeur</option>
                <option value="admin" <?= (isset($role) && $role === 'admin') ? 'selected' : '' ?>>Administrateur</option>
            </select>
        </div>
        
        <button type="submit">Créer l'utilisateur</button>
    </form>
    
    <p><a href="test_login.php">Retour à la page de connexion</a></p>
</body>
</html>