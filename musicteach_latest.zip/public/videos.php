<?php
// Inclusion des fichiers nécessaires
$pageTitle = "Vidéos Pédagogiques";
include_once '../resources/views/header.php';
?>

<style>
/* Styles pour les différents modes d'affichage */
/* Mode carte (défaut) */
.view-cards .card {
    height: 100%;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.view-cards .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

/* Mode liste */
.view-list .card {
    height: auto;
    margin-bottom: 1rem;
}

.view-list .card-body {
    display: flex;
    flex-direction: row;
    align-items: center;
}

.view-list .card .ratio {
    width: 30%;
    min-width: 200px;
    margin-right: 1.5rem;
}

.view-list .card-title {
    margin-top: 0;
}

@media (max-width: 768px) {
    .view-list .card-body {
        flex-direction: column;
    }
    
    .view-list .card .ratio {
        width: 100%;
        margin-right: 0;
        margin-bottom: 1rem;
    }
}

/* Mode grille */
.view-grid .card {
    height: 100%;
    padding: 0.5rem;
}

.view-grid .card-body {
    padding: 0.75rem;
}

.view-grid .card-title {
    font-size: 1rem;
    margin-bottom: 0.5rem;
}

.view-grid .card-text {
    font-size: 0.85rem;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.view-grid .btn {
    padding: 0.25rem 0.5rem;
    font-size: 0.8rem;
}
</style>

<div class="container mt-5">
    <div class="row">
        <div class="col-12 text-center mb-5">
            <h1 class="display-4" data-aos="fade-up">Vidéos Pédagogiques</h1>
            <p class="lead" data-aos="fade-up" data-aos-delay="100">
                Découvrez notre sélection de vidéos pour apprendre la musique à votre rythme
            </p>
        </div>
    </div>
    
    <!-- Contrôles de visualisation -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-light" data-aos="fade-up">
                <div class="card-body d-flex flex-wrap justify-content-between align-items-center">
                    <div class="mb-2 mb-md-0">
                        <h5 class="card-title mb-0">Options d'affichage</h5>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <div class="btn-group" role="group" aria-label="Mode d'affichage">
                            <button type="button" class="btn btn-outline-primary view-mode-btn active" data-view="cards">
                                <i class="fas fa-th-large"></i> Cartes
                            </button>
                            <button type="button" class="btn btn-outline-primary view-mode-btn" data-view="list">
                                <i class="fas fa-list"></i> Liste
                            </button>
                            <button type="button" class="btn btn-outline-primary view-mode-btn" data-view="grid">
                                <i class="fas fa-th"></i> Grille
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Message d'instruction pour les onglets -->
    <div class="row mb-3">
        <div class="col-12">
            <div class="alert alert-light border text-center" data-aos="fade-up">
                <i class="fas fa-hand-point-down me-2"></i> <strong>Sélectionnez une catégorie ci-dessous pour naviguer entre les différentes sections de vidéos</strong>
            </div>
        </div>
    </div>

    <!-- Onglets de navigation -->
    <ul class="nav nav-tabs nav-fill mb-4" id="videoTabs" role="tablist" data-aos="fade-up" data-aos-delay="200">
        <li class="nav-item" role="presentation">
            <button class="nav-link active fw-bold py-3" id="introduction-tab" data-bs-toggle="tab" data-bs-target="#introduction" type="button" role="tab" aria-controls="introduction" aria-selected="true">
                <span class="badge bg-primary rounded-pill mb-2 d-block mx-auto">01</span>
                <i class="fas fa-music d-block mb-2 fa-lg"></i> 
                <span>Introduction à la musique</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link fw-bold py-3" id="solfege-tab" data-bs-toggle="tab" data-bs-target="#solfege" type="button" role="tab" aria-controls="solfege" aria-selected="false">
                <span class="badge bg-warning rounded-pill mb-2 d-block mx-auto">02</span>
                <i class="fas fa-book-open d-block mb-2 fa-lg"></i> 
                <span>Solfège</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link fw-bold py-3" id="instruments-tab" data-bs-toggle="tab" data-bs-target="#instruments" type="button" role="tab" aria-controls="instruments" aria-selected="false">
                <span class="badge bg-success rounded-pill mb-2 d-block mx-auto">03</span>
                <i class="fas fa-guitar d-block mb-2 fa-lg"></i> 
                <span>Par instrument</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link fw-bold py-3" id="decouverte-tab" data-bs-toggle="tab" data-bs-target="#decouverte" type="button" role="tab" aria-controls="decouverte" aria-selected="false">
                <span class="badge bg-info rounded-pill mb-2 d-block mx-auto">04</span>
                <i class="fas fa-globe d-block mb-2 fa-lg"></i> 
                <span>Découverte</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link fw-bold py-3" id="apprendre-seul-tab" data-bs-toggle="tab" data-bs-target="#apprendre-seul" type="button" role="tab" aria-controls="apprendre-seul" aria-selected="false">
                <span class="badge bg-danger rounded-pill mb-2 d-block mx-auto">05</span>
                <i class="fas fa-user-graduate d-block mb-2 fa-lg"></i> 
                <span>Apprendre Seul</span>
            </button>
        </li>
    </ul>

    <!-- Contenu des onglets -->
    <div class="tab-content" id="videoTabsContent">
        <!-- Introduction à la musique -->
        <div class="tab-pane fade show active" id="introduction" role="tabpanel" aria-labelledby="introduction-tab">
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="alert alert-primary">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <span class="badge bg-primary rounded-circle p-3">
                                    <i class="fas fa-music fa-2x"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h2 class="h3 mb-1" data-aos="fade-right">🎵 SECTION 1: Introduction au monde de la musique</h2>
                                <p class="mb-0" data-aos="fade-up">
                                    Découvrez pourquoi la musique est si importante pour notre bien-être, notre développement cognitif et notre épanouissement personnel.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- Vidéo 1 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/gU4Q0LpZ2g4" title="La puissance cachée de la musique" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">La puissance cachée de la musique et ses pouvoirs</h5>
                            <p class="card-text">Une conférence TEDx qui explore l'impact profond de la musique sur notre cerveau et notre bien-être.</p>
                            <a href="https://www.youtube.com/watch?v=gU4Q0LpZ2g4" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 2 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/3XFi6pA0QYM" title="Les bienfaits de la musique pour le cerveau" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Les bienfaits de la musique pour le cerveau</h5>
                            <p class="card-text">Le médecin Michel Cymes discute des effets positifs de la musique sur notre santé mentale et cognitive.</p>
                            <a href="https://www.youtube.com/watch?v=3XFi6pA0QYM" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 3 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="300">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/kJ5OwdLA5JM" title="18 bienfaits de la musique sur le cerveau" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">18 bienfaits de la musique sur le cerveau</h5>
                            <p class="card-text">Une vidéo qui détaille comment la musique influence positivement différentes fonctions cérébrales.</p>
                            <a href="https://www.youtube.com/watch?v=kJ5OwdLA5JM" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 4 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="400">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/LvjIi8dul68" title="Pourquoi jouer d'un instrument de musique est bon pour le cerveau" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Pourquoi jouer d'un instrument est bon pour le cerveau</h5>
                            <p class="card-text">Une exploration des avantages cognitifs liés à la pratique d'un instrument musical.</p>
                            <a href="https://www.youtube.com/watch?v=LvjIi8dul68" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 5 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="500">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/zAnkWarYO9U" title="Comment la musique facilite l'apprentissage" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Comment la musique facilite l'apprentissage</h5>
                            <p class="card-text">Une discussion sur la manière dont la musique peut aider à mieux apprendre et se concentrer.</p>
                            <a href="https://www.youtube.com/watch?v=zAnkWarYO9U" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Solfège -->
        <div class="tab-pane fade" id="solfege" role="tabpanel" aria-labelledby="solfege-tab">
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="alert alert-warning">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <span class="badge bg-warning rounded-circle p-3">
                                    <i class="fas fa-book-open fa-2x"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h2 class="h3 mb-1" data-aos="fade-right">🎼 SECTION 2: Solfège (théorie musicale)</h2>
                                <p class="mb-0" data-aos="fade-up">
                                    Découvrez les bases de la théorie musicale pour mieux comprendre et apprécier la musique.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- Vidéo 1 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/2MJXgF2yAxM" title="Cours de solfège débutant – Guitare Facile" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Cours de solfège débutant – Guitare Facile</h5>
                            <p class="card-text">Une introduction au solfège pour les guitaristes débutants.</p>
                            <a href="https://www.youtube.com/watch?v=2MJXgF2yAxM" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 2 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/vBo9Xyiee08" title="Apprendre à lire la musique (Notes, rythmes, clés…)" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Apprendre à lire la musique</h5>
                            <p class="card-text">Apprenez à lire les notes, les rythmes et à comprendre les clés musicales.</p>
                            <a href="https://www.youtube.com/watch?v=vBo9Xyiee08" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Regarder sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 3 -->
                <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="300">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Leçons de solfège (lecture rythmique)</h5>
                            <p class="card-text">Une playlist complète de leçons de solfège axées sur la lecture rythmique par Musiclic.</p>
                            <a href="https://www.youtube.com/playlist?list=PLvHLQqVrOVM1Y-8WkmY0z7kuC9M7xheHO" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la playlist
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Par instrument -->
        <div class="tab-pane fade" id="instruments" role="tabpanel" aria-labelledby="instruments-tab">
            <div class="row mb-4">
                <div class="col-12">
                    <div class="alert alert-success">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <span class="badge bg-success rounded-circle p-3">
                                    <i class="fas fa-guitar fa-2x"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h2 class="h3 mb-1" data-aos="fade-right">🎸 SECTION 3: Apprentissage par instrument</h2>
                                <p class="mb-0" data-aos="fade-up">
                                    Découvrez des tutoriels spécifiques à chaque instrument avec des progressions adaptées à chaque niveau.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Message pour sous-onglets instruments -->
            <div class="alert alert-light border text-center mb-4">
                <i class="fas fa-hand-point-down me-2"></i> <strong>Choisissez un instrument ci-dessous</strong>
            </div>
            
            <!-- Sous-onglets pour les instruments -->
            <ul class="nav nav-pills nav-justified mb-4" id="instrumentTabs" role="tablist">
                <li class="nav-item me-2" role="presentation">
                    <button class="nav-link active py-3" id="piano-tab" data-bs-toggle="pill" data-bs-target="#piano" type="button" role="tab" aria-controls="piano" aria-selected="true">
                        <i class="fas fa-piano me-2"></i> Piano
                    </button>
                </li>
                <li class="nav-item me-2" role="presentation">
                    <button class="nav-link py-3" id="guitare-tab" data-bs-toggle="pill" data-bs-target="#guitare" type="button" role="tab" aria-controls="guitare" aria-selected="false">
                        <i class="fas fa-guitar me-2"></i> Guitare
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link py-3" id="batterie-tab" data-bs-toggle="pill" data-bs-target="#batterie" type="button" role="tab" aria-controls="batterie" aria-selected="false">
                        <i class="fas fa-drum me-2"></i> Batterie
                    </button>
                </li>
            </ul>
            
            <!-- Contenu des sous-onglets -->
            <div class="tab-content" id="instrumentTabsContent">
                <!-- Piano -->
                <div class="tab-pane fade show active" id="piano" role="tabpanel" aria-labelledby="piano-tab">
                    <div class="row">
                        <div class="col-12 mb-4">
                            <h2 class="h3 mb-4" data-aos="fade-right">🎹 Piano</h2>
                            <p data-aos="fade-up">
                                Apprenez à jouer du piano avec ces ressources gratuites en français.
                            </p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <!-- Vidéo 1 -->
                        <div class="col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="100">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body">
                                    <h5 class="card-title">PianoFacile – Cours débutants en français</h5>
                                    <p class="card-text">Une chaîne YouTube dédiée à l'apprentissage du piano pour les débutants, avec des explications claires en français.</p>
                                    <a href="https://www.youtube.com/@PianoFacile/videos" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Voir la chaîne
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 2 -->
                        <div class="col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="200">
                            <div class="card h-100 shadow-sm">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/_7z8AAExF5c" title="Apprendre le piano sans solfège" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Apprendre le piano sans solfège</h5>
                                    <p class="card-text">Un tutoriel pour débuter au piano même sans connaissances en solfège.</p>
                                    <a href="https://www.youtube.com/watch?v=_7z8AAExF5c" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Regarder sur YouTube
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Guitare -->
                <div class="tab-pane fade" id="guitare" role="tabpanel" aria-labelledby="guitare-tab">
                    <div class="row">
                        <div class="col-12 mb-4">
                            <h2 class="h3 mb-4" data-aos="fade-right">🎸 Guitare</h2>
                            <p data-aos="fade-up">
                                Des ressources pour apprendre la guitare à votre rythme.
                            </p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <!-- Vidéo 1 -->
                        <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="100">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body">
                                    <h5 class="card-title">Cours de guitare débutant – MyGuitare</h5>
                                    <p class="card-text">Une chaîne complète de cours de guitare pour les débutants en français.</p>
                                    <a href="https://www.youtube.com/@MyGuitare/videos" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Voir la chaîne
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 2 -->
                        <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="200">
                            <div class="card h-100 shadow-sm">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/4GE-j-B_Kv0" title="Apprendre la guitare sans solfège" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Apprendre la guitare sans solfège</h5>
                                    <p class="card-text">Comment débuter à la guitare sans connaissances en théorie musicale.</p>
                                    <a href="https://www.youtube.com/watch?v=4GE-j-B_Kv0" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Regarder sur YouTube
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 3 -->
                        <div class="col-md-6 col-lg-4 mb-4" data-aos="zoom-in" data-aos-delay="300">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body">
                                    <h5 class="card-title">Tutos guitare acoustique & électrique</h5>
                                    <p class="card-text">Tonton Guitare propose des tutoriels pour guitare acoustique et électrique.</p>
                                    <a href="https://www.youtube.com/@TontonGuitare/videos" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Voir la chaîne
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Batterie -->
                <div class="tab-pane fade" id="batterie" role="tabpanel" aria-labelledby="batterie-tab">
                    <div class="row">
                        <div class="col-12 mb-4">
                            <h2 class="h3 mb-4" data-aos="fade-right">🥁 Batterie / Percussions</h2>
                            <p data-aos="fade-up">
                                Apprenez les percussions et la batterie avec ces ressources gratuites.
                            </p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <!-- Vidéo 1 -->
                        <div class="col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="100">
                            <div class="card h-100 shadow-sm">
                                <div class="card-body">
                                    <h5 class="card-title">Débuter la batterie – Batteur Débutant</h5>
                                    <p class="card-text">Une chaîne YouTube dédiée aux batteurs débutants avec des tutoriels en français.</p>
                                    <a href="https://www.youtube.com/@batteurdebutant/videos" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Voir la chaîne
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 2 -->
                        <div class="col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="200">
                            <div class="card h-100 shadow-sm">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/dopdcU4L5VE" title="Apprendre à jouer des rythmes simples" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Apprendre à jouer des rythmes simples</h5>
                                    <p class="card-text">Un tutoriel pour apprendre les rythmes de base à la batterie.</p>
                                    <a href="https://www.youtube.com/watch?v=dopdcU4L5VE" class="btn btn-primary" target="_blank">
                                        <i class="fab fa-youtube"></i> Regarder sur YouTube
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Découverte -->
        <div class="tab-pane fade" id="decouverte" role="tabpanel" aria-labelledby="decouverte-tab">
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="alert alert-info">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <span class="badge bg-info rounded-circle p-3">
                                    <i class="fas fa-globe fa-2x"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h2 class="h3 mb-1" data-aos="fade-right">🎻 SECTION 4: Découverte des instruments</h2>
                                <p class="mb-0" data-aos="fade-up">
                                    Explorez le monde des instruments de musique à travers ces vidéos éducatives.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- Vidéo 1 -->
                <div class="col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Les instruments de musique pour enfants (et débutants)</h5>
                            <p class="card-text">Une playlist de la Philharmonie des enfants pour découvrir les instruments de musique.</p>
                            <a href="https://www.youtube.com/playlist?list=PLCSXAA2kVDKDKilnIu58KHwCuC-4V0ehm" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la playlist
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéo 2 -->
                <div class="col-md-6 mb-4" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Découverte des instruments classiques</h5>
                            <p class="card-text">L'Orchestre Philharmonique de Radio France présente les instruments classiques.</p>
                            <a href="https://www.youtube.com/playlist?list=PLK2EXM1oGciPPK_d3Luv0W2XzryE8QJby" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la playlist
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Apprendre Seul -->
        <div class="tab-pane fade" id="apprendre-seul" role="tabpanel" aria-labelledby="apprendre-seul-tab">
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="alert alert-danger">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <span class="badge bg-danger rounded-circle p-3">
                                    <i class="fas fa-user-graduate fa-2x"></i>
                                </span>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h2 class="h3 mb-1" data-aos="fade-right">🎓 SECTION 5: Apprendre la musique à votre rythme</h2>
                                <p class="mb-0" data-aos="fade-up">
                                    Sélection de ressources gratuites en français pour apprendre à jouer d'un instrument par vous-même. 
                                    Ces vidéos sont idéales pour l'auto-apprentissage et vous permettent de progresser à votre propre rythme.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Filtres par instrument -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card bg-light" data-aos="fade-up">
                        <div class="card-body">
                            <h5 class="card-title mb-3"><i class="fas fa-filter me-2"></i> Filtrer les vidéos par instrument</h5>
                            <div class="alert alert-light border text-center mb-3">
                                <i class="fas fa-info-circle me-2"></i> Cliquez sur un instrument ci-dessous pour filtrer les vidéos
                            </div>
                            <div class="d-flex flex-wrap gap-2 justify-content-center">
                                <button class="btn btn-lg btn-outline-primary filter-btn active" data-filter="all">
                                    <i class="fas fa-border-all"></i> Tous les instruments
                                </button>
                                <button class="btn btn-lg btn-outline-primary filter-btn" data-filter="piano">
                                    <i class="fas fa-piano"></i> Piano
                                </button>
                                <button class="btn btn-lg btn-outline-primary filter-btn" data-filter="guitare">
                                    <i class="fas fa-guitar"></i> Guitare
                                </button>
                                <button class="btn btn-lg btn-outline-primary filter-btn" data-filter="batterie">
                                    <i class="fas fa-drum"></i> Batterie
                                </button>
                                <button class="btn btn-lg btn-outline-primary filter-btn" data-filter="chant">
                                    <i class="fas fa-microphone"></i> Chant
                                </button>
                                <button class="btn btn-lg btn-outline-primary filter-btn" data-filter="violon">
                                    <i class="fas fa-music"></i> Violon
                                </button>
                                <button class="btn btn-lg btn-outline-primary filter-btn" data-filter="flute">
                                    <i class="fas fa-music"></i> Flûte
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row video-grid">
                <!-- Piano -->
                <div class="col-md-6 col-lg-4 mb-4 video-item piano" data-aos="zoom-in">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/_7z8AAExF5c" title="Apprendre le piano sans solfège" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Piano</span>
                            <h5 class="card-title">Apprendre le piano sans solfège</h5>
                            <p class="card-text">Un tutoriel pour débuter au piano même sans connaissances en solfège par Paul Learning Music.</p>
                            <a href="https://www.youtube.com/watch?v=_7z8AAExF5c" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-4 mb-4 video-item piano" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Piano</span>
                            <h5 class="card-title">PianoFacile – Cours débutants en français</h5>
                            <p class="card-text">Une chaîne YouTube dédiée à l'apprentissage du piano pour les débutants, avec des explications claires en français.</p>
                            <a href="https://www.youtube.com/@PianoFacile/videos" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la chaîne
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Guitare -->
                <div class="col-md-6 col-lg-4 mb-4 video-item guitare" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/4GE-j-B_Kv0" title="Apprendre la guitare sans solfège" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Guitare</span>
                            <h5 class="card-title">Apprendre la guitare sans solfège</h5>
                            <p class="card-text">Comment débuter la guitare facilement sans connaissances en théorie musicale par HGuitare.</p>
                            <a href="https://www.youtube.com/watch?v=4GE-j-B_Kv0" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-4 mb-4 video-item guitare" data-aos="zoom-in" data-aos-delay="300">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Guitare</span>
                            <h5 class="card-title">Cours de guitare débutant – MyGuitare</h5>
                            <p class="card-text">Une chaîne complète de cours de guitare pour les débutants en français avec progression structurée.</p>
                            <a href="https://www.youtube.com/@MyGuitare/videos" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la chaîne
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-4 mb-4 video-item guitare" data-aos="zoom-in" data-aos-delay="400">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Guitare</span>
                            <h5 class="card-title">Tutos guitare acoustique & électrique</h5>
                            <p class="card-text">Tonton Guitare propose des tutoriels pour guitare acoustique et électrique pour tous niveaux.</p>
                            <a href="https://www.youtube.com/@TontonGuitare/videos" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la chaîne
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Batterie -->
                <div class="col-md-6 col-lg-4 mb-4 video-item batterie" data-aos="zoom-in" data-aos-delay="500">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Batterie</span>
                            <h5 class="card-title">Débuter la batterie – Batteur Débutant</h5>
                            <p class="card-text">Une chaîne YouTube dédiée aux batteurs débutants avec des tutoriels en français, parfaite pour l'auto-apprentissage.</p>
                            <a href="https://www.youtube.com/@batteurdebutant/videos" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir la chaîne
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-4 mb-4 video-item batterie" data-aos="zoom-in" data-aos-delay="600">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/dopdcU4L5VE" title="Apprendre à jouer des rythmes simples" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <span class="badge bg-primary mb-2">Batterie</span>
                            <h5 class="card-title">Apprendre à jouer des rythmes simples</h5>
                            <p class="card-text">Un tutoriel pour apprendre les rythmes de base à la batterie par Drumsandco.</p>
                            <a href="https://www.youtube.com/watch?v=dopdcU4L5VE" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Solfège -->
                <div class="col-md-6 col-lg-4 mb-4 video-item solfege" data-aos="zoom-in" data-aos-delay="700">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/2MJXgF2yAxM" title="Cours de solfège débutant" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <span class="badge bg-info mb-2">Solfège</span>
                            <h5 class="card-title">Cours de solfège débutant – Guitare Facile</h5>
                            <p class="card-text">Une introduction au solfège pour les guitaristes débutants avec explications claires.</p>
                            <a href="https://www.youtube.com/watch?v=2MJXgF2yAxM" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-4 mb-4 video-item solfege" data-aos="zoom-in" data-aos-delay="800">
                    <div class="card h-100 shadow-sm">
                        <div class="ratio ratio-16x9">
                            <iframe src="https://www.youtube.com/embed/vBo9Xyiee08" title="Apprendre à lire la musique" allowfullscreen></iframe>
                        </div>
                        <div class="card-body">
                            <span class="badge bg-info mb-2">Solfège</span>
                            <h5 class="card-title">Apprendre à lire la musique</h5>
                            <p class="card-text">Apprendre à lire les notes, rythmes et comprendre les clés musicales pour tous instruments.</p>
                            <a href="https://www.youtube.com/watch?v=vBo9Xyiee08" class="btn btn-primary" target="_blank">
                                <i class="fab fa-youtube"></i> Voir sur YouTube
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-5 mb-5">
        <div class="col-12 text-center">
            <div class="alert alert-info" role="alert" data-aos="fade-up">
                <h4><i class="fas fa-info-circle"></i> Vous êtes enseignant?</h4>
                <p>
                    Vous souhaitez partager vos propres vidéos pédagogiques sur notre plateforme?
                    <a href="contact.php" class="alert-link">Contactez-nous</a> pour plus d'informations.
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Script pour les filtres et modes d'affichage -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gestion des filtres pour l'onglet "Apprendre Seul"
    const filterButtons = document.querySelectorAll('.filter-btn');
    const videoItems = document.querySelectorAll('.video-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Enlever la classe active de tous les boutons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Ajouter la classe active au bouton cliqué
            this.classList.add('active');
            
            // Récupérer le filtre sélectionné
            const filter = this.getAttribute('data-filter');
            
            // Filtrer les vidéos
            videoItems.forEach(item => {
                if (filter === 'all') {
                    item.style.display = 'block';
                } else {
                    if (item.classList.contains(filter)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                }
            });
        });
    });
    
    // Gestion des modes d'affichage
    const viewModeButtons = document.querySelectorAll('.view-mode-btn');
    const videoContainers = document.querySelectorAll('.tab-pane .row');
    
    viewModeButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Enlever la classe active de tous les boutons
            viewModeButtons.forEach(btn => btn.classList.remove('active'));
            
            // Ajouter la classe active au bouton cliqué
            this.classList.add('active');
            
            // Récupérer le mode d'affichage sélectionné
            const viewMode = this.getAttribute('data-view');
            
            // Appliquer le mode d'affichage
            videoContainers.forEach(container => {
                // Supprimer les anciennes classes de disposition
                container.classList.remove('view-cards', 'view-list', 'view-grid');
                
                // Ajouter la nouvelle classe
                container.classList.add('view-' + viewMode);
                
                // Modifier l'affichage des éléments
                const items = container.querySelectorAll('.col-md-6, .col-lg-4');
                
                items.forEach(item => {
                    // Réinitialiser les classes
                    item.classList.remove('col-md-6', 'col-md-12', 'col-lg-4', 'col-lg-3');
                    
                    // Appliquer les classes selon le mode
                    switch(viewMode) {
                        case 'cards':
                            item.classList.add('col-md-6', 'col-lg-4');
                            break;
                        case 'list':
                            item.classList.add('col-md-12');
                            break;
                        case 'grid':
                            item.classList.add('col-md-6', 'col-lg-3');
                            break;
                    }
                });
            });
            
            // Sauvegarder la préférence de l'utilisateur
            localStorage.setItem('videosViewMode', viewMode);
        });
    });
    
    // Charger le mode d'affichage sauvegardé
    const savedViewMode = localStorage.getItem('videosViewMode');
    if (savedViewMode) {
        const viewButton = document.querySelector(`.view-mode-btn[data-view="${savedViewMode}"]`);
        if (viewButton) {
            viewButton.click();
        }
    }
});
</script>

<?php include_once '../resources/views/footer.php'; ?>