<?php
// Afficher toutes les erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Debugging Page</h1>";
echo "<h2>PHP Info</h2>";
echo "<pre>";
echo "PHP Version: " . phpversion() . "\n";
echo "</pre>";

echo "<h2>Current Session</h2>";
echo "<pre>";
session_start();
echo "Session ID: " . session_id() . "\n";
print_r($_SESSION);
echo "</pre>";

echo "<h2>Installed Extensions</h2>";
echo "<pre>";
print_r(get_loaded_extensions());
echo "</pre>";

// Tester la connexion à la base de données
echo "<h2>Database Connection Test</h2>";
echo "<pre>";
try {
    $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $pdo = new PDO($dsn, 'musicteach', 'musicteach', $options);
    echo "Database connection successful!\n";
    
    // Vérifier les tables de la base de données
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables in database:\n";
    print_r($tables);
    
} catch (PDOException $e) {
    echo "Database connection failed: " . $e->getMessage() . "\n";
}
echo "</pre>";

// Vérifier les fonctions critiques
echo "<h2>Critical Functions Check</h2>";
echo "<pre>";
$requiredFunctions = [
    'password_hash',
    'password_verify',
    'session_start',
    'session_regenerate_id',
    'bin2hex',
    'random_bytes'
];

foreach ($requiredFunctions as $function) {
    echo "$function: " . (function_exists($function) ? "Available" : "NOT AVAILABLE") . "\n";
}

echo "</pre>";

// Vérifier les fichiers critiques
echo "<h2>Critical Files Check</h2>";
echo "<pre>";
$criticalFiles = [
    '/var/www/html/app/config.php',
    '/var/www/html/app/auth.php',
    '/var/www/html/app/utils.php',
    '/var/www/html/app/db_connect.php',
    '/var/www/html/app/mail.php',
    '/var/www/html/app/models/User.php'
];

foreach ($criticalFiles as $file) {
    echo "$file: " . (file_exists($file) ? "Exists" : "MISSING") . "\n";
}

echo "</pre>";
?>