<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Booking.php';

// Vérifier si l'utilisateur est connecté
requireLogin();

// Vérifier si l'ID de réservation est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Réservation non trouvée.');
    redirect('dashboard.php');
}

$bookingId = (int)$_GET['id'];

// Récupérer la réservation
$booking = Booking::findById($bookingId);

// Vérifier si la réservation existe
if (!$booking) {
    setFlashMessage('error', 'Réservation non trouvée.');
    redirect('dashboard.php');
}

// Vérifier si l'utilisateur a le droit d'annuler cette réservation
$isTeacher = isTeacher() && $booking['teacher_id'] === (int)$_SESSION['user_id'];
$isStudent = isStudent() && $booking['student_id'] === (int)$_SESSION['user_id'];

if (!$isTeacher && !$isStudent && !isAdmin()) {
    setFlashMessage('error', 'Vous n\'avez pas le droit d\'annuler cette réservation.');
    redirect('dashboard.php');
}

// Vérifier si la réservation est déjà annulée
if ($booking['status'] === 'canceled') {
    setFlashMessage('info', 'Cette réservation est déjà annulée.');
    redirect($isTeacher ? 'teacher_bookings.php' : 'student_bookings.php');
}

// Vérifier la date de la réservation (24h avant la date prévue)
$bookingDate = new DateTime($booking['date']);
$now = new DateTime();
$interval = $now->diff($bookingDate);
$hoursUntilClass = ($interval->days * 24) + $interval->h;

// Si moins de 24h avant le cours et ce n'est pas un admin qui annule
if ($bookingDate > $now && $hoursUntilClass < 24 && !isAdmin()) {
    setFlashMessage('error', 'Vous ne pouvez plus annuler cette réservation moins de 24h avant le cours.');
    redirect($isTeacher ? 'teacher_bookings.php' : 'student_bookings.php');
}

// Annuler la réservation
try {
    if (Booking::update($bookingId, ['status' => 'canceled'])) {
        setFlashMessage('success', 'La réservation a été annulée avec succès.');
    } else {
        setFlashMessage('error', 'Une erreur est survenue lors de l\'annulation de la réservation.');
    }
} catch (Exception $e) {
    setFlashMessage('error', 'Une erreur est survenue lors de l\'annulation de la réservation.');
}

// Rediriger vers la page appropriée
if ($isTeacher) {
    redirect('teacher_bookings.php');
} else {
    redirect('student_bookings.php');
}