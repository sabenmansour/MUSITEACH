<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';

// Rediriger si déjà connecté
if (isLoggedIn()) {
    redirect('dashboard.php');
}

// Vérifier si nous sommes en mode réinitialisation avec un token
$hasToken = isset($_GET['token']) && !empty($_GET['token']);
$token = $hasToken ? sanitizeInput($_GET['token']) : '';

// Titre de la page
$pageTitle = $hasToken ? "Définir un nouveau mot de passe" : "Réinitialisation du mot de passe";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <?php if ($hasToken) : ?>
                    <!-- Formulaire pour définir un nouveau mot de passe -->
                    <h1 class="card-title text-center mb-4">Définir un nouveau mot de passe</h1>
                    <form action="process_reset_password.php" method="post">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Nouveau mot de passe</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <div class="form-text">Le mot de passe doit contenir au moins 8 caractères.</div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="password_confirm" class="form-label">Confirmer le mot de passe</label>
                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Réinitialiser mon mot de passe</button>
                        </div>
                    </form>
                <?php else : ?>
                    <!-- Formulaire pour demander une réinitialisation -->
                    <h1 class="card-title text-center mb-4">Mot de passe oublié ?</h1>
                    <p class="text-center mb-4">Entrez votre adresse email et nous vous enverrons un lien pour réinitialiser votre mot de passe.</p>
                    
                    <form action="process_reset_request.php" method="post">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        
                        <div class="mb-4">
                            <label for="email" class="form-label">Adresse email</label>
                            <input type="email" class="form-control" id="email" name="email" required 
                                   value="<?= isset($_SESSION['reset_email']) ? htmlspecialchars($_SESSION['reset_email']) : '' ?>">
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Envoyer le lien de réinitialisation</button>
                        </div>
                    </form>
                <?php endif; ?>
                
                <div class="text-center mt-3">
                    <p><a href="login.php">Retour à la connexion</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Nettoyer les données stockées en session
if (isset($_SESSION['reset_email'])) {
    unset($_SESSION['reset_email']);
}

// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>