<?php
require_once __DIR__ . '/../db_connect.php';

/**
 * Modèle pour la gestion des disponibilités des professeurs
 */
class Availability {
    /**
     * Ajouter une plage de disponibilité
     * 
     * @param int $teacherId ID du professeur
     * @param int $dayOfWeek Jour de la semaine (0=dimanche, 1=lundi, ..., 6=samedi)
     * @param string $startTime Heure de début (format H:i:s)
     * @param string $endTime Heure de fin (format H:i:s)
     * @param bool $isRecurring Si la plage est récurrente
     * @param string|null $specificDate Date spécifique pour les plages non récurrentes (format Y-m-d)
     * @return int|false ID de la plage créée ou false en cas d'erreur
     */
    public static function create($teacherId, $dayOfWeek, $startTime, $endTime, $isRecurring = true, $specificDate = null) {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "INSERT INTO availability_slots 
             (teacher_id, day_of_week, start_time, end_time, is_recurring, specific_date, created_at, updated_at) 
             VALUES (:teacher_id, :day_of_week, :start_time, :end_time, :is_recurring, :specific_date, NOW(), NOW())"
        );
        
        $stmt->execute([
            'teacher_id' => $teacherId,
            'day_of_week' => $dayOfWeek,
            'start_time' => $startTime,
            'end_time' => $endTime,
            'is_recurring' => $isRecurring ? 1 : 0,
            'specific_date' => $specificDate
        ]);
        
        return $db->lastInsertId();
    }
    
    /**
     * Mettre à jour une plage de disponibilité
     * 
     * @param int $slotId ID de la plage
     * @param array $data Données à mettre à jour
     * @return bool Succès de l'opération
     */
    public static function update($slotId, $data) {
        $db = getDbConnection();
        
        $allowedFields = ['day_of_week', 'start_time', 'end_time', 'is_recurring', 'specific_date'];
        $fields = [];
        $params = ['id' => $slotId];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $fields[] = "$key = :$key";
                if ($key === 'is_recurring') {
                    $params[$key] = $value ? 1 : 0;
                } else {
                    $params[$key] = $value;
                }
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $sql = "UPDATE availability_slots SET " . implode(', ', $fields) . " WHERE id = :id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }
    
    /**
     * Supprimer une plage de disponibilité
     * 
     * @param int $slotId ID de la plage
     * @return bool Succès de l'opération
     */
    public static function delete($slotId) {
        $db = getDbConnection();
        $stmt = $db->prepare("DELETE FROM availability_slots WHERE id = :id");
        return $stmt->execute(['id' => $slotId]);
    }
    
    /**
     * Récupérer toutes les plages de disponibilité d'un professeur
     * 
     * @param int $teacherId ID du professeur
     * @return array Liste des plages
     */
    public static function findByTeacher($teacherId) {
        $db = getDbConnection();
        $stmt = $db->prepare(
            "SELECT * FROM availability_slots 
             WHERE teacher_id = :teacher_id 
             ORDER BY day_of_week, start_time"
        );
        $stmt->execute(['teacher_id' => $teacherId]);
        return $stmt->fetchAll();
    }
    
    /**
     * Récupérer les plages de disponibilité pour un jour spécifique
     * 
     * @param int $teacherId ID du professeur
     * @param int $dayOfWeek Jour de la semaine (0-6)
     * @param string|null $date Date spécifique (format Y-m-d)
     * @return array Liste des plages
     */
    public static function findByTeacherAndDay($teacherId, $dayOfWeek, $date = null) {
        $db = getDbConnection();
        
        // Préparation des requêtes
        $sql = "SELECT * FROM availability_slots 
                WHERE teacher_id = :teacher_id 
                AND (
                    (day_of_week = :day_of_week AND is_recurring = 1)";
        
        $params = [
            'teacher_id' => $teacherId,
            'day_of_week' => $dayOfWeek
        ];
        
        if ($date) {
            $sql .= " OR (specific_date = :specific_date AND is_recurring = 0)";
            $params['specific_date'] = $date;
        }
        
        $sql .= ") ORDER BY start_time";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
    }
    
    /**
     * Vérifier si un professeur est disponible à une date et heure spécifiques
     * 
     * @param int $teacherId ID du professeur
     * @param string $date Date au format Y-m-d
     * @param string $time Heure au format H:i:s
     * @return bool True si le professeur est disponible, false sinon
     */
    public static function isTeacherAvailable($teacherId, $date, $time) {
        $db = getDbConnection();
        
        // Convertir la date en jour de la semaine (0-6)
        $dayOfWeek = date('w', strtotime($date));
        
        // Vérifier s'il y a des plages de disponibilité qui correspondent
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM availability_slots 
             WHERE teacher_id = :teacher_id 
             AND (
                 (day_of_week = :day_of_week AND is_recurring = 1) 
                 OR (specific_date = :specific_date AND is_recurring = 0)
             )
             AND :time BETWEEN start_time AND end_time"
        );
        
        $stmt->execute([
            'teacher_id' => $teacherId,
            'day_of_week' => $dayOfWeek,
            'specific_date' => $date,
            'time' => $time
        ]);
        
        $hasAvailability = $stmt->fetchColumn() > 0;
        
        if (!$hasAvailability) {
            return false;
        }
        
        // Vérifier s'il y a déjà une réservation confirmée à cette date et heure
        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM bookings 
             WHERE teacher_id = :teacher_id 
             AND DATE(date) = :date 
             AND TIME(date) = :time
             AND status != 'canceled'"
        );
        
        $stmt->execute([
            'teacher_id' => $teacherId,
            'date' => $date,
            'time' => $time
        ]);
        
        $hasBooking = $stmt->fetchColumn() > 0;
        
        return !$hasBooking;
    }
    
    /**
     * Générer un calendrier de disponibilités pour un mois spécifique
     * 
     * @param int $teacherId ID du professeur
     * @param int $year Année
     * @param int $month Mois (1-12)
     * @return array Calendrier avec les disponibilités par jour
     */
    public static function generateMonthlyCalendar($teacherId, $year, $month) {
        $calendar = [];
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        
        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = sprintf('%04d-%02d-%02d', $year, $month, $day);
            $dayOfWeek = date('w', strtotime($date));
            
            // Récupérer les disponibilités pour ce jour
            $availabilities = self::findByTeacherAndDay($teacherId, $dayOfWeek, $date);
            
            // Récupérer les réservations pour ce jour
            $bookings = self::getBookingsForDate($teacherId, $date);
            
            $calendar[$day] = [
                'date' => $date,
                'day_of_week' => $dayOfWeek,
                'availabilities' => $availabilities,
                'bookings' => $bookings,
                'has_availabilities' => !empty($availabilities),
                'fully_booked' => !empty($availabilities) && count($bookings) >= count($availabilities)
            ];
        }
        
        return $calendar;
    }
    
    /**
     * Récupérer les réservations pour une date spécifique
     * 
     * @param int $teacherId ID du professeur
     * @param string $date Date au format Y-m-d
     * @return array Liste des réservations
     */
    private static function getBookingsForDate($teacherId, $date) {
        $db = getDbConnection();
        $stmt = $db->prepare(
            "SELECT b.*, u.name as student_name
             FROM bookings b
             JOIN users u ON b.student_id = u.id
             WHERE b.teacher_id = :teacher_id 
             AND DATE(b.date) = :date
             AND b.status != 'canceled'
             ORDER BY TIME(b.date)"
        );
        
        $stmt->execute([
            'teacher_id' => $teacherId,
            'date' => $date
        ]);
        
        return $stmt->fetchAll();
    }
}