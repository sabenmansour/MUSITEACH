#!/bin/bash

# Ce script copie le fichier db_connect_fixed.php vers le fichier db_connect.php
# à la fois localement et dans le conteneur Docker

# 1. Copier le fichier localement
cp -f /home/fennec/PROJECTS/MUSICTEACH/app/db_connect_fixed.php /home/fennec/PROJECTS/MUSICTEACH/app/db_connect.php
echo "Fichier copié localement"

# 2. Redémarrer les conteneurs Docker
cd /home/fennec/PROJECTS/MUSICTEACH/
docker-compose down
docker-compose up -d
echo "Conteneurs Docker redémarrés"

# 3. Attendre que le conteneur web soit prêt
echo "Attente du démarrage des conteneurs..."
sleep 5

# 4. Vérifier les conteneurs
WEBSERVER=$(docker ps | grep "musicteach_webserver" | awk '{print $1}')
if [ -z "$WEBSERVER" ]; then
    echo "Le conteneur webserver n'est pas en cours d'exécution"
    exit 1
fi

# 5. Copier le fichier dans le conteneur webserver
docker cp /home/fennec/PROJECTS/MUSICTEACH/app/db_connect_fixed.php ${WEBSERVER}:/var/www/html/app/db_connect.php
echo "Fichier copié dans le conteneur webserver"