#!/bin/bash

# Définition des couleurs pour un affichage plus clair
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║      MusiTeach - Mise à jour des fonctionnalités       ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo

# Fonctions utilitaires
afficher_message() {
    local type=$1
    local message=$2
    
    case $type in
        "info")
            echo -e "${BLUE}ℹ️ ${message}${NC}"
            ;;
        "success")
            echo -e "${GREEN}✅ ${message}${NC}"
            ;;
        "warning")
            echo -e "${YELLOW}⚠️ ${message}${NC}"
            ;;
        "error")
            echo -e "${RED}❌ ${message}${NC}"
            ;;
    esac
}

# Vérifier si les scripts nécessaires existent
if [ ! -f "backup_update.sh" ]; then
    afficher_message "error" "Le script backup_update.sh est introuvable!"
    exit 1
fi

if [ ! -f "update_docker.sh" ]; then
    afficher_message "error" "Le script update_docker.sh est introuvable!"
    exit 1
fi

# Menu principal
afficher_menu() {
    echo
    afficher_message "info" "Options disponibles:"
    echo "1) Effectuer une sauvegarde complète"
    echo "2) Mettre à jour Docker avec les nouvelles fonctionnalités"
    echo "3) Exécuter les deux (recommandé)"
    echo "4) Quitter"
    echo
}

# Effectuer la sauvegarde
effectuer_sauvegarde() {
    afficher_message "info" "Démarrage de la sauvegarde..."
    ./backup_update.sh
    
    if [ $? -eq 0 ]; then
        afficher_message "success" "Sauvegarde terminée avec succès"
        return 0
    else
        afficher_message "error" "Erreur lors de la sauvegarde"
        return 1
    fi
}

# Mettre à jour Docker
mettre_a_jour_docker() {
    afficher_message "info" "Démarrage de la mise à jour Docker..."
    ./update_docker.sh
    
    if [ $? -eq 0 ]; then
        afficher_message "success" "Mise à jour Docker terminée avec succès"
        return 0
    else
        afficher_message "error" "Erreur lors de la mise à jour Docker"
        return 1
    fi
}

# Exécution du menu
executer_action() {
    local choix=$1
    
    case $choix in
        1)
            effectuer_sauvegarde
            ;;
        2)
            mettre_a_jour_docker
            ;;
        3)
            effectuer_sauvegarde && mettre_a_jour_docker
            ;;
        4)
            afficher_message "info" "Au revoir!"
            exit 0
            ;;
        *)
            afficher_message "error" "Choix invalide"
            return 1
            ;;
    esac
}

# Afficher le menu et attendre le choix de l'utilisateur
afficher_menu
read -p "Entrez votre choix [1-4]: " choix_utilisateur

# Exécuter l'action correspondante
executer_action $choix_utilisateur

# Afficher un message de fin
echo
if [ $? -eq 0 ]; then
    afficher_message "success" "Opération terminée avec succès!"
    
    # Afficher les informations sur les nouvelles fonctionnalités
    echo
    afficher_message "info" "Nouvelles fonctionnalités disponibles:"
    echo "- FAQ (http://localhost:8000/faq.php)"
    echo "- Ressources musicales (http://localhost:8000/resources.php)"
    echo "- Conditions d'utilisation (http://localhost:8000/terms.php)"
    echo "- Politique de confidentialité (http://localhost:8000/privacy.php)"
    echo "- Mode sombre activable sur toutes les pages"
    echo
    afficher_message "info" "Accès à l'application:"
    echo "- MusiTeach: http://localhost:8000"
    echo "- phpMyAdmin: http://localhost:8181"
else
    afficher_message "error" "Des erreurs se sont produites pendant l'opération."
fi