<?php
// Configuration de l'application

// Informations de connexion à la base de données
define('DB_HOST', 'mysql');
define('DB_NAME', 'musicteach');
define('DB_USER', 'musicteach');
define('DB_PASS', 'musicteach');
define('DB_CHARSET', 'utf8mb4');

// Options de l'application
define('APP_NAME', 'MusiTeach');
define('APP_URL', 'http://localhost:8000');

// Configuration de sécurité
define('SECURITY_SALT', 'changemoi_en_production');

// Configuration des emails
define('MAIL_HOST', 'smtp.example.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'noreply@example.com');
define('MAIL_PASS', 'password');
define('MAIL_FROM', 'noreply@example.com');
define('MAIL_NAME', 'MusiTeach');

// Configuration de l'authentification
define('REQUIRE_EMAIL_VERIFICATION', true);
define('EMAIL_VERIFICATION_EXPIRY', 24); // Heures
define('MAX_LOGIN_ATTEMPTS', 5); // Nombre maximal de tentatives de connexion
define('LOG_AUTH_ACTIVITIES', true); // Enregistrer les activités d'authentification

// Debugging (désactiver en production)
define('DEBUG', true);

// Afficher les erreurs PHP (uniquement pour le développement)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);