<?php
/**
 * Connexion à la base de données avec PDO uniquement
 * Version ultra simple sans dépendances externes
 */

function getDbConnection() {
    // Ajouter un délai pour assurer que MySQL est prêt
    $retry = 0;
    $max_retries = 3;
    $wait_seconds = 1;
    
    while ($retry < $max_retries) {
        try {
            // Paramètres de connexion codés en dur pour le dépannage
            $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
            $user = "musicteach";
            $pass = "musicteach";
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                // Ajouter un timeout de connexion plus long
                PDO::ATTR_TIMEOUT => 5, // 5 secondes
            ];
            
            $pdo = new PDO($dsn, $user, $pass, $options);
            
            // Tester la connexion
            $pdo->query("SELECT 1");
            
            return $pdo;
        } catch (PDOException $e) {
            // Si c'est la dernière tentative, lancer l'exception
            if ($retry >= $max_retries - 1) {
                // Afficher l'erreur en clair pour le débogage
                die("Erreur de connexion à la base de données après $max_retries tentatives : " . $e->getMessage());
            }
            
            // Sinon attendre et réessayer
            error_log("Tentative de connexion à la base de données échouée, nouvelle tentative dans $wait_seconds secondes. Erreur: " . $e->getMessage());
            sleep($wait_seconds);
            $retry++;
            $wait_seconds *= 2; // Augmenter le temps d'attente (backoff exponentiel)
        }
    }
}
