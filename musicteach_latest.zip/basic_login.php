<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

echo '<h1>Page de connexion basique</h1>';

// Afficher un formulaire de connexion simple
echo '<form method="post" action="process_login.php">';
echo '<div>';
echo '<label for="email">Email:</label><br>';
echo '<input type="email" id="email" name="email" required>';
echo '</div><br>';

echo '<div>';
echo '<label for="password">Mot de passe:</label><br>';
echo '<input type="password" id="password" name="password" required>';
echo '</div><br>';

echo '<div>';
echo '<input type="checkbox" id="remember" name="remember" value="1">';
echo '<label for="remember">Se souvenir de moi</label>';
echo '</div><br>';

echo '<div>';
echo '<button type="submit">Se connecter</button>';
echo '</div>';
echo '</form>';

echo '<p>Pas encore de compte? <a href="signup.php">S\'inscrire</a></p>';
?>