<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';

// Démarrer la session
startSession();

// Titre de la page
$pageTitle = "Vérification d'email";

// Traiter la vérification du token
$token = sanitizeInput($_GET['token'] ?? '');
$verified = false;
$error = '';

if (!empty($token)) {
    try {
        // Rechercher l'utilisateur par son token d'activation
        $user = User::findByActivationToken($token);
        
        // Si l'utilisateur est trouvé et que le token n'a pas expiré
        if ($user) {
            // Activer le compte
            if (User::activate($user['id'])) {
                $verified = true;
                setFlashMessage('success', 'Votre compte a été activé avec succès ! Vous pouvez maintenant vous connecter.');
            } else {
                $error = 'Une erreur est survenue lors de l\'activation de votre compte.';
            }
        } else {
            $error = 'Le lien d\'activation est invalide ou a expiré.';
        }
    } catch (Exception $e) {
        $error = 'Une erreur est survenue lors de la vérification de votre email.';
        if (defined('DEBUG') && DEBUG) {
            error_log("Erreur de vérification d'email : " . $e->getMessage());
        }
    }
} else {
    $error = 'Aucun token de vérification fourni.';
}

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body p-4 text-center">
                <h1 class="card-title mb-4">Vérification de votre email</h1>
                
                <?php if ($verified): ?>
                    <div class="py-5">
                        <div class="mb-4">
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                        </div>
                        <h2 class="h4 mb-3">Votre compte a été activé avec succès !</h2>
                        <p class="mb-4">Vous pouvez maintenant vous connecter et profiter de tous les services de <?= APP_NAME ?>.</p>
                        <div class="mt-4">
                            <a href="login.php" class="btn btn-primary">Se connecter</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="py-5">
                        <div class="mb-4">
                            <i class="bi bi-exclamation-circle-fill text-danger" style="font-size: 4rem;"></i>
                        </div>
                        <h2 class="h4 mb-3">Échec de vérification</h2>
                        <p class="text-danger mb-4"><?= htmlspecialchars($error) ?></p>
                        <div class="mt-4">
                            <a href="login.php" class="btn btn-primary">Retour à la connexion</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>