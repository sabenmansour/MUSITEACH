<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Profile.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../utils.php';

/**
 * Service de gestion des utilisateurs
 */
class UserService {
    /**
     * Crée un nouvel utilisateur avec son profil
     * 
     * @param string $name Nom de l'utilisateur
     * @param string $email Email de l'utilisateur
     * @param string $password Mot de passe de l'utilisateur
     * @param string $role Rôle de l'utilisateur (student, teacher, admin)
     * @param array $profileData Données du profil (description, instrument, experience)
     * @return int|false ID de l'utilisateur créé ou false en cas d'erreur
     */
    public static function createUser($name, $email, $password, $role = 'student', $profileData = []) {
        // Valider les données
        if (empty($name) || empty($email) || empty($password)) {
            return false;
        }
        
        if (!isValidEmail($email)) {
            return false;
        }
        
        if (User::emailExists($email)) {
            return false;
        }
        
        if (!in_array($role, ['student', 'teacher', 'admin'])) {
            return false;
        }
        
        // Créer l'utilisateur
        $userId = User::create($name, $email, $password, $role);
        
        if (!$userId) {
            return false;
        }
        
        // Créer le profil
        $profileType = $role === 'admin' ? 'teacher' : $role; // Les admins ont un profil de type 'teacher'
        $description = $profileData['description'] ?? null;
        $instrument = $profileData['instrument'] ?? null;
        $experience = $profileData['experience'] ?? null;
        
        Profile::create($userId, $profileType, $description, $instrument, $experience);
        
        return $userId;
    }
    
    /**
     * Met à jour un utilisateur et son profil
     * 
     * @param int $userId ID de l'utilisateur
     * @param array $userData Données de l'utilisateur (name, email, role)
     * @param array $profileData Données du profil (description, instrument, experience)
     * @return bool Succès de l'opération
     */
    public static function updateUser($userId, $userData = [], $profileData = []) {
        // Vérifier si l'utilisateur existe
        $user = User::findById($userId);
        if (!$user) {
            return false;
        }
        
        // Préparer les données de l'utilisateur
        $userDataToUpdate = [];
        
        if (isset($userData['name']) && !empty($userData['name'])) {
            $userDataToUpdate['name'] = $userData['name'];
        }
        
        if (isset($userData['email']) && !empty($userData['email'])) {
            if (!isValidEmail($userData['email'])) {
                return false;
            }
            
            if (User::emailExists($userData['email'], $userId)) {
                return false;
            }
            
            $userDataToUpdate['email'] = $userData['email'];
        }
        
        if (isset($userData['role']) && in_array($userData['role'], ['student', 'teacher', 'admin'])) {
            $userDataToUpdate['role'] = $userData['role'];
        }
        
        // Mettre à jour l'utilisateur
        if (!empty($userDataToUpdate)) {
            if (!User::update($userId, $userDataToUpdate)) {
                return false;
            }
        }
        
        // Mettre à jour le profil
        if (!empty($profileData)) {
            $profileDataToUpdate = [];
            
            if (isset($profileData['description'])) {
                $profileDataToUpdate['description'] = $profileData['description'];
            }
            
            if (isset($profileData['instrument'])) {
                $profileDataToUpdate['instrument'] = $profileData['instrument'];
            }
            
            if (isset($profileData['experience'])) {
                $profileDataToUpdate['experience'] = $profileData['experience'];
            }
            
            if (isset($userData['role']) && $userDataToUpdate['role'] !== $user['role']) {
                $profileDataToUpdate['type'] = $userData['role'] === 'admin' ? 'teacher' : $userData['role'];
            }
            
            if (!empty($profileDataToUpdate)) {
                if (!Profile::createOrUpdate($userId, $profileDataToUpdate)) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /**
     * Supprime un utilisateur
     * 
     * @param int $userId ID de l'utilisateur
     * @return bool Succès de l'opération
     */
    public static function deleteUser($userId) {
        // Vérifier si l'utilisateur existe
        $user = User::findById($userId);
        if (!$user) {
            return false;
        }
        
        // Supprimer l'utilisateur
        return User::delete($userId);
    }
    
    /**
     * Récupère les statistiques des utilisateurs
     * 
     * @return array Statistiques (total, students, teachers, admins)
     */
    public static function getUsersStats() {
        $db = getDbConnection();
        
        $stats = [
            'total' => 0,
            'students' => 0,
            'teachers' => 0,
            'admins' => 0,
            'registrationsByMonth' => []
        ];
        
        // Compter le nombre total d'utilisateurs
        $stats['total'] = User::count();
        
        // Compter le nombre d'étudiants
        $stmt = $db->query("SELECT COUNT(*) FROM users WHERE role = 'student'");
        $stats['students'] = $stmt->fetchColumn();
        
        // Compter le nombre de professeurs
        $stats['teachers'] = User::countTeachers();
        
        // Compter le nombre d'administrateurs
        $stmt = $db->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        $stats['admins'] = $stmt->fetchColumn();
        
        // Récupérer les inscriptions par mois (12 derniers mois)
        $stmt = $db->query(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
             FROM users 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH) 
             GROUP BY month 
             ORDER BY month"
        );
        $registrationsByMonth = $stmt->fetchAll();
        
        foreach ($registrationsByMonth as $row) {
            $stats['registrationsByMonth'][$row['month']] = $row['count'];
        }
        
        return $stats;
    }
    
    /**
     * Recherche des utilisateurs
     * 
     * @param string $query Terme de recherche
     * @param string $role Rôle à filtrer (optionnel)
     * @param int $page Page actuelle
     * @param int $perPage Nombre d'éléments par page
     * @return array Résultat de la recherche (users et totalCount)
     */
    public static function searchUsers($query, $role = null, $page = 1, $perPage = 10) {
        $db = getDbConnection();
        $offset = ($page - 1) * $perPage;
        
        $whereClause = [];
        $params = [];
        
        if (!empty($query)) {
            $whereClause[] = "(name LIKE :query OR email LIKE :query)";
            $params['query'] = '%' . $query . '%';
        }
        
        if (!empty($role) && in_array($role, ['student', 'teacher', 'admin'])) {
            $whereClause[] = "role = :role";
            $params['role'] = $role;
        }
        
        $where = !empty($whereClause) ? "WHERE " . implode(" AND ", $whereClause) : "";
        
        // Compter le nombre total de résultats
        $countSql = "SELECT COUNT(*) FROM users $where";
        $countStmt = $db->prepare($countSql);
        foreach ($params as $key => $value) {
            $countStmt->bindValue(':' . $key, $value);
        }
        $countStmt->execute();
        $totalCount = $countStmt->fetchColumn();
        
        // Récupérer les utilisateurs
        $sql = "SELECT * FROM users $where ORDER BY created_at DESC LIMIT :offset, :limit";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        
        $stmt->execute();
        $users = $stmt->fetchAll();
        
        return [
            'users' => $users,
            'totalCount' => $totalCount
        ];
    }
}