# Guide de démarrage rapide pour MusiTeach

Ce guide explique comment démarrer l'application MusiTeach en environnement local et la déployer en production.

## Démarrage avec Docker (recommandé)

Nous avons mis en place Docker pour faciliter le déploiement local sans avoir à installer PHP, MySQL et Apache séparément.

### Prérequis
- Docker
- Docker Compose

### Étapes

1. Ouvrez un terminal dans le dossier racine du projet

2. Lancez l'application avec Docker Compose :
   ```
   docker-compose up -d
   ```

3. L'application sera disponible à l'adresse suivante :
   ```
   http://localhost:8000
   ```

4. Importez les données initiales (si nécessaire) :
   ```
   docker-compose exec mysql mysql -u musicteach -pmusicteach musicteach < database/instruments.sql
   ```

5. Pour arrêter l'application :
   ```
   docker-compose down
   ```

## Démarrage manuel (sans Docker)

Si vous préférez ne pas utiliser Docker, voici comment démarrer l'application manuellement.

### Prérequis
- PHP 7.4 ou supérieur
- MySQL ou MariaDB
- Apache ou Nginx

### Étapes

1. Créez une base de données nommée `musicteach`

2. Importez le schéma de la base de données :
   ```
   mysql -u votre_utilisateur -p musicteach < database/schema.sql
   mysql -u votre_utilisateur -p musicteach < database/instruments.sql
   ```

3. Configurez la connexion à la base de données dans `app/config.php`

4. Configurez votre serveur web (Apache/Nginx) pour pointer vers le dossier `public`

5. Alternativement, vous pouvez utiliser le serveur web intégré de PHP :
   ```
   php -S localhost:8000 -t public/
   ```

6. L'application sera disponible à l'adresse configurée sur votre serveur web ou, avec le serveur PHP intégré :
   ```
   http://localhost:8000
   ```

## Déploiement en production

### Hébergement traditionnel (mutualisé ou dédié)

1. Téléchargez les fichiers sur votre serveur via FTP ou SSH

2. Créez une base de données et importez les fichiers SQL :
   ```
   mysql -u utilisateur -p nom_base < database/schema.sql
   mysql -u utilisateur -p nom_base < database/instruments.sql
   ```

3. Configurez le fichier `app/config.php` avec les paramètres de production :
   ```php
   define('DEBUG', false);
   define('APP_URL', 'https://votre-domaine.com');
   ```

4. Configurez le serveur web pour pointer vers le dossier `public/`

5. Assurez-vous que le certificat SSL est correctement configuré

### Déploiement sur serveur Cloud (AWS, GCP, Azure)

1. Créez une instance de machine virtuelle avec l'OS de votre choix (recommandé: Ubuntu Server)

2. Installez les dépendances nécessaires (PHP, MySQL, Apache/Nginx)

3. Clonez le dépôt Git ou téléchargez une archive du code source

4. Suivez les étapes du déploiement traditionnel ci-dessus

5. Configuration de la sécurité réseau :
   - Ouvrez les ports 80 (HTTP) et 443 (HTTPS)
   - Restreignez l'accès au port 22 (SSH) à vos adresses IP
   - Configurez un pare-feu pour protéger la base de données

### Déploiement avec Docker en production

1. Sur le serveur de production, installez Docker et Docker Compose

2. Créez un fichier `docker-compose.prod.yml` adapté à la production :
   ```yaml
   version: '3'
   services:
     web:
       image: php:7.4-apache
       volumes:
         - ./:/var/www/html
       ports:
         - "80:80"
         - "443:443"
       environment:
         - ENVIRONMENT=production
       restart: always
       
     mysql:
       image: mariadb:10.5
       volumes:
         - mysql_data:/var/lib/mysql
       environment:
         - MYSQL_ROOT_PASSWORD=password_secure
         - MYSQL_DATABASE=musicteach
         - MYSQL_USER=musicteach
         - MYSQL_PASSWORD=password_secure
       restart: always
       
   volumes:
     mysql_data:
   ```

3. Lancez les conteneurs en mode production :
   ```
   docker-compose -f docker-compose.prod.yml up -d
   ```

4. Configurez un proxy inverse (comme Traefik ou Nginx Proxy Manager) pour gérer les certificats SSL

## Accès à l'application

### Création d'un administrateur

Pour tester l'application, créez un compte administrateur via la page d'inscription, puis changez le rôle depuis la base de données :

```sql
UPDATE users SET role = 'admin' WHERE email = 'votre_email@example.com';
```

### Configuration des emails (production)

En production, configurez les paramètres SMTP dans `app/config.php` :
```php
define('MAIL_HOST', 'smtp.votre-serveur.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'no-reply@votre-domaine.com');
define('MAIL_PASS', 'votre_mot_de_passe');
define('MAIL_FROM', 'no-reply@votre-domaine.com');
define('MAIL_NAME', 'MusiTeach');
```

### Problèmes courants

- Si vous rencontrez des erreurs de connexion à la base de données, vérifiez les paramètres dans `app/config.php`
- Si vous utilisez Docker et que la base de données n'est pas initialisée correctement, vous pouvez essayer de recréer les conteneurs :
  ```
  docker-compose down -v
  docker-compose up -d
  ```
- Pour les erreurs liées aux permissions de fichiers en production :
  ```
  chown -R www-data:www-data /chemin/vers/application
  find /chemin/vers/application -type f -exec chmod 644 {} \;
  find /chemin/vers/application -type d -exec chmod 755 {} \;
  ```

### Maintenance

- Effectuez des sauvegardes régulières de la base de données :
  ```
  mysqldump -u utilisateur -p musicteach > backup_$(date +%Y%m%d).sql
  ```
- Mettez à jour régulièrement le code source via Git ou FTP
- Vérifiez régulièrement les journaux d'erreurs pour détecter les problèmes