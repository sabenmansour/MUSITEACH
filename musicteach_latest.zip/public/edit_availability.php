<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Availability.php';
require_once __DIR__ . '/../app/db_connect.php';

// Vérifier si l'utilisateur est connecté et est un professeur
requireLogin();
if (!isTeacher()) {
    setFlashMessage('error', 'Accès réservé aux professeurs.');
    redirect('dashboard.php');
}

// Vérifier si l'ID de la disponibilité est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Disponibilité non trouvée.');
    redirect('availability.php');
}

$slotId = (int)$_GET['id'];
$teacherId = $_SESSION['user_id'];

// Vérifier si la table availability_slots existe
$db = getDbConnection();
$stmt = $db->prepare("SHOW TABLES LIKE 'availability_slots'");
$stmt->execute();
$tableExists = $stmt->fetchColumn();

if (!$tableExists) {
    setFlashMessage('error', 'La fonctionnalité de gestion des disponibilités n\'est pas disponible actuellement.');
    redirect('availability.php');
}

// Récupérer les informations de la disponibilité
$stmt = $db->prepare(
    "SELECT * FROM availability_slots 
     WHERE id = :id AND teacher_id = :teacher_id"
);
$stmt->execute(['id' => $slotId, 'teacher_id' => $teacherId]);
$slot = $stmt->fetch();

if (!$slot) {
    setFlashMessage('error', 'Disponibilité non trouvée ou vous n\'avez pas les droits pour la modifier.');
    redirect('availability.php');
}

// Traitement du formulaire de mise à jour
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_availability'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Une erreur de sécurité est survenue. Veuillez réessayer.';
    } else {
        $dayOfWeek = isset($_POST['day_of_week']) && is_numeric($_POST['day_of_week']) && $_POST['day_of_week'] >= 0 && $_POST['day_of_week'] <= 6
            ? (int)$_POST['day_of_week']
            : null;
        
        $startTime = isset($_POST['start_time']) ? $_POST['start_time'] : null;
        $endTime = isset($_POST['end_time']) ? $_POST['end_time'] : null;
        $isRecurring = isset($_POST['is_recurring']) ? (bool)$_POST['is_recurring'] : true;
        $specificDate = isset($_POST['specific_date']) && !empty($_POST['specific_date']) ? $_POST['specific_date'] : null;
        
        if ($dayOfWeek === null) {
            $error = 'Veuillez sélectionner un jour de la semaine.';
        } elseif (empty($startTime)) {
            $error = 'Veuillez sélectionner une heure de début.';
        } elseif (empty($endTime)) {
            $error = 'Veuillez sélectionner une heure de fin.';
        } elseif ($startTime >= $endTime) {
            $error = 'L\'heure de début doit être antérieure à l\'heure de fin.';
        } elseif (!$isRecurring && empty($specificDate)) {
            $error = 'Veuillez sélectionner une date spécifique pour une disponibilité non récurrente.';
        } else {
            try {
                $result = Availability::update($slotId, [
                    'day_of_week' => $dayOfWeek,
                    'start_time' => $startTime,
                    'end_time' => $endTime,
                    'is_recurring' => $isRecurring ? 1 : 0,
                    'specific_date' => !$isRecurring ? $specificDate : null
                ]);
                
                if ($result) {
                    setFlashMessage('success', 'La disponibilité a été mise à jour avec succès.');
                    redirect('availability.php');
                } else {
                    $error = 'Une erreur est survenue lors de la mise à jour de la disponibilité.';
                }
            } catch (Exception $e) {
                $error = 'Une erreur est survenue : ' . $e->getMessage();
            }
        }
    }
}

// Formater les données pour l'affichage
$startTime = date('H:i', strtotime($slot['start_time']));
$endTime = date('H:i', strtotime($slot['end_time']));
$isRecurring = (bool)$slot['is_recurring'];
$specificDate = $slot['specific_date'] ? date('Y-m-d', strtotime($slot['specific_date'])) : null;

// Javascript pour la gestion du formulaire
$extraJs = <<<JS
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gestion du champ de date spécifique
    const isRecurringCheckbox = document.getElementById('is_recurring');
    const specificDateContainer = document.getElementById('specific_date_container');
    
    function toggleSpecificDate() {
        specificDateContainer.style.display = isRecurringCheckbox.checked ? 'none' : 'block';
    }
    
    isRecurringCheckbox.addEventListener('change', toggleSpecificDate);
    toggleSpecificDate();
});
</script>
JS;

// Titre de la page
$pageTitle = "Modifier une disponibilité";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Modifier une disponibilité</h1>
    
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Éditer la disponibilité</h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger mb-3">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <?= $error ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success mb-3">
                            <i class="fas fa-check-circle me-2"></i>
                            La disponibilité a été mise à jour avec succès.
                        </div>
                    <?php endif; ?>
                    
                    <form action="edit_availability.php?id=<?= $slotId ?>" method="post">
                        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                        <input type="hidden" name="update_availability" value="1">
                        
                        <div class="mb-3">
                            <label for="day_of_week" class="form-label">Jour de la semaine</label>
                            <select class="form-select" id="day_of_week" name="day_of_week" required>
                                <option value="1" <?= $slot['day_of_week'] == 1 ? 'selected' : '' ?>>Lundi</option>
                                <option value="2" <?= $slot['day_of_week'] == 2 ? 'selected' : '' ?>>Mardi</option>
                                <option value="3" <?= $slot['day_of_week'] == 3 ? 'selected' : '' ?>>Mercredi</option>
                                <option value="4" <?= $slot['day_of_week'] == 4 ? 'selected' : '' ?>>Jeudi</option>
                                <option value="5" <?= $slot['day_of_week'] == 5 ? 'selected' : '' ?>>Vendredi</option>
                                <option value="6" <?= $slot['day_of_week'] == 6 ? 'selected' : '' ?>>Samedi</option>
                                <option value="0" <?= $slot['day_of_week'] == 0 ? 'selected' : '' ?>>Dimanche</option>
                            </select>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-6">
                                <label for="start_time" class="form-label">Heure de début</label>
                                <input type="time" class="form-control" id="start_time" name="start_time" 
                                       value="<?= $startTime ?>" required>
                            </div>
                            <div class="col-6">
                                <label for="end_time" class="form-label">Heure de fin</label>
                                <input type="time" class="form-control" id="end_time" name="end_time" 
                                       value="<?= $endTime ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="is_recurring" name="is_recurring" 
                                   value="1" <?= $isRecurring ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_recurring">Disponibilité récurrente</label>
                            <div class="form-text">
                                Si activé, cette disponibilité s'appliquera chaque semaine au jour sélectionné.
                            </div>
                        </div>
                        
                        <div class="mb-3" id="specific_date_container" style="display: <?= $isRecurring ? 'none' : 'block' ?>;">
                            <label for="specific_date" class="form-label">Date spécifique</label>
                            <input type="date" class="form-control" id="specific_date" name="specific_date" 
                                   value="<?= $specificDate ?>" min="<?= date('Y-m-d') ?>">
                            <div class="form-text">
                                Pour une disponibilité ponctuelle, sélectionnez une date spécifique.
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="availability.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Retour
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Enregistrer les modifications
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>