<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';
require_once __DIR__ . '/../app/models/Booking.php';

// Vérifier si l'utilisateur est connecté
requireLogin();

// Récupérer les informations de l'utilisateur
$user = User::findById($_SESSION['user_id']);
$profile = Profile::findByUserId($_SESSION['user_id']);

// Récupérer les réservations (selon le type d'utilisateur)
$bookings = [];
if (isStudent()) {
    $bookings = Booking::findByStudent($_SESSION['user_id'], 1, 5);
} elseif (isTeacher()) {
    $bookings = Booking::findByTeacher($_SESSION['user_id'], 1, 5);
}

// Titre de la page
$pageTitle = "Tableau de bord";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row align-items-center mb-4">
        <div class="col-md-6">
            <h1 class="mb-0" data-aos="fade-right">Tableau de bord</h1>
        </div>
        <div class="col-md-6 text-md-end" data-aos="fade-left">
            <a href="profile_edit.php" class="btn btn-primary">
                <i class="fas fa-user-edit me-2"></i>Modifier mon profil
            </a>
            <?php if (isTeacher()): ?>
            <a href="teacher_bookings.php" class="btn btn-outline-primary ms-2">
                <i class="fas fa-calendar-check me-2"></i>Gérer mes réservations
            </a>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Statistiques -->
    <div class="row mb-4">
        <?php if (isStudent()): ?>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="dashboard-stats">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="counter"><span class="stat-value" data-target="<?= count($bookings) ?>">0</span></h3>
                        <p>Cours à venir</p>
                    </div>
                    <div class="col-4 text-end">
                        <div class="icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div class="dashboard-stats">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="counter"><span class="stat-value" data-target="12">0</span></h3>
                        <p>Cours terminés</p>
                    </div>
                    <div class="col-4 text-end">
                        <div class="icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
            <div class="dashboard-stats">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="counter"><span class="stat-value" data-target="3">0</span></h3>
                        <p>Professeurs différents</p>
                    </div>
                    <div class="col-4 text-end">
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif (isTeacher()): ?>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="dashboard-stats">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="counter"><span class="stat-value" data-target="<?= count($bookings) ?>">0</span></h3>
                        <p>Cours à donner</p>
                    </div>
                    <div class="col-4 text-end">
                        <div class="icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div class="dashboard-stats">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="counter"><span class="stat-value" data-target="48">0</span></h3>
                        <p>Cours donnés</p>
                    </div>
                    <div class="col-4 text-end">
                        <div class="icon">
                            <i class="fas fa-music"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
            <div class="dashboard-stats">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="counter"><span class="stat-value" data-target="15">0</span></h3>
                        <p>Élèves différents</p>
                    </div>
                    <div class="col-4 text-end">
                        <div class="icon">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="row">
        <!-- Colonne de gauche : Informations utilisateur -->
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card">
                <div class="card-body text-center">
                    <div class="position-relative mx-auto mb-4">
                        <img src="/resources/img/<?= $user['role'] === 'teacher' ? 'teacher' : 'user' ?>-placeholder.jpg" 
                             alt="<?= htmlspecialchars($user['name']) ?>" 
                             class="img-fluid rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;">
                        <span class="position-absolute bottom-0 end-0 badge rounded-pill bg-<?= $user['role'] === 'teacher' ? 'primary' : ($user['role'] === 'admin' ? 'danger' : 'success') ?>" 
                              style="font-size: 0.9rem; padding: 0.5rem 0.8rem;">
                            <?= $user['role'] === 'student' ? 'Élève' : ($user['role'] === 'teacher' ? 'Professeur' : 'Admin') ?>
                        </span>
                    </div>
                    
                    <h3 class="card-title mb-1"><?= htmlspecialchars($user['name']) ?></h3>
                    <p class="text-muted mb-3"><?= htmlspecialchars($user['email']) ?></p>
                    
                    <?php if ($user['role'] === 'teacher' && isset($profile['instrument']) && !empty($profile['instrument'])): ?>
                        <div class="mb-3">
                            <span class="badge bg-primary px-3 py-2"><?= htmlspecialchars($profile['instrument']) ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-4">
                        <a href="profile_edit.php" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-edit me-1"></i> Modifier mon profil
                        </a>
                        <a href="change_password.php" class="btn btn-outline-secondary btn-sm ms-2">
                            <i class="fas fa-key me-1"></i> Changer mot de passe
                        </a>
                    </div>
                </div>
                
                <?php if (isset($profile) && $profile): ?>
                <div class="card-footer p-3">
                    <h5 class="mb-3">Informations supplémentaires</h5>
                    
                    <?php if (isset($profile['location']) && !empty($profile['location'])): ?>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-map-marker-alt text-muted me-2"></i>
                            <span><?= htmlspecialchars($profile['location']) ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($profile['phone']) && !empty($profile['phone'])): ?>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-phone text-muted me-2"></i>
                            <span><?= htmlspecialchars($profile['phone']) ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($user['role'] === 'teacher' && isset($profile['teaching_since']) && !empty($profile['teaching_since'])): ?>
                        <div class="d-flex align-items-center mb-2">
                            <i class="fas fa-graduation-cap text-muted me-2"></i>
                            <span>Enseigne depuis <?= htmlspecialchars($profile['teaching_since']) ?></span>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Colonne de droite : Contenu principal -->
        <div class="col-md-8" data-aos="fade-left">
            <!-- Message de bienvenue -->
            <div class="card mb-4">
                <div class="card-body">
                    <h4 class="mb-3">Bienvenue, <?= htmlspecialchars($user['name']) ?> !</h4>
                    <?php if (isStudent()): ?>
                        <p>Vous pouvez parcourir les profils des professeurs et réserver des cours selon vos disponibilités.</p>
                        <div class="d-flex mt-3">
                            <a href="teachers.php" class="btn btn-primary me-2">
                                <i class="fas fa-search me-1"></i> Trouver un professeur
                            </a>
                            <a href="student_bookings.php" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-alt me-1"></i> Voir tous mes cours
                            </a>
                        </div>
                    <?php elseif (isTeacher()): ?>
                        <p>Vous pouvez gérer votre profil et vos disponibilités pour permettre aux élèves de réserver des cours avec vous.</p>
                        <div class="d-flex mt-3">
                            <a href="profile.php?id=<?= $user['id'] ?>" class="btn btn-primary me-2">
                                <i class="fas fa-user me-1"></i> Voir mon profil public
                            </a>
                            <a href="teacher_bookings.php" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-check me-1"></i> Gérer mes réservations
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Réservations récentes -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center bg-transparent">
                    <h5 class="mb-0"><?= isStudent() ? 'Mes cours à venir' : 'Mes prochains cours à donner' ?></h5>
                    <a href="<?= isStudent() ? 'student_bookings.php' : 'teacher_bookings.php' ?>" class="btn btn-sm btn-link">
                        Voir tout <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
                <div class="card-body">
                    <?php if (empty($bookings)): ?>
                        <div class="text-center py-4">
                            <div class="mb-3">
                                <i class="fas fa-calendar-times fa-4x text-muted"></i>
                            </div>
                            <p class="text-muted">Aucune réservation pour le moment.</p>
                            <?php if (isStudent()): ?>
                                <a href="teachers.php" class="btn btn-primary">
                                    <i class="fas fa-search me-1"></i> Trouver un professeur
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th><?= isStudent() ? 'Professeur' : 'Élève' ?></th>
                                        <th>Instrument</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                        <tr class="recent-activity">
                                            <td>
                                                <div class="fw-bold"><?= formatDate($booking['date']) ?></div>
                                                <small class="text-muted"><?= substr($booking['date'], 11, 5) ?></small>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="/resources/img/<?= isStudent() ? 'teacher' : 'user' ?>-placeholder.jpg" 
                                                         class="rounded-circle me-2" width="40" height="40">
                                                    <div>
                                                        <?= isStudent() 
                                                            ? htmlspecialchars($booking['teacher_name']) 
                                                            : htmlspecialchars($booking['student_name']) 
                                                        ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?= $booking['instrument'] ?? 'Non spécifié' ?></td>
                                            <td>
                                                <?php
                                                switch ($booking['status']) {
                                                    case 'pending':
                                                        echo '<span class="badge bg-warning">En attente</span>';
                                                        break;
                                                    case 'confirmed':
                                                        echo '<span class="badge bg-success">Confirmé</span>';
                                                        break;
                                                    case 'canceled':
                                                        echo '<span class="badge bg-danger">Annulé</span>';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($booking['status'] !== 'canceled'): ?>
                                                    <a href="cancel_booking.php?id=<?= $booking['id'] ?>" 
                                                       class="btn btn-sm btn-outline-danger"
                                                       onclick="return confirm('Êtes-vous sûr de vouloir annuler cette réservation ?');">
                                                        <i class="fas fa-times me-1"></i> Annuler
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted">Annulé</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="text-center mt-4">
                            <a href="<?= isStudent() ? 'student_bookings.php' : 'teacher_bookings.php' ?>" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-alt me-1"></i> Voir toutes les réservations
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>