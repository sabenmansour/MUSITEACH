/**
 * MusiTeach - Script principal
 */

document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour initialiser le menu de modes
    function initThemeMode() {
        const htmlElement = document.documentElement;
        const modeSwitch = document.querySelector('.mode-switch');
        
        // Créer le panneau de modes s'il n'existe pas
        let modePanel = document.querySelector('.mode-panel');
        if (!modePanel) {
            modePanel = document.createElement('div');
            modePanel.className = 'mode-panel';
            modePanel.innerHTML = `
                <div class="d-flex align-items-center mb-3 pb-2 border-bottom">
                    <i class="fas fa-palette fa-2x me-2 text-primary"></i>
                    <h5 class="mb-0">Options d'affichage</h5>
                </div>
                
                <div class="mode-btn system-btn" data-mode="system">
                    <i class="fas fa-laptop"></i> Mode Système
                </div>
                <div class="mode-btn light-btn" data-mode="light">
                    <i class="fas fa-sun"></i> Mode Clair
                </div>
                <div class="mode-btn dark-btn" data-mode="dark">
                    <i class="fas fa-moon"></i> Mode Sombre
                </div>
                <div class="mode-btn sepia-btn" data-mode="sepia">
                    <i class="fas fa-book"></i> Mode Sepia
                </div>
                <div class="mode-btn high-contrast-btn" data-mode="high-contrast">
                    <i class="fas fa-adjust"></i> Contraste Élevé
                </div>
                
                <div class="alert alert-light border mt-3 text-center py-2 mb-0">
                    <i class="fas fa-info-circle me-1"></i> Vos préférences sont sauvegardées automatiquement
                </div>
            `;
            document.body.appendChild(modePanel);
            
            // Ajouter les écouteurs d'événements aux boutons de mode
            const modeButtons = document.querySelectorAll('.mode-btn');
            modeButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    const mode = this.getAttribute('data-mode');
                    setThemeMode(mode);
                    updateActiveButton(mode);
                    modePanel.classList.remove('active');
                });
            });
        }
        
        // Gérer le clic sur le bouton de switch
        if (modeSwitch) {
            modeSwitch.addEventListener('click', function(e) {
                e.preventDefault();
                modePanel.classList.toggle('active');
            });
            
            // Fermer le panneau si on clique ailleurs sur la page
            document.addEventListener('click', function(e) {
                if (!modeSwitch.contains(e.target) && !modePanel.contains(e.target)) {
                    modePanel.classList.remove('active');
                }
            });
        }
        
        // Fonction pour détecter le mode préféré du système
        function getSystemPreference() {
            return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        
        // Fonction pour définir le mode
        function setThemeMode(mode) {
            // Supprimer toutes les classes de mode
            htmlElement.classList.remove('dark-mode', 'sepia-mode', 'high-contrast-mode');
            
            // Vérifier si le mode est système et déterminer le mode réel
            const actualMode = mode === 'system' ? getSystemPreference() : mode;
            
            // Ajouter la classe appropriée selon le mode
            switch(actualMode) {
                case 'dark':
                    htmlElement.classList.add('dark-mode');
                    modeSwitch.innerHTML = mode === 'system' ? 
                        '<i class="fas fa-laptop me-1"></i> Thèmes' : 
                        '<i class="fas fa-moon me-1"></i> Thèmes';
                    break;
                case 'sepia':
                    htmlElement.classList.add('sepia-mode');
                    modeSwitch.innerHTML = '<i class="fas fa-book me-1"></i> Thèmes';
                    break;
                case 'high-contrast':
                    htmlElement.classList.add('high-contrast-mode');
                    modeSwitch.innerHTML = '<i class="fas fa-adjust me-1"></i> Thèmes';
                    break;
                default: // Mode clair
                    modeSwitch.innerHTML = mode === 'system' ? 
                        '<i class="fas fa-laptop me-1"></i> Thèmes' : 
                        '<i class="fas fa-sun me-1"></i> Thèmes';
            }
            
            // Sauvegarder le mode dans localStorage
            localStorage.setItem('themeMode', mode);
        }
        
        // Fonction pour mettre à jour le bouton actif
        function updateActiveButton(mode) {
            const modeButtons = document.querySelectorAll('.mode-btn');
            modeButtons.forEach(btn => {
                if (btn.getAttribute('data-mode') === mode) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
        }
        
        // Écouteur d'événements pour les changements de préférence du système
        if (window.matchMedia) {
            const colorSchemeQuery = window.matchMedia('(prefers-color-scheme: dark)');
            
            // S'assurer que la fonctionnalité de correspondance média est supportée
            if (colorSchemeQuery.addEventListener) {
                colorSchemeQuery.addEventListener('change', function() {
                    // Si le mode système est actif, mettre à jour le thème
                    if (localStorage.getItem('themeMode') === 'system') {
                        setThemeMode('system');
                    }
                });
            }
        }
        
        // Charger le mode sauvegardé
        const storedMode = localStorage.getItem('themeMode') || 'system';
        setThemeMode(storedMode);
        updateActiveButton(storedMode);
    }
    
    // Initialiser le mode thème
    initThemeMode();
    
    // Ajouter le bouton de changement de mode s'il n'existe pas déjà
    if (!document.querySelector('.mode-switch')) {
        const modeSwitchBtn = document.createElement('a');
        modeSwitchBtn.href = '#';
        modeSwitchBtn.className = 'mode-switch';
        
        // Déterminer l'icône initiale en fonction du mode stocké
        const storedMode = localStorage.getItem('themeMode') || 'system';
        
        modeSwitchBtn.innerHTML = '<span>Thèmes</span>';
        
        if (storedMode === 'system') {
            modeSwitchBtn.innerHTML = '<i class="fas fa-laptop me-1"></i> Thèmes';
        } else if (storedMode === 'dark') {
            modeSwitchBtn.innerHTML = '<i class="fas fa-moon me-1"></i> Thèmes';
        } else if (storedMode === 'sepia') {
            modeSwitchBtn.innerHTML = '<i class="fas fa-book me-1"></i> Thèmes';
        } else if (storedMode === 'high-contrast') {
            modeSwitchBtn.innerHTML = '<i class="fas fa-adjust me-1"></i> Thèmes';
        } else {
            modeSwitchBtn.innerHTML = '<i class="fas fa-sun me-1"></i> Thèmes';
        }
        
        modeSwitchBtn.title = 'Options d\'affichage';
        document.body.appendChild(modeSwitchBtn);
        
        // Réinitialiser les écouteurs d'événements
        initThemeMode();
    }

    // Fermeture automatique des alertes après 5 secondes
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        }, 5000);
    });

    // Gestion du calendrier pour la réservation
    const calendarDays = document.querySelectorAll('.calendar-day');
    calendarDays.forEach(function(day) {
        day.addEventListener('click', function() {
            // Supprimer la classe active de tous les jours
            calendarDays.forEach(function(d) {
                d.classList.remove('active');
            });
            
            // Ajouter la classe active au jour cliqué
            day.classList.add('active');
            
            // Si nous sommes sur la page de réservation, mettre à jour le champ date
            const bookingDateInput = document.getElementById('booking_date');
            if (bookingDateInput) {
                // Logique pour calculer la date réelle à partir du jour cliqué
                const year = new Date().getFullYear();
                const month = new Date().getMonth() + 1; // Mois actuel
                const dayNum = parseInt(day.textContent);
                if (!isNaN(dayNum)) {
                    const formattedDate = `${year}-${month.toString().padStart(2, '0')}-${dayNum.toString().padStart(2, '0')}`;
                    bookingDateInput.value = formattedDate;
                    
                    // Déclencher l'événement change pour mettre à jour les créneaux horaires
                    const changeEvent = new Event('change');
                    bookingDateInput.dispatchEvent(changeEvent);
                }
                
                // Afficher les créneaux horaires disponibles
                const timeSlots = document.getElementById('time-slots');
                if (timeSlots) {
                    timeSlots.classList.remove('d-none');
                    // Faire défiler jusqu'aux créneaux horaires
                    timeSlots.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });

    // Gestion des créneaux horaires dans l'interface de réservation
    const timeSlotItems = document.querySelectorAll('.time-slot');
    if (timeSlotItems.length > 0) {
        timeSlotItems.forEach(function(slot) {
            if (!slot.classList.contains('unavailable')) {
                slot.addEventListener('click', function() {
                    // Supprimer la classe selected de tous les créneaux
                    timeSlotItems.forEach(function(s) {
                        s.classList.remove('selected');
                    });
                    
                    // Ajouter la classe selected au créneau cliqué
                    slot.classList.add('selected');
                    
                    // Mettre à jour le champ caché avec l'heure sélectionnée
                    const bookingTimeInput = document.getElementById('booking_time');
                    if (bookingTimeInput) {
                        bookingTimeInput.value = slot.dataset.time;
                    }
                    
                    // Afficher le bouton de confirmation
                    const confirmButton = document.getElementById('confirm-booking');
                    if (confirmButton) {
                        confirmButton.classList.remove('d-none');
                        // Faire défiler jusqu'au bouton
                        confirmButton.scrollIntoView({ behavior: 'smooth' });
                    }
                });
            }
        });
    }

    // Animation pour les statistiques du tableau de bord
    const animateValue = (element, start, end, duration) => {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const value = Math.floor(progress * (end - start) + start);
            element.textContent = value;
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    };
    
    // Animer les statistiques s'il y en a
    const statElements = document.querySelectorAll('.stat-value');
    if (statElements.length > 0) {
        statElements.forEach(element => {
            const target = parseInt(element.getAttribute('data-target'), 10);
            animateValue(element, 0, target, 1500);
        });
    }

    // Validation des formulaires
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
            
            // Validation spécifique pour le formulaire d'inscription
            if (form.action.includes('process_signup.php')) {
                const password = document.getElementById('password');
                const passwordConfirm = document.getElementById('password_confirm');
                
                if (password && passwordConfirm && password.value !== passwordConfirm.value) {
                    passwordConfirm.setCustomValidity('Les mots de passe ne correspondent pas.');
                    event.preventDefault();
                } else if (passwordConfirm) {
                    passwordConfirm.setCustomValidity('');
                }
            }
        });
    });

    // Validation des mots de passe en temps réel
    const passwordConfirm = document.getElementById('password_confirm');
    if (passwordConfirm) {
        passwordConfirm.addEventListener('input', function() {
            const password = document.getElementById('password');
            if (password.value !== passwordConfirm.value) {
                passwordConfirm.setCustomValidity('Les mots de passe ne correspondent pas.');
            } else {
                passwordConfirm.setCustomValidity('');
            }
        });
    }

    // Changement dynamique des options de l'heure en fonction de la date
    const bookingDate = document.getElementById('booking_date');
    const bookingTime = document.getElementById('booking_time');
    
    if (bookingDate && bookingTime) {
        bookingDate.addEventListener('change', function() {
            // Simuler une réponse AJAX pour les créneaux disponibles
            // En production, cela ferait une requête AJAX au serveur pour obtenir les créneaux disponibles
            
            // Vider les options actuelles
            bookingTime.innerHTML = '<option value="">Choisir un horaire</option>';
            
            // Ajouter les nouveaux créneaux (simulés pour l'exemple)
            const timeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
            
            // Simuler quelques créneaux indisponibles pour les jours pairs
            const day = new Date(bookingDate.value).getDate();
            const availableSlots = day % 2 === 0 
                ? timeSlots.filter(t => !['10:00', '15:00'].includes(t)) 
                : timeSlots;
            
            // Ajouter les options disponibles
            availableSlots.forEach(function(time) {
                const option = document.createElement('option');
                option.value = time;
                option.textContent = time;
                bookingTime.appendChild(option);
            });
            
            // Mettre à jour l'affichage des créneaux horaires s'ils existent
            updateTimeSlotDisplay(availableSlots);
        });
    }
    
    // Fonction pour mettre à jour l'affichage des créneaux horaires visuels
    function updateTimeSlotDisplay(availableSlots) {
        const timeSlotsContainer = document.getElementById('visual-time-slots');
        if (timeSlotsContainer) {
            // Vider le conteneur
            timeSlotsContainer.innerHTML = '';
            
            // Créer des éléments pour chaque créneau horaire
            const allTimeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
            
            allTimeSlots.forEach(time => {
                const isAvailable = availableSlots.includes(time);
                const slotElement = document.createElement('div');
                slotElement.className = `time-slot ${isAvailable ? '' : 'unavailable'}`;
                slotElement.dataset.time = time;
                slotElement.innerHTML = `
                    <i class="far fa-clock me-2"></i> ${time}
                    ${isAvailable ? '' : '<span class="badge bg-secondary ms-2">Indisponible</span>'}
                `;
                
                timeSlotsContainer.appendChild(slotElement);
                
                // Ajouter l'événement click aux créneaux disponibles
                if (isAvailable) {
                    slotElement.addEventListener('click', function() {
                        // Supprimer la classe selected de tous les créneaux
                        document.querySelectorAll('.time-slot').forEach(s => {
                            s.classList.remove('selected');
                        });
                        
                        // Ajouter la classe selected au créneau cliqué
                        slotElement.classList.add('selected');
                        
                        // Mettre à jour le champ caché avec l'heure sélectionnée
                        const bookingTimeInput = document.getElementById('booking_time');
                        if (bookingTimeInput) {
                            bookingTimeInput.value = time;
                        }
                        
                        // Afficher le bouton de confirmation
                        const confirmButton = document.getElementById('confirm-booking');
                        if (confirmButton) {
                            confirmButton.classList.remove('d-none');
                            confirmButton.scrollIntoView({ behavior: 'smooth' });
                        }
                    });
                }
            });
        }
    }
    
    // Initialiser l'affichage des créneaux horaires si nous sommes sur la page de réservation
    if (document.getElementById('visual-time-slots')) {
        const timeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
        updateTimeSlotDisplay(timeSlots);
    }
    
    // Gestion des effets de transparence au défilement
    window.addEventListener('scroll', function() {
        const heroSection = document.querySelector('.hero');
        if (heroSection) {
            const scrollPosition = window.scrollY;
            const parallaxElements = document.querySelectorAll('.parallax');
            
            // Effet de parallaxe pour les éléments avec la classe parallax
            parallaxElements.forEach(element => {
                const speed = element.dataset.speed || 0.5;
                element.style.transform = `translateY(${scrollPosition * speed}px)`;
            });
        }
    });
    
    // Initialisation des tooltips Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});