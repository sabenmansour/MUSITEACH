<?php
// Titre de la page
$pageTitle = "Conditions d'utilisation";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12">
            <h1 class="mb-4">Conditions Générales d'Utilisation</h1>
            <p class="text-muted">Dernière mise à jour : <?= date('d/m/Y') ?></p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">1. Introduction</h3>
                    <p>Bienvenue sur MusiTeach (ci-après dénommé "le Service"). Les présentes Conditions Générales d'Utilisation régissent votre utilisation de notre site web et de nos services. En accédant ou en utilisant le Service, vous acceptez d'être lié par ces conditions. Si vous n'acceptez pas ces conditions, vous ne devez pas utiliser le Service.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">2. Définitions</h3>
                    <p><strong>"Utilisateur"</strong> : toute personne qui utilise le Service en tant qu'élève ou professeur.</p>
                    <p><strong>"Élève"</strong> : utilisateur qui recherche et réserve des cours de musique via le Service.</p>
                    <p><strong>"Professeur"</strong> : utilisateur qui offre des cours de musique via le Service.</p>
                    <p><strong>"Contenu"</strong> : toutes les informations et données (y compris les images, photos, vidéos, textes, messages, etc.) que vous publiez, téléchargez, partagez, stockez ou transmettez via le Service.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">3. Conditions d'accès et d'utilisation</h3>
                    <h5>3.1 Inscription</h5>
                    <p>Pour utiliser certaines fonctionnalités du Service, vous devez créer un compte. Vous vous engagez à fournir des informations exactes, complètes et à jour lors de votre inscription. Vous êtes responsable de la protection et de la confidentialité de vos identifiants de connexion.</p>
                    
                    <h5>3.2 Âge minimum</h5>
                    <p>Le Service est destiné aux utilisateurs âgés de 18 ans ou plus. Si vous êtes mineur, vous ne pouvez utiliser le Service qu'avec le consentement et sous la supervision d'un parent ou tuteur légal.</p>
                    
                    <h5>3.3 Utilisation acceptable</h5>
                    <p>Vous acceptez de ne pas utiliser le Service d'une manière qui pourrait endommager, désactiver, surcharger ou altérer le Service. Toute tentative d'accéder sans autorisation aux systèmes ou réseaux connectés au Service est strictement interdite.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">4. Cours et réservations</h3>
                    <h5>4.1 Réservation</h5>
                    <p>Les élèves peuvent réserver des cours avec les professeurs disponibles via le Service. Une réservation n'est confirmée qu'après acceptation par le professeur et paiement par l'élève, le cas échéant.</p>
                    
                    <h5>4.2 Annulation</h5>
                    <p>Les annulations sont soumises à la politique d'annulation spécifiée par chaque professeur. En général, une annulation effectuée moins de 24 heures avant le cours peut entraîner des frais.</p>
                    
                    <h5>4.3 Conflits</h5>
                    <p>En cas de conflit entre un élève et un professeur, MusiTeach s'efforcera de servir de médiateur, mais ne peut garantir une résolution satisfaisante pour toutes les parties.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">5. Contenu et propriété intellectuelle</h3>
                    <h5>5.1 Droits sur le contenu</h5>
                    <p>Vous conservez tous les droits de propriété intellectuelle sur le Contenu que vous soumettez au Service. Cependant, vous accordez à MusiTeach une licence mondiale, non exclusive, libre de redevance pour utiliser, reproduire, adapter, publier, traduire et distribuer votre Contenu dans le cadre de la fourniture du Service.</p>
                    
                    <h5>5.2 Contenu interdit</h5>
                    <p>Vous vous engagez à ne pas publier de Contenu illégal, offensant, menaçant, diffamatoire, frauduleux, ou qui enfreint les droits de propriété intellectuelle d'un tiers.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">6. Limitation de responsabilité</h3>
                    <p>MusiTeach n'est pas responsable de la qualité, de la sécurité ou de la légalité des cours proposés, ni de la capacité des professeurs à enseigner ou des élèves à payer. Le Service est fourni "tel quel" sans garantie d'aucune sorte.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">7. Modifications des conditions</h3>
                    <p>MusiTeach se réserve le droit de modifier ces Conditions Générales d'Utilisation à tout moment. Les modifications entrent en vigueur dès leur publication sur le Service. Votre utilisation continue du Service après de telles modifications constitue votre acceptation des nouvelles conditions.</p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">8. Loi applicable</h3>
                    <p>Ces conditions sont régies par les lois françaises. Tout litige relatif à ces conditions sera soumis à la compétence exclusive des tribunaux français.</p>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">9. Contact</h3>
                    <p>Pour toute question concernant ces Conditions Générales d'Utilisation, veuillez nous contacter à l'adresse suivante : contact@musicteach.com</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>