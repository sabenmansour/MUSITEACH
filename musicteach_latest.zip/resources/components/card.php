<?php
/**
 * Composant de carte
 * 
 * @param string $title Titre de la carte
 * @param string $content Contenu de la carte
 * @param string $footer Pied de la carte (optionnel)
 * @param string $headerClass Classes CSS supplémentaires pour l'en-tête
 * @param string $bodyClass Classes CSS supplémentaires pour le corps
 * @param string $footerClass Classes CSS supplémentaires pour le pied
 * @param string $cardClass Classes CSS supplémentaires pour la carte
 * @return string Le HTML de la carte
 */
function renderCard($title, $content, $footer = '', $headerClass = '', $bodyClass = '', $footerClass = '', $cardClass = '') {
    $footerHtml = '';
    if (!empty($footer)) {
        $footerHtml = <<<HTML
        <div class="card-footer {$footerClass}">
            {$footer}
        </div>
HTML;
    }

    return <<<HTML
    <div class="card {$cardClass}">
        <div class="card-header {$headerClass}">
            <h5 class="card-title mb-0">{$title}</h5>
        </div>
        <div class="card-body {$bodyClass}">
            {$content}
        </div>
        {$footerHtml}
    </div>
HTML;
}

/**
 * Composant de carte professeur
 * 
 * @param array $teacher Données du professeur
 * @param bool $showActions Afficher les boutons d'action
 * @return string Le HTML de la carte
 */
function renderTeacherCard($teacher, $showActions = true) {
    $instrument = isset($teacher['instrument']) && !empty($teacher['instrument']) 
        ? '<span class="badge bg-primary mb-2">' . htmlspecialchars($teacher['instrument']) . '</span>' 
        : '';
    
    $description = isset($teacher['description']) && !empty($teacher['description']) 
        ? htmlspecialchars(substr($teacher['description'], 0, 100)) . '...' 
        : 'Professeur de musique passionné prêt à partager son savoir.';
    
    $actions = '';
    if ($showActions) {
        $actions = <<<HTML
        <div class="mt-3">
            <a href="profile.php?id={$teacher['id']}" class="btn btn-primary">Voir le profil</a>
        </div>
HTML;
    }

    return <<<HTML
    <div class="card h-100">
        <img src="/resources/img/teacher-placeholder.jpg" class="card-img-top" alt="{$teacher['name']}">
        <div class="card-body">
            <h5 class="card-title">{$teacher['name']}</h5>
            <p class="card-text">
                {$instrument}
                {$description}
            </p>
            {$actions}
        </div>
    </div>
HTML;
}