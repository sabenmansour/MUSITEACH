<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/mail.php';
require_once __DIR__ . '/../app/models/User.php';

// Démarrer la session
startSession();

// Rediriger si déjà connecté
if (isLoggedIn()) {
    redirect('dashboard.php');
}

// Titre de la page
$pageTitle = "Renvoyer l'email de vérification";

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
        redirect('resend_verification.php');
    }
    
    $email = sanitizeInput($_POST['email'] ?? '');
    
    if (empty($email) || !isValidEmail($email)) {
        setFlashMessage('error', 'Veuillez fournir une adresse email valide.');
        redirect('resend_verification.php');
    }
    
    // Rechercher l'utilisateur
    $user = User::findByEmail($email);
    
    if ($user) {
        // Vérifier si le compte est déjà actif
        if ($user['is_active'] == 1) {
            setFlashMessage('info', 'Votre compte est déjà activé. Vous pouvez vous connecter dès maintenant.');
            redirect('login.php');
        }
        
        // Générer un nouveau token d'activation
        $token = User::generateNewActivationToken($user['id']);
        
        if ($token) {
            // Envoyer un nouvel email de vérification
            sendVerificationEmail($user['email'], $user['name'], $token);
            setFlashMessage('success', 'Un nouvel email de vérification a été envoyé. Veuillez vérifier votre boîte de réception.');
            redirect('login.php');
        } else {
            setFlashMessage('error', 'Une erreur est survenue lors de la génération d\'un nouveau lien de vérification.');
            redirect('resend_verification.php');
        }
    } else {
        // Ne pas révéler si l'email existe ou non pour des raisons de sécurité
        setFlashMessage('success', 'Si cette adresse email existe dans notre système, un nouvel email de vérification a été envoyé.');
        redirect('login.php');
    }
}

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="card-title text-center mb-4">Renvoyer l'email de vérification</h1>
                
                <p class="text-center mb-4">Si vous n'avez pas reçu l'email de vérification ou si le lien a expiré, vous pouvez demander un nouvel email en renseignant votre adresse email ci-dessous.</p>
                
                <form action="resend_verification.php" method="post">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Adresse email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Renvoyer l'email de vérification</button>
                    </div>
                </form>
                
                <div class="text-center mt-3">
                    <a href="login.php">Retour à la page de connexion</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>