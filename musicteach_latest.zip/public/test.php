<?php
// Test file to verify PHP is working
echo "<!DOCTYPE html><html><head><title>PHP Test</title></head><body>";
echo "<h1>PHP Test</h1>";
echo "<p>Current time: " . date("Y-m-d H:i:s") . "</p>";
echo "<p>PHP version: " . phpversion() . "</p>";
echo "</body></html>";
?>