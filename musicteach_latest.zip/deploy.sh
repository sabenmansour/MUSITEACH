#!/bin/bash

# Définition des couleurs pour un affichage plus clair
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Définition des chemins
APP_DIR="$(pwd)"
BACKUP_DIR="${APP_DIR}/BACKUP"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/musicteach_backup_${TIMESTAMP}.tar.gz"

echo -e "${BLUE}=== MusiTeach Deployment Tool ===${NC}"
echo "Current directory: ${APP_DIR}"

# Fonction pour la sauvegarde
backup_app() {
    echo -e "${YELLOW}Creating backup...${NC}"
    
    # S'assurer que le dossier de sauvegarde existe
    mkdir -p "${BACKUP_DIR}"
    
    # Créer une archive de l'application (excluant le dossier BACKUP et certains fichiers)
    tar -czf "${BACKUP_FILE}" --exclude="BACKUP" --exclude="node_modules" --exclude=".git" .
    
    # Vérifier si la sauvegarde a réussi
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Backup created successfully: ${BACKUP_FILE}${NC}"
    else
        echo -e "${RED}Backup creation failed${NC}"
        exit 1
    fi
}

# Fonction pour arrêter les containers
stop_containers() {
    echo -e "${YELLOW}Stopping existing containers...${NC}"
    docker-compose down
    echo -e "${GREEN}Containers stopped${NC}"
}

# Fonction pour démarrer les containers
start_containers() {
    echo -e "${YELLOW}Starting containers...${NC}"
    
    # Construire et démarrer les containers
    docker-compose up -d --build
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Containers started successfully${NC}"
        echo -e "${GREEN}MusiTeach is now available at: http://localhost:8000${NC}"
    else
        echo -e "${RED}Failed to start containers${NC}"
        exit 1
    fi
}

# Fonction pour installer les dépendances PHP
install_dependencies() {
    echo -e "${YELLOW}Installing PHP dependencies inside the container...${NC}"
    
    # Installer les extensions PHP nécessaires
    docker-compose exec webserver bash -c "apt-get update && \
        apt-get install -y libpq-dev libzip-dev zip unzip && \
        docker-php-ext-install pdo pdo_mysql zip && \
        a2enmod rewrite"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Dependencies installed successfully${NC}"
    else
        echo -e "${RED}Failed to install dependencies${NC}"
        return 1
    fi
}

# Fonction pour initialiser la base de données
initialize_database() {
    echo -e "${YELLOW}Initializing database...${NC}"
    
    # Attendre que MySQL soit prêt
    echo "Waiting for MySQL to be ready..."
    sleep 10
    
    # Exécuter le schéma SQL
    docker-compose exec mysql bash -c "mysql -u musicteach -pmusicteach musicteach < /docker-entrypoint-initdb.d/schema.sql"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Database initialized successfully${NC}"
    else
        echo -e "${RED}Failed to initialize database${NC}"
        return 1
    fi
}

# Menu principal
show_menu() {
    echo
    echo -e "${BLUE}=== Options ===${NC}"
    echo "1) Backup and deploy"
    echo "2) Only create backup"
    echo "3) Only deploy (no backup)"
    echo "4) Stop containers"
    echo "5) Exit"
    echo
    read -p "Enter your choice [1-5]: " choice
    
    case $choice in
        1)
            backup_app
            stop_containers
            start_containers
            install_dependencies
            initialize_database
            ;;
        2)
            backup_app
            ;;
        3)
            stop_containers
            start_containers
            install_dependencies
            initialize_database
            ;;
        4)
            stop_containers
            ;;
        5)
            echo -e "${GREEN}Exiting...${NC}"
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid choice. Please try again.${NC}"
            show_menu
            ;;
    esac
}

# Démarrer le menu
show_menu

echo -e "${GREEN}Done!${NC}"