<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Titre de la page
$pageTitle = "Accueil";

// Pas de récupération de professeurs pour le moment
$featuredTeachers = [];

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container text-center">
        <h1>Trouvez le prof de musique parfait en quelques clics</h1>
        <p class="mx-auto">Cours particuliers avec des professeurs qualifiés, en présentiel ou en ligne, pour tous niveaux et tous instruments.</p>
        <a href="teachers.php" class="btn btn-primary btn-lg">Découvrir les professeurs</a>
    </div>
</section>

<!-- Comment ça marche -->
<section class="how-it-works my-5">
    <div class="container">
        <h2 class="text-center mb-5">Comment ça marche ?</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="text-center feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3>Recherchez</h3>
                    <p>Trouvez facilement le professeur de musique idéal parmi nos nombreux profils vérifiés.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="text-center feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <h3>Réservez</h3>
                    <p>Choisissez une date et un horaire qui vous conviennent et réservez votre cours en quelques clics.</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="text-center feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-music"></i>
                    </div>
                    <h3>Apprenez</h3>
                    <p>Profitez de cours de qualité et progressez à votre rythme avec un suivi personnalisé.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>
