-- Structure des tables pour la gestion des instruments

-- Table des instruments
CREATE TABLE IF NOT EXISTS `instruments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table de relation entre professeurs et instruments
CREATE TABLE IF NOT EXISTS `teacher_instruments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `instrument_id` int(11) NOT NULL,
  `level` enum('beginner', 'intermediate', 'advanced', 'all') NOT NULL DEFAULT 'all',
  `description` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teacher_instrument` (`teacher_id`,`instrument_id`),
  FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`instrument_id`) REFERENCES `instruments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Données initiales pour les instruments
INSERT INTO `instruments` (`name`, `category`) VALUES
-- Cordes
('Violon', 'Cordes'),
('Alto', 'Cordes'),
('Violoncelle', 'Cordes'),
('Contrebasse', 'Cordes'),
('Guitare classique', 'Cordes'),
('Guitare acoustique', 'Cordes'),
('Guitare électrique', 'Cordes'),
('Basse électrique', 'Cordes'),
('Harpe', 'Cordes'),
('Ukulélé', 'Cordes'),
('Banjo', 'Cordes'),
('Mandoline', 'Cordes'),
('Luth', 'Cordes'),

-- Vents - Bois
('Flûte traversière', 'Vents - Bois'),
('Flûte à bec', 'Vents - Bois'),
('Clarinette', 'Vents - Bois'),
('Hautbois', 'Vents - Bois'),
('Basson', 'Vents - Bois'),
('Saxophone', 'Vents - Bois'),

-- Vents - Cuivres
('Trompette', 'Vents - Cuivres'),
('Trombone', 'Vents - Cuivres'),
('Cor', 'Vents - Cuivres'),
('Tuba', 'Vents - Cuivres'),
('Cor d\'harmonie', 'Vents - Cuivres'),

-- Percussions
('Batterie', 'Percussions'),
('Percussion classique', 'Percussions'),
('Djembé', 'Percussions'),
('Congas', 'Percussions'),
('Cajon', 'Percussions'),
('Marimba', 'Percussions'),
('Vibraphone', 'Percussions'),
('Xylophone', 'Percussions'),

-- Claviers
('Piano', 'Claviers'),
('Piano électrique', 'Claviers'),
('Synthétiseur', 'Claviers'),
('Orgue', 'Claviers'),
('Clavecin', 'Claviers'),
('Accordéon', 'Claviers'),

-- Voix
('Chant lyrique', 'Voix'),
('Chant moderne', 'Voix'),
('Technique vocale', 'Voix'),
('Coaching vocal', 'Voix'),

-- Traditionnels
('Cornemuse', 'Traditionnels'),
('Flûte irlandaise', 'Traditionnels'),
('Sitar', 'Traditionnels'),
('Oud', 'Traditionnels'),
('Tabla', 'Traditionnels'),
('Erhu', 'Traditionnels'),

-- Autres
('Composition', 'Autres'),
('Direction d\'orchestre', 'Autres'),
('Théorie musicale', 'Autres'),
('Éveil musical', 'Autres'),
('MAO (Musique Assistée par Ordinateur)', 'Autres'),
('Solfège', 'Autres');

-- Add availability_slots table for teacher schedules
CREATE TABLE IF NOT EXISTS `availability_slots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `day_of_week` tinyint(1) NOT NULL COMMENT '0=Sunday, 1=Monday, ..., 6=Saturday',
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT '1',
  `specific_date` date DEFAULT NULL COMMENT 'For non-recurring slots',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teacher_day` (`teacher_id`, `day_of_week`),
  FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;