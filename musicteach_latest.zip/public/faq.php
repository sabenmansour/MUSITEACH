<?php
// Titre de la page
$pageTitle = "Foire Aux Questions";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12 text-center" data-aos="fade-up">
            <h1 class="mb-3">Foire Aux Questions</h1>
            <p class="lead">Vous avez des questions ? Nous avons les réponses.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Onglets pour les catégories de FAQ -->
            <ul class="nav nav-pills mb-4 justify-content-center" id="faq-tabs" role="tablist" data-aos="fade-up">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active px-4" id="general-tab" data-bs-toggle="pill" data-bs-target="#general" 
                            type="button" role="tab" aria-controls="general" aria-selected="true">
                        Général
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-4" id="students-tab" data-bs-toggle="pill" data-bs-target="#students" 
                            type="button" role="tab" aria-controls="students" aria-selected="false">
                        Pour les élèves
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-4" id="teachers-tab" data-bs-toggle="pill" data-bs-target="#teachers" 
                            type="button" role="tab" aria-controls="teachers" aria-selected="false">
                        Pour les professeurs
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-4" id="payment-tab" data-bs-toggle="pill" data-bs-target="#payment" 
                            type="button" role="tab" aria-controls="payment" aria-selected="false">
                        Paiement
                    </button>
                </li>
            </ul>

            <!-- Contenu des onglets FAQ -->
            <div class="tab-content" id="faq-tabContent">
                <!-- Questions générales -->
                <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                    <div class="accordion" id="accordionGeneral" data-aos="fade-up">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Qu'est-ce que MusiTeach ?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionGeneral">
                                <div class="accordion-body">
                                    <p>MusiTeach est une plateforme qui met en relation les professeurs de musique qualifiés avec des élèves de tous niveaux. Notre mission est de rendre l'apprentissage de la musique accessible à tous, en proposant une solution simple pour trouver le professeur idéal et réserver des cours en quelques clics.</p>
                                    <p>Que vous soyez débutant ou musicien confirmé, vous trouverez sur MusiTeach des professeurs adaptés à votre niveau, votre instrument et vos objectifs.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Quels instruments peut-on apprendre sur MusiTeach ?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionGeneral">
                                <div class="accordion-body">
                                    <p>MusiTeach propose des cours pour une grande variété d'instruments, notamment :</p>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <ul>
                                                <li>Piano</li>
                                                <li>Guitare (acoustique, électrique, classique)</li>
                                                <li>Basse</li>
                                                <li>Batterie et percussions</li>
                                                <li>Violon</li>
                                                <li>Violoncelle</li>
                                                <li>Contrebasse</li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <ul>
                                                <li>Flûte</li>
                                                <li>Clarinette</li>
                                                <li>Saxophone</li>
                                                <li>Trompette</li>
                                                <li>Chant</li>
                                                <li>Ukulélé</li>
                                                <li>Et bien d'autres...</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <p>Si vous ne trouvez pas l'instrument que vous souhaitez apprendre, contactez-nous et nous ferons notre possible pour vous aider à trouver un professeur adapté.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Les cours sont-ils en ligne ou en présentiel ?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionGeneral">
                                <div class="accordion-body">
                                    <p>MusiTeach propose à la fois des cours en ligne et en présentiel, selon les préférences de l'élève et les disponibilités du professeur.</p>
                                    <p><strong>Cours en présentiel :</strong> Le professeur se déplace chez l'élève ou accueille l'élève à son domicile ou dans son studio.</p>
                                    <p><strong>Cours en ligne :</strong> Les cours se déroulent via des plateformes de visioconférence comme Zoom, Skype ou Google Meet, permettant une grande flexibilité géographique et horaire.</p>
                                    <p>Vous pouvez filtrer votre recherche de professeurs selon le mode d'enseignement qui vous convient le mieux.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    Comment sont sélectionnés les professeurs ?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionGeneral">
                                <div class="accordion-body">
                                    <p>Chez MusiTeach, nous mettons un point d'honneur à sélectionner des professeurs qualifiés et passionnés. Notre processus de sélection comprend :</p>
                                    <ol>
                                        <li><strong>Vérification des diplômes</strong> : Nous vérifions les qualifications et l'expérience de chaque professeur.</li>
                                        <li><strong>Entretien individuel</strong> : Nous nous entretenons avec chaque professeur pour évaluer ses compétences pédagogiques et sa motivation.</li>
                                        <li><strong>Références</strong> : Nous demandons et vérifions les références auprès d'anciens élèves ou employeurs.</li>
                                        <li><strong>Contrôle de qualité continu</strong> : Nous surveillons les retours des élèves pour maintenir un niveau d'enseignement élevé.</li>
                                    </ol>
                                    <p>Les professeurs sont également évalués par leurs élèves, ce qui vous permet de choisir en fonction des avis et des notes.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Questions pour les élèves -->
                <div class="tab-pane fade" id="students" role="tabpanel" aria-labelledby="students-tab">
                    <div class="accordion" id="accordionStudents" data-aos="fade-up">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
                                    Comment réserver un cours ?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse show" aria-labelledby="headingFive" data-bs-parent="#accordionStudents">
                                <div class="accordion-body">
                                    <p>Réserver un cours sur MusiTeach est simple et rapide :</p>
                                    <ol>
                                        <li><strong>Créez un compte</strong> ou connectez-vous à votre compte existant.</li>
                                        <li><strong>Recherchez un professeur</strong> en utilisant nos filtres (instrument, localisation, tarifs, etc.).</li>
                                        <li><strong>Consultez les profils</strong> des professeurs, leurs qualifications, expériences et avis.</li>
                                        <li><strong>Choisissez un professeur</strong> et cliquez sur "Réserver un cours".</li>
                                        <li><strong>Sélectionnez une date et un horaire</strong> parmi les disponibilités du professeur.</li>
                                        <li><strong>Confirmez votre réservation</strong> et procédez au paiement.</li>
                                    </ol>
                                    <p>Vous recevrez ensuite une confirmation de réservation par email, avec toutes les informations nécessaires pour votre cours.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingSix">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                    Comment annuler ou reporter un cours ?
                                </button>
                            </h2>
                            <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionStudents">
                                <div class="accordion-body">
                                    <p>Pour annuler ou reporter un cours :</p>
                                    <ol>
                                        <li>Connectez-vous à votre compte MusiTeach.</li>
                                        <li>Accédez à la section "Mes réservations" dans votre tableau de bord.</li>
                                        <li>Sélectionnez le cours concerné et cliquez sur "Annuler" ou "Reporter".</li>
                                    </ol>
                                    <p><strong>Politique d'annulation :</strong></p>
                                    <ul>
                                        <li>Annulation plus de 24 heures avant le cours : remboursement intégral.</li>
                                        <li>Annulation moins de 24 heures avant le cours : aucun remboursement (sauf cas de force majeure).</li>
                                        <li>Report du cours : possible gratuitement au moins 24 heures à l'avance, sous réserve de disponibilité du professeur.</li>
                                    </ul>
                                    <p>Nous encourageons une communication directe avec votre professeur pour toute modification de planning.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingSeven">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                    Puis-je prendre un seul cours ou dois-je réserver un forfait ?
                                </button>
                            </h2>
                            <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionStudents">
                                <div class="accordion-body">
                                    <p>MusiTeach offre une flexibilité totale dans la réservation des cours :</p>
                                    <ul>
                                        <li><strong>Cours unique</strong> : Vous pouvez réserver un seul cours, idéal pour essayer un professeur ou pour une remise à niveau ponctuelle.</li>
                                        <li><strong>Forfaits de cours</strong> : Nous proposons des forfaits de 5, 10 ou 20 cours à prix avantageux, recommandés pour un apprentissage régulier et progressif.</li>
                                        <li><strong>Abonnement mensuel</strong> : Certains professeurs proposent des abonnements avec un nombre de cours fixe par mois, offrant une réduction supplémentaire.</li>
                                    </ul>
                                    <p>Chaque professeur définit ses propres tarifs et forfaits, que vous pouvez consulter sur son profil.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingEight">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                    Dois-je déjà posséder un instrument pour prendre des cours ?
                                </button>
                            </h2>
                            <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight" data-bs-parent="#accordionStudents">
                                <div class="accordion-body">
                                    <p>Pour un apprentissage optimal, il est généralement recommandé de posséder ou d'avoir accès à l'instrument que vous souhaitez apprendre, afin de pouvoir pratiquer entre les cours.</p>
                                    <p>Cependant, plusieurs options s'offrent à vous si vous n'avez pas encore d'instrument :</p>
                                    <ul>
                                        <li><strong>Cours chez le professeur</strong> : Certains professeurs disposent d'instruments que vous pouvez utiliser pendant les cours.</li>
                                        <li><strong>Location</strong> : Votre professeur peut vous conseiller sur les options de location d'instruments, souvent disponibles à des prix raisonnables.</li>
                                        <li><strong>Achat d'un instrument débutant</strong> : Votre professeur peut vous guider dans le choix d'un premier instrument adapté à votre budget.</li>
                                        <li><strong>Accès à un instrument</strong> : Si vous avez accès à un instrument dans une école de musique, un centre culturel ou chez des amis, cela peut suffire pour débuter.</li>
                                    </ul>
                                    <p>N'hésitez pas à discuter de cette question avec votre professeur avant le premier cours. Il pourra vous donner des conseils personnalisés en fonction de votre situation.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Questions pour les professeurs -->
                <div class="tab-pane fade" id="teachers" role="tabpanel" aria-labelledby="teachers-tab">
                    <div class="accordion" id="accordionTeachers" data-aos="fade-up">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingNine">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="true" aria-controls="collapseNine">
                                    Comment devenir professeur sur MusiTeach ?
                                </button>
                            </h2>
                            <div id="collapseNine" class="accordion-collapse collapse show" aria-labelledby="headingNine" data-bs-parent="#accordionTeachers">
                                <div class="accordion-body">
                                    <p>Pour rejoindre MusiTeach en tant que professeur, suivez ces étapes :</p>
                                    <ol>
                                        <li><strong>Inscription</strong> : Créez un compte sur MusiTeach et sélectionnez l'option "Je suis professeur".</li>
                                        <li><strong>Complétez votre profil</strong> : Renseignez vos informations personnelles, qualifications, expérience, et l'instrument que vous enseignez.</li>
                                        <li><strong>Téléchargez vos documents</strong> : Fournissez des copies de vos diplômes, certifications et autres documents pertinents.</li>
                                        <li><strong>Définissez vos tarifs et disponibilités</strong> : Indiquez vos tarifs horaires, forfaits éventuels et plages horaires disponibles.</li>
                                        <li><strong>Validation</strong> : Notre équipe examinera votre candidature et pourra vous contacter pour un entretien.</li>
                                        <li><strong>Activation du profil</strong> : Une fois validé, votre profil sera visible pour les élèves potentiels.</li>
                                    </ol>
                                    <p>Nous privilégions les professeurs ayant une formation musicale solide et/ou une expérience d'enseignement démontrable, mais nous étudions chaque candidature individuellement.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTen">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                    Quels sont les frais pour les professeurs ?
                                </button>
                            </h2>
                            <div id="collapseTen" class="accordion-collapse collapse" aria-labelledby="headingTen" data-bs-parent="#accordionTeachers">
                                <div class="accordion-body">
                                    <p>MusiTeach fonctionne sur un modèle de commission :</p>
                                    <ul>
                                        <li>L'inscription et la création d'un profil sont <strong>gratuites</strong>.</li>
                                        <li>MusiTeach prélève une commission de <strong>15%</strong> sur chaque cours réservé via la plateforme.</li>
                                        <li>Cette commission couvre les frais de service, de marketing, de paiement sécurisé et de support client.</li>
                                        <li>Les paiements sont versés aux professeurs chaque semaine pour les cours effectués.</li>
                                    </ul>
                                    <p><strong>Exemple :</strong> Si vous fixez votre tarif à 40€ de l'heure, vous recevrez 34€ après déduction de la commission de 15%.</p>
                                    <p>En retour, MusiTeach vous offre :</p>
                                    <ul>
                                        <li>Une visibilité auprès d'élèves potentiels</li>
                                        <li>Un système de réservation et de paiement sécurisé</li>
                                        <li>Une gestion simplifiée de votre planning</li>
                                        <li>Un support client réactif</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingEleven">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                                    Comment gérer mon planning et mes disponibilités ?
                                </button>
                            </h2>
                            <div id="collapseEleven" class="accordion-collapse collapse" aria-labelledby="headingEleven" data-bs-parent="#accordionTeachers">
                                <div class="accordion-body">
                                    <p>MusiTeach offre un système intuitif de gestion de planning :</p>
                                    <ol>
                                        <li><strong>Tableau de bord</strong> : Accédez à votre espace professeur pour gérer votre planning.</li>
                                        <li><strong>Calendrier interactif</strong> : Définissez vos plages horaires disponibles à l'avance.</li>
                                        <li><strong>Récurrence</strong> : Configurez des disponibilités récurrentes (toutes les semaines, tous les mardis, etc.).</li>
                                        <li><strong>Blocage de plages horaires</strong> : Bloquez facilement des périodes où vous n'êtes pas disponible (vacances, engagements professionnels).</li>
                                        <li><strong>Synchronisation</strong> : Possibilité de synchroniser avec votre calendrier personnel (Google Calendar, iCal, etc.).</li>
                                        <li><strong>Notifications</strong> : Recevez des alertes pour les nouvelles réservations, modifications ou annulations.</li>
                                    </ol>
                                    <p>Vous gardez le contrôle total sur votre emploi du temps et pouvez l'ajuster à tout moment selon vos contraintes.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwelve">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                                    Comment optimiser mon profil pour attirer plus d'élèves ?
                                </button>
                            </h2>
                            <div id="collapseTwelve" class="accordion-collapse collapse" aria-labelledby="headingTwelve" data-bs-parent="#accordionTeachers">
                                <div class="accordion-body">
                                    <p>Voici nos conseils pour maximiser l'attractivité de votre profil :</p>
                                    <ol>
                                        <li><strong>Photo professionnelle</strong> : Utilisez une photo de qualité, bien éclairée, où vous apparaissez souriant et professionnel.</li>
                                        <li><strong>Description complète</strong> : Rédigez une biographie détaillée, mettant en avant votre parcours, votre style d'enseignement et votre passion pour la musique.</li>
                                        <li><strong>Détaillez vos compétences</strong> : Précisez les styles musicaux, niveaux et techniques que vous enseignez.</li>
                                        <li><strong>Partagez votre expérience</strong> : Mentionnez vos diplômes, années d'expérience, concerts notables ou élèves ayant réussi.</li>
                                        <li><strong>Ajoutez des médias</strong> : Intégrez des extraits audio ou vidéo de vos performances ou de vos élèves (avec leur permission).</li>
                                        <li><strong>Soyez réactif</strong> : Répondez rapidement aux demandes et questions des élèves potentiels.</li>
                                        <li><strong>Collectez des avis</strong> : Encouragez vos élèves satisfaits à laisser des commentaires positifs.</li>
                                        <li><strong>Offrez des options flexibles</strong> : Proposez différentes durées de cours, niveaux et formats (en ligne/présentiel).</li>
                                    </ol>
                                    <p>N'hésitez pas à mettre régulièrement à jour votre profil pour refléter vos nouvelles compétences ou réalisations.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Questions sur le paiement -->
                <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="payment-tab">
                    <div class="accordion" id="accordionPayment" data-aos="fade-up">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThirteen">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThirteen" aria-expanded="true" aria-controls="collapseThirteen">
                                    Quelles sont les méthodes de paiement acceptées ?
                                </button>
                            </h2>
                            <div id="collapseThirteen" class="accordion-collapse collapse show" aria-labelledby="headingThirteen" data-bs-parent="#accordionPayment">
                                <div class="accordion-body">
                                    <p>MusiTeach accepte plusieurs méthodes de paiement pour vous offrir un maximum de flexibilité :</p>
                                    <ul>
                                        <li><strong>Cartes bancaires</strong> : Visa, Mastercard, American Express</li>
                                        <li><strong>Portefeuilles électroniques</strong> : PayPal, Apple Pay, Google Pay</li>
                                        <li><strong>Virement bancaire</strong> : Pour certains forfaits ou abonnements</li>
                                    </ul>
                                    <p>Tous les paiements sont sécurisés et traités par des prestataires de confiance conformes aux normes de sécurité PCI DSS. Vos informations bancaires ne sont jamais stockées sur nos serveurs.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFourteen">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFourteen" aria-expanded="false" aria-controls="collapseFourteen">
                                    Quand suis-je débité pour mes cours ?
                                </button>
                            </h2>
                            <div id="collapseFourteen" class="accordion-collapse collapse" aria-labelledby="headingFourteen" data-bs-parent="#accordionPayment">
                                <div class="accordion-body">
                                    <p>Le paiement est traité différemment selon le type de réservation :</p>
                                    <ul>
                                        <li><strong>Cours uniques</strong> : Le paiement est prélevé immédiatement lors de la confirmation de la réservation.</li>
                                        <li><strong>Forfaits</strong> : Le montant total du forfait est prélevé au moment de l'achat.</li>
                                        <li><strong>Abonnements</strong> : Le prélèvement est automatique au début de chaque période (généralement mensuel).</li>
                                    </ul>
                                    <p>En cas d'annulation respectant notre politique (plus de 24h avant le cours), le remboursement est traité sous 3 à 5 jours ouvrés, selon votre banque.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFifteen">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFifteen" aria-expanded="false" aria-controls="collapseFifteen">
                                    Les prix affichés sont-ils définitifs ?
                                </button>
                            </h2>
                            <div id="collapseFifteen" class="accordion-collapse collapse" aria-labelledby="headingFifteen" data-bs-parent="#accordionPayment">
                                <div class="accordion-body">
                                    <p>Oui, les prix affichés sur les profils des professeurs sont définitifs et incluent tous les frais de service MusiTeach. Il n'y a pas de frais supplémentaires cachés pour les élèves.</p>
                                    <p>Points importants :</p>
                                    <ul>
                                        <li>Chaque professeur fixe librement ses tarifs.</li>
                                        <li>Les prix peuvent varier selon le niveau d'expérience du professeur, l'instrument enseigné et la localisation.</li>
                                        <li>Des remises peuvent s'appliquer pour les forfaits de plusieurs cours ou les abonnements.</li>
                                        <li>Certains professeurs peuvent facturer des frais de déplacement supplémentaires pour les cours à domicile, mais ces frais sont toujours clairement indiqués sur leur profil.</li>
                                    </ul>
                                    <p>Vous verrez toujours le prix total avant de confirmer votre réservation.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingSixteen">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSixteen" aria-expanded="false" aria-controls="collapseSixteen">
                                    Comment obtenir une facture pour mes cours ?
                                </button>
                            </h2>
                            <div id="collapseSixteen" class="accordion-collapse collapse" aria-labelledby="headingSixteen" data-bs-parent="#accordionPayment">
                                <div class="accordion-body">
                                    <p>Obtenir une facture pour vos cours est simple :</p>
                                    <ol>
                                        <li>Les factures sont automatiquement générées pour chaque paiement effectué sur la plateforme.</li>
                                        <li>Vous pouvez les télécharger directement depuis votre tableau de bord, dans la section "Historique des paiements".</li>
                                        <li>Les factures contiennent toutes les informations nécessaires : détails du cours, montant, date, coordonnées du professeur et numéro de TVA le cas échéant.</li>
                                    </ol>
                                    <p>Si vous avez besoin d'une facture spécifique (par exemple pour une entreprise ou avec des mentions particulières), vous pouvez en faire la demande via notre formulaire de contact ou directement auprès du service client.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Contact supplémentaire -->
            <div class="card mt-5 text-center" data-aos="fade-up">
                <div class="card-body py-4">
                    <h4 class="mb-3">Vous n'avez pas trouvé la réponse à votre question ?</h4>
                    <p class="mb-4">Notre équipe est disponible pour vous aider.</p>
                    <a href="contact.php" class="btn btn-primary px-4 py-2">
                        <i class="fas fa-envelope me-2"></i>Nous contacter
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>