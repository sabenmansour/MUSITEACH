<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Traitement du formulaire si soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
        redirect('admin_user_add.php');
    }
    
    // Récupérer et nettoyer les données du formulaire
    $name = sanitizeInput($_POST['name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $role = sanitizeInput($_POST['role'] ?? '');
    $description = sanitizeInput($_POST['description'] ?? '');
    $instrument = sanitizeInput($_POST['instrument'] ?? '');
    $experience = sanitizeInput($_POST['experience'] ?? '');
    
    // Validation
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Le nom est requis.';
    }
    
    if (empty($email) || !isValidEmail($email)) {
        $errors[] = 'L\'adresse email est invalide.';
    } elseif (User::emailExists($email)) {
        $errors[] = 'Cette adresse email est déjà utilisée.';
    }
    
    if (empty($password)) {
        $errors[] = 'Le mot de passe est requis.';
    } elseif (strlen($password) < 8) {
        $errors[] = 'Le mot de passe doit contenir au moins 8 caractères.';
    }
    
    if ($password !== $confirmPassword) {
        $errors[] = 'Les mots de passe ne correspondent pas.';
    }
    
    if (!in_array($role, ['student', 'teacher', 'admin'])) {
        $errors[] = 'Le rôle sélectionné est invalide.';
    }
    
    // S'il y a des erreurs, afficher un message d'erreur
    if (!empty($errors)) {
        setFlashMessage('error', implode(' ', $errors));
    } else {
        // Créer l'utilisateur
        try {
            $userId = User::create($name, $email, $password, $role);
            
            // Créer le profil de base
            $profileType = $role === 'admin' ? 'teacher' : $role; // Les admins ont un profil de type 'teacher'
            
            $profileData = [
                'type' => $profileType,
                'description' => $description,
                'instrument' => $instrument,
                'experience' => $experience
            ];
            
            Profile::create($userId, $profileType, $description, $instrument, $experience);
            
            setFlashMessage('success', 'L\'utilisateur a été créé avec succès.');
            redirect('admin_users.php');
        } catch (Exception $e) {
            setFlashMessage('error', 'Une erreur est survenue lors de la création de l\'utilisateur.');
        }
    }
}

// Titre de la page
$pageTitle = "Ajouter un utilisateur";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Ajouter un utilisateur</h1>
    
    <div class="card">
        <div class="card-body">
            <form action="admin_user_add.php" method="post">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <input type="hidden" name="create_user" value="1">
                
                <div class="mb-3">
                    <label for="name" class="form-label">Nom</label>
                    <input type="text" class="form-control" id="name" name="name" required 
                           value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required 
                           value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">Mot de passe</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                    <div class="form-text">Le mot de passe doit contenir au moins 8 caractères.</div>
                </div>
                
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirmer le mot de passe</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                
                <div class="mb-3">
                    <label for="role" class="form-label">Rôle</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="student" <?= isset($_POST['role']) && $_POST['role'] === 'student' ? 'selected' : '' ?>>Élève</option>
                        <option value="teacher" <?= isset($_POST['role']) && $_POST['role'] === 'teacher' ? 'selected' : '' ?>>Professeur</option>
                        <option value="admin" <?= isset($_POST['role']) && $_POST['role'] === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                    </select>
                </div>
                
                <!-- Champs spécifiques au profil -->
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                </div>
                
                <div class="mb-3">
                    <label for="instrument" class="form-label">Instrument (pour les professeurs)</label>
                    <input type="text" class="form-control" id="instrument" name="instrument" 
                           value="<?= isset($_POST['instrument']) ? htmlspecialchars($_POST['instrument']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="experience" class="form-label">Expérience (pour les professeurs)</label>
                    <textarea class="form-control" id="experience" name="experience" rows="3"><?= isset($_POST['experience']) ? htmlspecialchars($_POST['experience']) : '' ?></textarea>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="admin_users.php" class="btn btn-secondary">Annuler</a>
                    <button type="submit" class="btn btn-primary">Créer l'utilisateur</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>