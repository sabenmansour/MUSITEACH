<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';
require_once __DIR__ . '/../app/models/Booking.php';
require_once __DIR__ . '/../app/db_connect.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Récupérer quelques statistiques
$db = getDbConnection();

// Total des utilisateurs
$totalUsers = User::count();

// Total des professeurs
$totalTeachers = User::countTeachers();

// Total des élèves
$stmt = $db->query("SELECT COUNT(*) FROM users WHERE role = 'student'");
$totalStudents = $stmt->fetchColumn();

// Total des réservations
$stmt = $db->query("SELECT COUNT(*) FROM bookings");
$totalBookings = $stmt->fetchColumn();

// Réservations par statut
$stmt = $db->query("SELECT status, COUNT(*) as count FROM bookings GROUP BY status");
$bookingsByStatus = $stmt->fetchAll();

// Utilisateurs récents
$recentUsers = User::findAll(1, 5);

// Réservations récentes
$stmt = $db->prepare(
    "SELECT b.*, 
     t.name as teacher_name, 
     s.name as student_name 
     FROM bookings b
     JOIN users t ON b.teacher_id = t.id
     JOIN users s ON b.student_id = s.id
     ORDER BY b.created_at DESC
     LIMIT 5"
);
$stmt->execute();
$recentBookings = $stmt->fetchAll();

// Titre de la page
$pageTitle = "Tableau de bord administrateur";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Tableau de bord administrateur</h1>
    
    <!-- Actions rapides -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Actions rapides</h5>
                    <div class="d-flex gap-2">
                        <a href="admin_dashboard.php" class="btn btn-primary">
                            <i class="fas fa-tachometer-alt me-2"></i>Tableau de bord
                        </a>
                        <a href="admin_users.php" class="btn btn-outline-primary">
                            <i class="fas fa-users me-2"></i>Utilisateurs
                        </a>
                        <a href="admin_bookings.php" class="btn btn-outline-primary">
                            <i class="fas fa-calendar-alt me-2"></i>Réservations
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Statistiques -->
    <div class="row mb-4">
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white h-100">
                <div class="card-body text-center">
                    <i class="fas fa-users fa-3x mb-3"></i>
                    <h3 class="card-title h4">Utilisateurs</h3>
                    <p class="card-text display-4"><?= $totalUsers ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white h-100">
                <div class="card-body text-center">
                    <i class="fas fa-chalkboard-teacher fa-3x mb-3"></i>
                    <h3 class="card-title h4">Professeurs</h3>
                    <p class="card-text display-4"><?= $totalTeachers ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-info text-white h-100">
                <div class="card-body text-center">
                    <i class="fas fa-user-graduate fa-3x mb-3"></i>
                    <h3 class="card-title h4">Élèves</h3>
                    <p class="card-text display-4"><?= $totalStudents ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-white h-100">
                <div class="card-body text-center">
                    <i class="fas fa-calendar-check fa-3x mb-3"></i>
                    <h3 class="card-title h4">Réservations</h3>
                    <p class="card-text display-4"><?= $totalBookings ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Graphiques et statistiques détaillées -->
    <div class="row mb-4">
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Réservations par statut</h5>
                    <div class="d-flex justify-content-around mt-4">
                        <?php
                        $statusCounts = ['pending' => 0, 'confirmed' => 0, 'canceled' => 0];
                        
                        foreach ($bookingsByStatus as $status) {
                            $statusCounts[$status['status']] = $status['count'];
                        }
                        
                        $statusLabels = [
                            'pending' => ['En attente', 'bg-warning'],
                            'confirmed' => ['Confirmées', 'bg-success'],
                            'canceled' => ['Annulées', 'bg-danger']
                        ];
                        
                        foreach ($statusCounts as $status => $count) {
                            $percentage = $totalBookings > 0 ? round(($count / $totalBookings) * 100) : 0;
                            
                            echo '<div class="text-center">';
                            echo '<div class="progress-circle position-relative" style="width: 100px; height: 100px;">';
                            echo '<div class="progress-circle-bg ' . $statusLabels[$status][1] . ' d-flex align-items-center justify-content-center text-white rounded-circle" style="width: 100px; height: 100px; font-size: 24px; font-weight: bold;">' . $percentage . '%</div>';
                            echo '</div>';
                            echo '<p class="mt-2">' . $statusLabels[$status][0] . ': ' . $count . '</p>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Activité récente</h5>
                    <div class="list-group list-group-flush mt-3">
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between">
                                <span><i class="fas fa-user-plus text-success me-2"></i>Nouveaux utilisateurs (7 derniers jours)</span>
                                <span class="badge bg-primary rounded-pill">
                                    <?php
                                    $stmt = $db->prepare(
                                        "SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
                                    );
                                    $stmt->execute();
                                    echo $stmt->fetchColumn();
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between">
                                <span><i class="fas fa-calendar-plus text-info me-2"></i>Nouvelles réservations (7 derniers jours)</span>
                                <span class="badge bg-primary rounded-pill">
                                    <?php
                                    $stmt = $db->prepare(
                                        "SELECT COUNT(*) FROM bookings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
                                    );
                                    $stmt->execute();
                                    echo $stmt->fetchColumn();
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between">
                                <span><i class="fas fa-user-check text-success me-2"></i>Professeurs actifs</span>
                                <span class="badge bg-primary rounded-pill">
                                    <?php
                                    $stmt = $db->prepare(
                                        "SELECT COUNT(DISTINCT teacher_id) FROM bookings"
                                    );
                                    $stmt->execute();
                                    echo $stmt->fetchColumn();
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between">
                                <span><i class="fas fa-user-check text-info me-2"></i>Élèves actifs</span>
                                <span class="badge bg-primary rounded-pill">
                                    <?php
                                    $stmt = $db->prepare(
                                        "SELECT COUNT(DISTINCT student_id) FROM bookings"
                                    );
                                    $stmt->execute();
                                    echo $stmt->fetchColumn();
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Utilisateurs récents et réservations récentes -->
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0">Utilisateurs récents</h5>
                        <a href="admin_users.php" class="btn btn-sm btn-outline-primary">Voir tous</a>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUsers as $user): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($user['name']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td>
                                            <?php
                                            switch ($user['role']) {
                                                case 'student':
                                                    echo '<span class="badge bg-info">Élève</span>';
                                                    break;
                                                case 'teacher':
                                                    echo '<span class="badge bg-success">Professeur</span>';
                                                    break;
                                                case 'admin':
                                                    echo '<span class="badge bg-danger">Admin</span>';
                                                    break;
                                            }
                                            ?>
                                        </td>
                                        <td><?= formatDate($user['created_at']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0">Réservations récentes</h5>
                        <a href="admin_bookings.php" class="btn btn-sm btn-outline-primary">Voir toutes</a>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Professeur</th>
                                    <th>Élève</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentBookings as $booking): ?>
                                    <tr>
                                        <td><?= $booking['id'] ?></td>
                                        <td><?= htmlspecialchars($booking['teacher_name']) ?></td>
                                        <td><?= htmlspecialchars($booking['student_name']) ?></td>
                                        <td>
                                            <?php
                                            switch ($booking['status']) {
                                                case 'pending':
                                                    echo '<span class="badge bg-warning">En attente</span>';
                                                    break;
                                                case 'confirmed':
                                                    echo '<span class="badge bg-success">Confirmé</span>';
                                                    break;
                                                case 'canceled':
                                                    echo '<span class="badge bg-danger">Annulé</span>';
                                                    break;
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.progress-circle {
    position: relative;
}

.progress-circle-bg {
    transition: all 0.3s ease;
}
</style>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>