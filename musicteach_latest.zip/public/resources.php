<?php
// Titre de la page
$pageTitle = "Ressources Musicales";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <div class="row mb-4">
        <div class="col-md-12 text-center" data-aos="fade-up">
            <h1 class="mb-3">Ressources Musicales</h1>
            <p class="lead">Une collection de ressources pour soutenir votre apprentissage musical</p>
        </div>
    </div>

    <!-- Onglets des ressources -->
    <div class="row">
        <div class="col-12">
            <ul class="nav nav-pills nav-fill mb-4" id="resources-tabs" role="tablist" data-aos="fade-up">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="theory-tab" data-bs-toggle="pill" data-bs-target="#theory" 
                            type="button" role="tab" aria-controls="theory" aria-selected="true">
                        <i class="fas fa-book me-2"></i>Théorie musicale
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="exercises-tab" data-bs-toggle="pill" data-bs-target="#exercises" 
                            type="button" role="tab" aria-controls="exercises" aria-selected="false">
                        <i class="fas fa-dumbbell me-2"></i>Exercices
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="blog-tab" data-bs-toggle="pill" data-bs-target="#blog" 
                            type="button" role="tab" aria-controls="blog" aria-selected="false">
                        <i class="fas fa-pen-fancy me-2"></i>Articles de blog
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="videos-tab" data-bs-toggle="pill" data-bs-target="#videos" 
                            type="button" role="tab" aria-controls="videos" aria-selected="false">
                        <i class="fas fa-video me-2"></i>Vidéos pédagogiques
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="resources-tabContent">
                <!-- Théorie musicale -->
                <div class="tab-pane fade show active" id="theory" role="tabpanel" aria-labelledby="theory-tab">
                    <div class="row">
                        <div class="col-md-8 mb-4" data-aos="fade-up">
                            <div class="card h-100">
                                <div class="card-body p-4">
                                    <h3 class="card-title mb-4">Bases de la théorie musicale</h3>
                                    
                                    <div class="mb-5">
                                        <h4>1. La portée et les notes</h4>
                                        <p>La portée musicale est l'ensemble des cinq lignes horizontales sur lesquelles on écrit la musique. Les notes sont placées sur ces lignes ou dans les interlignes (espaces entre les lignes).</p>
                                        <div class="text-center my-4">
                                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Music-staff.svg/500px-Music-staff.svg.png" 
                                                 alt="Portée musicale" class="img-fluid" style="max-height: 150px;">
                                        </div>
                                        <p>Les sept notes de musique sont : Do, Ré, Mi, Fa, Sol, La, Si. Elles se répètent ensuite à l'octave supérieure.</p>
                                    </div>
                                    
                                    <div class="mb-5">
                                        <h4>2. Les clés</h4>
                                        <p>Les clés déterminent la position des notes sur la portée. Les plus courantes sont :</p>
                                        <ul>
                                            <li><strong>Clé de Sol</strong> : Utilisée pour les instruments aigus (piano main droite, guitare, violon...)</li>
                                            <li><strong>Clé de Fa</strong> : Utilisée pour les instruments graves (piano main gauche, basse, contrebasse...)</li>
                                            <li><strong>Clé d'Ut</strong> : Utilisée pour certains instruments comme l'alto (clé d'ut 3ème) ou le violoncelle (clé d'ut 4ème)</li>
                                        </ul>
                                    </div>
                                    
                                    <div class="mb-5">
                                        <h4>3. Les valeurs rythmiques</h4>
                                        <p>Les figures de notes déterminent la durée de chaque note :</p>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Figure</th>
                                                        <th>Nom</th>
                                                        <th>Valeur</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="text-center">𝅝</td>
                                                        <td>Ronde</td>
                                                        <td>4 temps</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">𝅗𝅥</td>
                                                        <td>Blanche</td>
                                                        <td>2 temps</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">♩</td>
                                                        <td>Noire</td>
                                                        <td>1 temps</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">♪</td>
                                                        <td>Croche</td>
                                                        <td>1/2 temps</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-center">♬</td>
                                                        <td>Double-croche</td>
                                                        <td>1/4 temps</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-5">
                                        <h4>4. Les mesures et la signature rythmique</h4>
                                        <p>La mesure est une unité de temps en musique. La signature rythmique (ou chiffrage de mesure) indique :</p>
                                        <ul>
                                            <li>Le nombre de temps par mesure (chiffre du haut)</li>
                                            <li>La valeur de chaque temps (chiffre du bas)</li>
                                        </ul>
                                        <p>Exemples :</p>
                                        <ul>
                                            <li><strong>4/4</strong> : 4 temps par mesure, la noire vaut un temps (mesure simple la plus courante)</li>
                                            <li><strong>3/4</strong> : 3 temps par mesure, la noire vaut un temps (comme une valse)</li>
                                            <li><strong>6/8</strong> : 6 temps par mesure, la croche vaut un temps (mesure composée)</li>
                                        </ul>
                                    </div>
                                    
                                    <div>
                                        <h4>5. Les armures et les tonalités</h4>
                                        <p>L'armure est l'ensemble des altérations (dièses ou bémols) placées au début de la portée pour indiquer la tonalité du morceau.</p>
                                        <p>Les tonalités déterminent la note fondamentale et le mode (majeur ou mineur) d'un morceau.</p>
                                        <p>Exemple : Une armure avec un dièse (placé sur le Fa) indique la tonalité de Sol majeur ou Mi mineur.</p>
                                    </div>
                                </div>
                                <div class="card-footer bg-transparent text-center">
                                    <a href="#" class="btn btn-primary">Télécharger le PDF complet</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                            <div class="card h-100">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">Ressources complémentaires</h5>
                                </div>
                                <div class="card-body">
                                    <h5 class="mb-3">Guides par instrument</h5>
                                    <ul class="list-group list-group-flush mb-4">
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-guitar me-2"></i>Théorie pour guitaristes</span>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Voir</a>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-piano me-2"></i>Théorie pour pianistes</span>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Voir</a>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-drum me-2"></i>Théorie pour batteurs</span>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Voir</a>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-microphone-alt me-2"></i>Théorie pour chanteurs</span>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Voir</a>
                                        </li>
                                    </ul>
                                    
                                    <h5 class="mb-3">Outils pratiques</h5>
                                    <div class="d-grid gap-2">
                                        <a href="#" class="btn btn-outline-primary">
                                            <i class="fas fa-circle-notch me-2"></i>Cercle des quintes interactif
                                        </a>
                                        <a href="#" class="btn btn-outline-primary">
                                            <i class="fas fa-calculator me-2"></i>Calculateur d'accords
                                        </a>
                                        <a href="#" class="btn btn-outline-primary">
                                            <i class="fas fa-music me-2"></i>Dictionnaire d'accords
                                        </a>
                                        <a href="#" class="btn btn-outline-primary">
                                            <i class="fas fa-headphones me-2"></i>Entraînement à l'oreille
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Exercices -->
                <div class="tab-pane fade" id="exercises" role="tabpanel" aria-labelledby="exercises-tab">
                    <div class="row row-cols-1 row-cols-md-2 g-4" data-aos="fade-up">
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h4 class="card-title mb-3">Exercices de technique pour guitaristes</h4>
                                    <h6 class="text-muted mb-3">Niveau : Débutant à intermédiaire</h6>
                                    <div class="mb-3">
                                        <span class="badge bg-primary me-1">Guitare</span>
                                        <span class="badge bg-secondary me-1">Technique</span>
                                        <span class="badge bg-info">Coordination</span>
                                    </div>
                                    <p>Une série d'exercices progressifs pour développer la dextérité et la coordination des deux mains. Ces exercices couvrent :</p>
                                    <ul>
                                        <li>Échauffements essentiels</li>
                                        <li>Coordination main droite/main gauche</li>
                                        <li>Exercices de légato (hammer-on, pull-off)</li>
                                        <li>Motifs de picking alterné</li>
                                        <li>Motifs d'arpèges simples</li>
                                    </ul>
                                    <p>Pratiquez ces exercices quotidiennement pour des résultats optimaux.</p>
                                </div>
                                <div class="card-footer bg-transparent text-center">
                                    <a href="#" class="btn btn-primary">Télécharger les exercices</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h4 class="card-title mb-3">Exercices de technique pour pianistes</h4>
                                    <h6 class="text-muted mb-3">Niveau : Débutant à intermédiaire</h6>
                                    <div class="mb-3">
                                        <span class="badge bg-primary me-1">Piano</span>
                                        <span class="badge bg-secondary me-1">Technique</span>
                                        <span class="badge bg-info">Indépendance des doigts</span>
                                    </div>
                                    <p>Une collection d'exercices conçus pour développer la technique pianistique fondamentale :</p>
                                    <ul>
                                        <li>Exercices de Hanon adaptés pour débutants</li>
                                        <li>Gammes majeures et mineures (avec doigtés)</li>
                                        <li>Arpèges fondamentaux</li>
                                        <li>Exercices d'indépendance des doigts</li>
                                        <li>Exercices de croisement de doigts</li>
                                    </ul>
                                    <p>Ces exercices constituent une base solide pour tout pianiste en développement.</p>
                                </div>
                                <div class="card-footer bg-transparent text-center">
                                    <a href="#" class="btn btn-primary">Télécharger les exercices</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h4 class="card-title mb-3">Exercices d'entraînement de l'oreille</h4>
                                    <h6 class="text-muted mb-3">Niveau : Tous niveaux</h6>
                                    <div class="mb-3">
                                        <span class="badge bg-primary me-1">Tous instruments</span>
                                        <span class="badge bg-secondary me-1">Oreille musicale</span>
                                        <span class="badge bg-info">Solfège</span>
                                    </div>
                                    <p>Une série d'exercices progressifs pour développer votre oreille musicale :</p>
                                    <ul>
                                        <li>Reconnaissance des intervalles</li>
                                        <li>Identification des accords (majeurs, mineurs, septièmes)</li>
                                        <li>Dictées rythmiques simples</li>
                                        <li>Dictées mélodiques progressives</li>
                                        <li>Exercices d'harmonie à l'oreille</li>
                                    </ul>
                                    <p>Une bonne oreille est essentielle pour tous les musiciens, quel que soit votre instrument.</p>
                                </div>
                                <div class="card-footer bg-transparent text-center">
                                    <a href="#" class="btn btn-primary">Accéder aux exercices en ligne</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h4 class="card-title mb-3">Exercices vocaux pour chanteurs</h4>
                                    <h6 class="text-muted mb-3">Niveau : Débutant à intermédiaire</h6>
                                    <div class="mb-3">
                                        <span class="badge bg-primary me-1">Chant</span>
                                        <span class="badge bg-secondary me-1">Technique vocale</span>
                                        <span class="badge bg-info">Respiration</span>
                                    </div>
                                    <p>Une sélection d'exercices pour développer votre voix et votre technique vocale :</p>
                                    <ul>
                                        <li>Échauffements vocaux essentiels</li>
                                        <li>Exercices de respiration diaphragmatique</li>
                                        <li>Vocalises pour étendre votre registre</li>
                                        <li>Techniques pour améliorer la projection</li>
                                        <li>Exercices de soutien et de contrôle</li>
                                    </ul>
                                    <p>Ces exercices sont accompagnés de fichiers audio pour vous guider.</p>
                                </div>
                                <div class="card-footer bg-transparent text-center">
                                    <a href="#" class="btn btn-primary">Accéder aux exercices</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Exercices supplémentaires -->
                    <div class="text-center mt-4" data-aos="fade-up">
                        <a href="#" class="btn btn-outline-primary">
                            <i class="fas fa-plus-circle me-2"></i>Voir plus d'exercices
                        </a>
                    </div>
                </div>
                
                <!-- Blog musical -->
                <div class="tab-pane fade" id="blog" role="tabpanel" aria-labelledby="blog-tab">
                    <div class="row">
                        <div class="col-lg-8">
                            <!-- Articles de blog -->
                            <div class="card mb-4" data-aos="fade-up">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4 mb-3 mb-md-0">
                                            <img src="https://images.unsplash.com/photo-1511379938547-c1f69419868d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
                                                 alt="Comment structurer votre pratique musicale" class="img-fluid rounded">
                                        </div>
                                        <div class="col-md-8">
                                            <h4 class="card-title">Comment structurer efficacement votre pratique musicale</h4>
                                            <div class="mb-2">
                                                <span class="text-muted">Par Sophie Martin • 15 avril 2025</span>
                                            </div>
                                            <p>La pratique régulière est essentielle pour progresser en musique, mais la qualité importe autant que la quantité. Découvrez comment organiser vos sessions de pratique pour maximiser vos progrès...</p>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Lire la suite</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4" data-aos="fade-up" data-aos-delay="100">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4 mb-3 mb-md-0">
                                            <img src="https://images.unsplash.com/photo-1507838153414-b4b713384a76?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
                                                 alt="Vaincre le trac" class="img-fluid rounded">
                                        </div>
                                        <div class="col-md-8">
                                            <h4 class="card-title">5 techniques pour vaincre le trac avant une performance</h4>
                                            <div class="mb-2">
                                                <span class="text-muted">Par Thomas Dubois • 8 avril 2025</span>
                                            </div>
                                            <p>Le trac est un phénomène naturel qui touche même les musiciens les plus expérimentés. Cette anxiété de performance peut cependant être maîtrisée avec les bonnes techniques. Voici cinq méthodes éprouvées...</p>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Lire la suite</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4" data-aos="fade-up" data-aos-delay="200">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4 mb-3 mb-md-0">
                                            <img src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
                                                 alt="Home studio" class="img-fluid rounded">
                                        </div>
                                        <div class="col-md-8">
                                            <h4 class="card-title">Créer un home studio efficace avec un budget limité</h4>
                                            <div class="mb-2">
                                                <span class="text-muted">Par Emma Leclerc • 2 avril 2025</span>
                                            </div>
                                            <p>L'enregistrement à domicile est devenu accessible à tous grâce aux avancées technologiques. Vous n'avez pas besoin d'investir des milliers d'euros pour créer un espace d'enregistrement de qualité...</p>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Lire la suite</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card mb-4" data-aos="fade-up" data-aos-delay="300">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4 mb-3 mb-md-0">
                                            <img src="https://images.unsplash.com/photo-1514119412350-e174d90d280e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
                                                 alt="Improvisation musicale" class="img-fluid rounded">
                                        </div>
                                        <div class="col-md-8">
                                            <h4 class="card-title">Les bases de l'improvisation musicale expliquées simplement</h4>
                                            <div class="mb-2">
                                                <span class="text-muted">Par Marc Dupont • 28 mars 2025</span>
                                            </div>
                                            <p>L'improvisation peut sembler magique ou intimidante pour les débutants, mais elle repose sur des principes que l'on peut apprendre et pratiquer. Découvrez comment commencer à improviser, quel que soit votre niveau...</p>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Lire la suite</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Pagination -->
                            <nav aria-label="Blog pagination" class="mt-4" data-aos="fade-up">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Précédent</a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">Suivant</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        
                        <!-- Sidebar -->
                        <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                            <!-- Catégories -->
                            <div class="card mb-4">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">Catégories</h5>
                                </div>
                                <div class="card-body">
                                    <div class="list-group list-group-flush">
                                        <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                            Conseils de pratique
                                            <span class="badge bg-primary rounded-pill">14</span>
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                            Théorie musicale
                                            <span class="badge bg-primary rounded-pill">8</span>
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                            Technologie musicale
                                            <span class="badge bg-primary rounded-pill">11</span>
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                            Conseils pour les performances
                                            <span class="badge bg-primary rounded-pill">7</span>
                                        </a>
                                        <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                            Entretien des instruments
                                            <span class="badge bg-primary rounded-pill">5</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Articles populaires -->
                            <div class="card mb-4">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">Articles populaires</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-3">
                                            <img src="https://images.unsplash.com/photo-1513883049090-d0b7439799bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=60" 
                                                 alt="Article populaire" class="img-fluid rounded">
                                        </div>
                                        <div class="col-9">
                                            <h6 class="mb-1"><a href="#" class="text-decoration-none">Comment choisir votre premier instrument</a></h6>
                                            <small class="text-muted">3.5K lectures</small>
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-3">
                                            <img src="https://images.unsplash.com/photo-1465821185615-20b3c2fbf41b?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=60" 
                                                 alt="Article populaire" class="img-fluid rounded">
                                        </div>
                                        <div class="col-9">
                                            <h6 class="mb-1"><a href="#" class="text-decoration-none">10 habitudes des musiciens qui réussissent</a></h6>
                                            <small class="text-muted">2.8K lectures</small>
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-3">
                                            <img src="https://images.unsplash.com/photo-1512053459797-38c3a066cabd?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=60" 
                                                 alt="Article populaire" class="img-fluid rounded">
                                        </div>
                                        <div class="col-9">
                                            <h6 class="mb-1"><a href="#" class="text-decoration-none">Les bases de la composition musicale</a></h6>
                                            <small class="text-muted">2.2K lectures</small>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-3">
                                            <img src="https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=60" 
                                                 alt="Article populaire" class="img-fluid rounded">
                                        </div>
                                        <div class="col-9">
                                            <h6 class="mb-1"><a href="#" class="text-decoration-none">Comment surmonter le plateau technique</a></h6>
                                            <small class="text-muted">1.9K lectures</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Newsletter -->
                            <div class="card">
                                <div class="card-body text-center">
                                    <h5 class="card-title">Restez informé</h5>
                                    <p class="card-text">Abonnez-vous à notre newsletter pour recevoir nos derniers articles et conseils musicaux.</p>
                                    <form>
                                        <div class="mb-3">
                                            <input type="email" class="form-control" placeholder="Votre adresse email" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-100">S'abonner</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Vidéos pédagogiques -->
                <div class="tab-pane fade" id="videos" role="tabpanel" aria-labelledby="videos-tab">
                    <div class="row row-cols-1 row-cols-md-2 g-4">
                        <!-- Vidéo 1 -->
                        <div class="col" data-aos="fade-up">
                            <div class="card h-100">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Vidéo pédagogique" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Les bases de la lecture de partitions</h5>
                                    <p class="card-text">Un guide étape par étape pour apprendre à lire la musique, même si vous débutez complètement. Cette vidéo couvre les notes, les clés, les valeurs rythmiques et plus encore.</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">Durée: 15:24</small>
                                        <div>
                                            <span class="badge bg-primary me-1">Débutant</span>
                                            <span class="badge bg-secondary">Solfège</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 2 -->
                        <div class="col" data-aos="fade-up" data-aos-delay="100">
                            <div class="card h-100">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Vidéo pédagogique" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Technique de respiration pour chanteurs</h5>
                                    <p class="card-text">Apprenez les techniques de respiration diaphragmatique essentielles pour les chanteurs. Cette méthode vous aidera à améliorer votre projection et votre contrôle vocal.</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">Durée: 12:08</small>
                                        <div>
                                            <span class="badge bg-primary me-1">Tous niveaux</span>
                                            <span class="badge bg-secondary">Chant</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 3 -->
                        <div class="col" data-aos="fade-up" data-aos-delay="200">
                            <div class="card h-100">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Vidéo pédagogique" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Guide complet des accords de guitare pour débutants</h5>
                                    <p class="card-text">Apprenez les accords fondamentaux de la guitare avec des explications claires et des exercices pratiques. Idéal pour les débutants qui souhaitent rapidement jouer leurs morceaux préférés.</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">Durée: 18:45</small>
                                        <div>
                                            <span class="badge bg-primary me-1">Débutant</span>
                                            <span class="badge bg-secondary">Guitare</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Vidéo 4 -->
                        <div class="col" data-aos="fade-up" data-aos-delay="300">
                            <div class="card h-100">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Vidéo pédagogique" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Comprendre les gammes musicales facilement</h5>
                                    <p class="card-text">Une explication claire et visuelle des gammes majeures et mineures, leur construction et leur utilisation dans la composition et l'improvisation.</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">Durée: 14:30</small>
                                        <div>
                                            <span class="badge bg-primary me-1">Intermédiaire</span>
                                            <span class="badge bg-secondary">Théorie</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Plus de vidéos -->
                    <div class="text-center mt-4" data-aos="fade-up">
                        <a href="videos.php" class="btn btn-primary">
                            <i class="fas fa-play-circle me-2"></i>Voir notre bibliothèque de vidéos musicales
                        </a>
                        <p class="mt-3 text-muted">Découvrez notre collection complète de vidéos pédagogiques par thème et par instrument</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Call-to-action -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card bg-primary text-white" data-aos="fade-up">
                <div class="card-body p-5 text-center">
                    <h3 class="mb-3">Vous avez une question ou besoin de conseils personnalisés ?</h3>
                    <p class="mb-4">Nos professeurs experts sont là pour vous aider dans votre parcours musical.</p>
                    <div class="d-flex justify-content-center gap-3">
                        <a href="teachers.php" class="btn btn-light">
                            <i class="fas fa-search me-2"></i>Trouver un professeur
                        </a>
                        <a href="contact.php" class="btn btn-outline-light">
                            <i class="fas fa-envelope me-2"></i>Nous contacter
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>