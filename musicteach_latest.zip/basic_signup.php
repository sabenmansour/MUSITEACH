<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

echo '<h1>Page d\'inscription basique</h1>';

// Afficher un formulaire d'inscription simple
echo '<form method="post" action="process_signup.php">';
echo '<div>';
echo '<label for="name">Nom complet:</label><br>';
echo '<input type="text" id="name" name="name" required>';
echo '</div><br>';

echo '<div>';
echo '<label for="email">Email:</label><br>';
echo '<input type="email" id="email" name="email" required>';
echo '</div><br>';

echo '<div>';
echo '<label for="password">Mot de passe:</label><br>';
echo '<input type="password" id="password" name="password" required>';
echo '<p><small>Le mot de passe doit contenir au moins 8 caractères.</small></p>';
echo '</div>';

echo '<div>';
echo '<label for="password_confirm">Confirmer le mot de passe:</label><br>';
echo '<input type="password" id="password_confirm" name="password_confirm" required>';
echo '</div><br>';

echo '<div>';
echo '<label>Je souhaite m\'inscrire en tant que:</label><br>';
echo '<input type="radio" id="role_student" name="role" value="student" checked>';
echo '<label for="role_student">Élève</label><br>';
echo '<input type="radio" id="role_teacher" name="role" value="teacher">';
echo '<label for="role_teacher">Professeur</label>';
echo '</div><br>';

echo '<div>';
echo '<button type="submit">S\'inscrire</button>';
echo '</div>';
echo '</form>';

echo '<p>Déjà un compte? <a href="login.php">Se connecter</a></p>';
?>