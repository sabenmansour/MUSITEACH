#!/bin/bash

# Définition des couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Configuration du dépôt GitHub pour MusiTeach ===${NC}"
echo
echo -e "${YELLOW}Ce script va vous aider à connecter votre dépôt local à GitHub.${NC}"
echo -e "${YELLOW}Assurez-vous d'avoir déjà créé un dépôt vide sur GitHub avant de continuer.${NC}"
echo

# Demande de l'URL du dépôt
read -p "Entrez l'URL de votre dépôt GitHub (ex: https://github.com/username/MusiTeach.git): " repo_url

if [ -z "$repo_url" ]; then
    echo -e "${RED}Erreur: vous devez fournir une URL de dépôt.${NC}"
    exit 1
fi

# Configuration du remote
echo -e "${YELLOW}Configuration du dépôt distant...${NC}"
git remote add origin $repo_url

if [ $? -ne 0 ]; then
    echo -e "${RED}Erreur lors de l'ajout du dépôt distant. Veuillez vérifier l'URL et réessayer.${NC}"
    exit 1
fi

# Push vers GitHub
echo -e "${YELLOW}Envoi du code vers GitHub...${NC}"
git push -u origin master

if [ $? -ne 0 ]; then
    echo -e "${RED}Erreur lors de l'envoi du code vers GitHub.${NC}"
    echo -e "${YELLOW}Si c'est la première fois que vous utilisez Git avec GitHub, vous devrez peut-être configurer votre identité:${NC}"
    echo "git config --global user.name \"Votre Nom\""
    echo "git config --global user.email \"votre.email@exemple.com\""
    echo -e "${YELLOW}Et authentifiez-vous avec GitHub en utilisant:${NC}"
    echo "1. Un token d'accès personnel (https://github.com/settings/tokens)"
    echo "2. SSH (https://docs.github.com/en/authentication/connecting-to-github-with-ssh)"
    exit 1
fi

echo -e "${GREEN}Félicitations! Votre dépôt local est maintenant connecté à GitHub.${NC}"
echo -e "${GREEN}URL du dépôt: ${repo_url}${NC}"
echo
echo -e "${BLUE}=== Instructions pour les futurs push ===${NC}"
echo "1. Faites vos modifications"
echo "2. Ajoutez vos fichiers modifiés: git add ."
echo "3. Commitez vos changements: git commit -m \"Description des changements\""
echo "4. Envoyez sur GitHub: git push"
echo
echo -e "${YELLOW}N'oubliez pas de configurer un fichier README.md attractif sur GitHub pour présenter votre projet!${NC}"