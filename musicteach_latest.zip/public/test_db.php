<?php
// Afficher toutes les erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Vérifier directement si PDO est disponible
echo "<h1>Vérification de l'environnement PHP</h1>";

echo "<h2>Extensions PHP chargées :</h2>";
echo "<pre>";
print_r(get_loaded_extensions());
echo "</pre>";

echo "<h2>Vérification de PDO :</h2>";
if (class_exists('PDO')) {
    echo "<p style='color: green;'>PDO est disponible.</p>";
    
    echo "<h3>Pilotes PDO disponibles :</h3>";
    echo "<pre>";
    print_r(PDO::getAvailableDrivers());
    echo "</pre>";
    
    // Tester la connexion à MySQL directement
    if (in_array('mysql', PDO::getAvailableDrivers())) {
        echo "<p style='color: green;'>Le pilote MySQL pour PDO est disponible.</p>";
        
        try {
            $pdo = new PDO('mysql:host=mysql;dbname=musicteach', 'musicteach', 'musicteach');
            echo "<p style='color: green;'>Connexion à la base de données réussie !</p>";
            
            // Vérifier les tables
            $stmt = $pdo->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            echo "<h3>Tables dans la base de données :</h3>";
            echo "<ul>";
            foreach ($tables as $table) {
                echo "<li>$table</li>";
            }
            echo "</ul>";
            
        } catch (PDOException $e) {
            echo "<p style='color: red;'>Erreur de connexion à la base de données : " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color: red;'>Le pilote MySQL pour PDO n'est pas disponible.</p>";
    }
} else {
    echo "<p style='color: red;'>PDO n'est pas disponible.</p>";
}

// Vérifier si mysqli est disponible
echo "<h2>Vérification de MySQLi :</h2>";
if (function_exists('mysqli_connect')) {
    echo "<p style='color: green;'>La fonction mysqli_connect est disponible.</p>";
} else {
    echo "<p style='color: red;'>La fonction mysqli_connect n'est pas disponible.</p>";
    
    echo "<h3>Modules PHP manquants :</h3>";
    echo "<p>Le module mysqli ne semble pas être installé. Voici comment l'installer :</p>";
    echo "<pre>
    Dans le Dockerfile ou dans le conteneur :
    apt-get update && apt-get install -y php-mysqli
    
    Puis redémarrer Apache :
    service apache2 restart
    </pre>";
}
?>