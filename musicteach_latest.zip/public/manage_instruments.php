<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Instrument.php';
require_once __DIR__ . '/../app/models/TeacherInstrument.php';
require_once __DIR__ . '/../app/db_connect.php';

// Vérifier si l'utilisateur est connecté et est un professeur
requireLogin();
if (!isTeacher()) {
    setFlashMessage('error', 'Accès réservé aux professeurs.');
    redirect('dashboard.php');
}

$teacherId = $_SESSION['user_id'];

// Vérifier si les tables nécessaires existent
$db = getDbConnection();
$stmt = $db->prepare("SHOW TABLES LIKE 'instruments'");
$stmt->execute();
$hasInstrumentsTable = $stmt->fetchColumn();

$stmt = $db->prepare("SHOW TABLES LIKE 'teacher_instruments'");
$stmt->execute();
$hasTeacherInstrumentsTable = $stmt->fetchColumn();

// Si les tables n'existent pas, créer les tables à partir du script SQL
if (!$hasInstrumentsTable || !$hasTeacherInstrumentsTable) {
    $sqlFile = __DIR__ . '/../database/instruments.sql';
    if (file_exists($sqlFile)) {
        $sql = file_get_contents($sqlFile);
        $db->exec($sql);
        
        // Vérifier à nouveau si les tables ont été créées
        $stmt = $db->prepare("SHOW TABLES LIKE 'instruments'");
        $stmt->execute();
        $hasInstrumentsTable = $stmt->fetchColumn();
        
        $stmt = $db->prepare("SHOW TABLES LIKE 'teacher_instruments'");
        $stmt->execute();
        $hasTeacherInstrumentsTable = $stmt->fetchColumn();
    }
}

// Traitement des actions
$success = false;
$error = '';

// Ajouter un instrument
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_instrument'])) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Une erreur de sécurité est survenue. Veuillez réessayer.';
    } else {
        $instrumentId = isset($_POST['instrument_id']) && is_numeric($_POST['instrument_id']) 
            ? (int)$_POST['instrument_id'] 
            : null;
        
        $level = isset($_POST['level']) && in_array($_POST['level'], ['beginner', 'intermediate', 'advanced', 'all']) 
            ? $_POST['level'] 
            : 'all';
        
        $description = isset($_POST['description']) ? sanitizeInput($_POST['description']) : null;
        
        if ($instrumentId) {
            try {
                $result = TeacherInstrument::create($teacherId, $instrumentId, $level, $description);
                if ($result) {
                    $success = true;
                    setFlashMessage('success', 'L\'instrument a été ajouté à votre profil avec succès.');
                    redirect('manage_instruments.php');
                } else {
                    $error = 'Une erreur est survenue lors de l\'ajout de l\'instrument.';
                }
            } catch (Exception $e) {
                $error = 'Une erreur est survenue : ' . $e->getMessage();
            }
        } else {
            $error = 'Veuillez sélectionner un instrument.';
        }
    }
}

// Supprimer un instrument
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $instrumentId = (int)$_GET['id'];
    
    try {
        $result = TeacherInstrument::delete($teacherId, $instrumentId);
        if ($result) {
            setFlashMessage('success', 'L\'instrument a été supprimé de votre profil.');
            redirect('manage_instruments.php');
        } else {
            setFlashMessage('error', 'Une erreur est survenue lors de la suppression de l\'instrument.');
            redirect('manage_instruments.php');
        }
    } catch (Exception $e) {
        setFlashMessage('error', 'Une erreur est survenue : ' . $e->getMessage());
        redirect('manage_instruments.php');
    }
}

// Récupérer les instruments du professeur
$teacherInstruments = $hasTeacherInstrumentsTable ? TeacherInstrument::findByTeacher($teacherId) : [];

// Récupérer tous les instruments disponibles
$allInstruments = $hasInstrumentsTable ? Instrument::findAll() : [];

// Filtrer les instruments pour n'afficher que ceux qui ne sont pas déjà associés au professeur
$teacherInstrumentIds = array_map(function($item) {
    return $item['instrument_id'];
}, $teacherInstruments);

$availableInstruments = array_filter($allInstruments, function($instrument) use ($teacherInstrumentIds) {
    return !in_array($instrument['id'], $teacherInstrumentIds);
});

// Titre de la page
$pageTitle = "Gérer mes instruments";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Gérer mes instruments</h1>
    
    <?php if (!$hasInstrumentsTable || !$hasTeacherInstrumentsTable): ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle me-2"></i>
            La fonctionnalité de gestion des instruments n'est pas disponible actuellement. Veuillez contacter l'administrateur.
        </div>
    <?php else: ?>
        <div class="row">
            <!-- Instruments actuels -->
            <div class="col-lg-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Mes instruments</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($teacherInstruments)): ?>
                            <p class="text-muted">Vous n'avez pas encore ajouté d'instruments à votre profil.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Instrument</th>
                                            <th>Catégorie</th>
                                            <th>Niveau</th>
                                            <th>Description</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($teacherInstruments as $instrument): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($instrument['instrument_name']) ?></td>
                                                <td><?= htmlspecialchars($instrument['instrument_category']) ?></td>
                                                <td>
                                                    <?php
                                                    switch ($instrument['level']) {
                                                        case 'beginner':
                                                            echo '<span class="badge bg-info">Débutant</span>';
                                                            break;
                                                        case 'intermediate':
                                                            echo '<span class="badge bg-primary">Intermédiaire</span>';
                                                            break;
                                                        case 'advanced':
                                                            echo '<span class="badge bg-danger">Avancé</span>';
                                                            break;
                                                        case 'all':
                                                            echo '<span class="badge bg-success">Tous niveaux</span>';
                                                            break;
                                                    }
                                                    ?>
                                                </td>
                                                <td><?= htmlspecialchars($instrument['description'] ?? 'Non spécifié') ?></td>
                                                <td>
                                                    <a href="edit_instrument.php?id=<?= $instrument['instrument_id'] ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="manage_instruments.php?action=delete&id=<?= $instrument['instrument_id'] ?>" 
                                                       class="btn btn-sm btn-danger"
                                                       onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet instrument de votre profil ?');">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Ajouter un instrument -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Ajouter un instrument</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger mb-3">
                                <i class="fas fa-exclamation-circle me-2"></i>
                                <?= $error ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success mb-3">
                                <i class="fas fa-check-circle me-2"></i>
                                L'instrument a été ajouté à votre profil avec succès.
                            </div>
                        <?php endif; ?>
                        
                        <?php if (empty($availableInstruments)): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Vous avez déjà ajouté tous les instruments disponibles à votre profil.
                            </div>
                        <?php else: ?>
                            <form action="manage_instruments.php" method="post">
                                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                                <input type="hidden" name="add_instrument" value="1">
                                
                                <div class="mb-3">
                                    <label for="instrument_id" class="form-label">Instrument</label>
                                    <select class="form-select" id="instrument_id" name="instrument_id" required>
                                        <option value="">Sélectionner un instrument</option>
                                        <?php 
                                        $currentCategory = null;
                                        foreach ($availableInstruments as $instrument): 
                                            if ($currentCategory !== $instrument['category']) {
                                                if ($currentCategory !== null) {
                                                    echo '</optgroup>';
                                                }
                                                $currentCategory = $instrument['category'];
                                                echo '<optgroup label="' . htmlspecialchars($currentCategory) . '">';
                                            }
                                        ?>
                                            <option value="<?= $instrument['id'] ?>">
                                                <?= htmlspecialchars($instrument['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                        <?php if ($currentCategory !== null): ?>
                                            </optgroup>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="level" class="form-label">Niveau d'enseignement</label>
                                    <select class="form-select" id="level" name="level">
                                        <option value="all">Tous niveaux</option>
                                        <option value="beginner">Débutant</option>
                                        <option value="intermediate">Intermédiaire</option>
                                        <option value="advanced">Avancé</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description (optionnel)</label>
                                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Ex: Spécialisation en jazz, 10 ans d'enseignement..."></textarea>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Ajouter cet instrument</button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="mt-4">
        <a href="profile_edit.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i>Retour à mon profil
        </a>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>