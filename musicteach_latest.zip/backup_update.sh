#!/bin/bash

# Définition des couleurs pour un affichage plus clair
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Définition des chemins
APP_DIR="$(pwd)"
BACKUP_DIR="${APP_DIR}/BACKUP"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="musicteach_update_features_${TIMESTAMP}"
BACKUP_FILE="${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
DOCKER_IMAGE_BACKUP="${BACKUP_DIR}/${BACKUP_NAME}_docker.tar"

echo -e "${BLUE}=== MusiTeach Backup pour mise à jour fonctionnalités ===${NC}"
echo "Répertoire courant: ${APP_DIR}"

# S'assurer que le dossier de sauvegarde existe
mkdir -p "${BACKUP_DIR}"

# 1. Créer une sauvegarde des fichiers de l'application
echo -e "${YELLOW}Création de la sauvegarde des fichiers...${NC}"
tar -czf "${BACKUP_FILE}" --exclude="BACKUP" --exclude="node_modules" --exclude=".git" .

# Vérifier si la sauvegarde a réussi
if [ $? -eq 0 ]; then
    echo -e "${GREEN}Sauvegarde des fichiers créée: ${BACKUP_FILE}${NC}"
else
    echo -e "${RED}Échec de la sauvegarde des fichiers${NC}"
    exit 1
fi

# 2. Sauvegarde des images Docker existantes
echo -e "${YELLOW}Sauvegarde des images Docker...${NC}"

# Liste des images à sauvegarder
IMAGES=("musicteach_web" "musicteach_db" "musicteach_phpmyadmin")

# Vérifier si les conteneurs sont en cours d'exécution
if docker ps | grep -q "musicteach"; then
    echo "Conteneurs en cours d'exécution trouvés"
    
    # Sauvegarde des conteneurs Docker
    echo -e "${YELLOW}Exportation des images Docker...${NC}"
    
    docker save $(docker-compose images -q) -o "${DOCKER_IMAGE_BACKUP}" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Images Docker sauvegardées: ${DOCKER_IMAGE_BACKUP}${NC}"
    else
        echo -e "${YELLOW}Note: Aucune image Docker n'a pu être sauvegardée ou les conteneurs ne sont pas en cours d'exécution${NC}"
    fi
else
    echo -e "${YELLOW}Aucun conteneur Docker en cours d'exécution trouvé pour la sauvegarde${NC}"
fi

# 3. Informations sur la sauvegarde
echo -e "${GREEN}Sauvegarde terminée avec succès${NC}"
echo -e "${BLUE}Détails de la sauvegarde:${NC}"
echo "- Fichiers: ${BACKUP_FILE}"
echo "- Images Docker: ${DOCKER_IMAGE_BACKUP} (si disponible)"
echo
echo -e "${YELLOW}Pour restaurer cette sauvegarde:${NC}"
echo "1. Pour les fichiers: tar -xzf ${BACKUP_FILE} -C /chemin/de/restauration"
echo "2. Pour les images Docker: docker load -i ${DOCKER_IMAGE_BACKUP}"
echo
echo -e "${GREEN}Vous pouvez maintenant procéder à la mise à jour des fonctionnalités.${NC}"