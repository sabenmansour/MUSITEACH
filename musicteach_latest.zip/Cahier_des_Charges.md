# Cahier des Charges

## 1. Présentation du Projet

Le projet consiste en la mise en place d'une plateforme web de gestion des cours de musique, permettant aux professeurs de proposer leurs cours et aux élèves de s'inscrire, interagir et réserver des sessions.

## 2. Objectifs

- Faciliter l'inscription et la gestion des cours de musique.
- Permettre une interaction fluide entre élèves et professeurs.
- Assurer une administration efficace des utilisateurs et des contenus.

## 3. Environnement Technique

- **Hébergement** : Serveur Debian hébergé par OVH
- **Base de données** : MariaDB
- **Technologies utilisées** : PHP, Bootstrap, Appache
- **Frameworks recommandés** : Laravel/Symfony pour PHP

## 4. Fonctionnalités

### 4.1 Fonctionnalités de Base (MVP)

#### **Front-End**
- **Page d'Accueil** :
  - Barre de navigation simple (Bootstrap/Nginx routing)
  - Présentation du service (HTML/CSS)
- **Formulaires d'Inscription et Connexion** :
  - Formulaire d'inscription basique (nom, email, mot de passe) (HTML/CSS/JS + Bootstrap)
  - Connexion avec vérification email/password (Jetstream/Fortify ou Guard en AJAX)
  - Vérification de l'inscription par token envoyé par email (avec mail conforme à la charte graphique)
  - Authentification sociale (SSO) via Facebook, Google ou LinkedIn
  - Récupération de mot de passe par magic link ou token (emails conformes à la charte graphique)
- **Affichage de la Liste des Professeurs** :
  - Liste simple des professeurs inscrits avec leur nom et description (HTML/CSS, récupération en AJAX)
  - Barre de recherche avancée avec filtres (instruments, niveaux, avis, tarifs)
  - Mode carte interactive pour voir les professeurs proches
- **Profil Professeur** :
  - Page affichant le profil du professeur avec son nom, description et matières enseignées (HTML/CSS, récupération dynamique via API Backend)
  - Téléversement de photo de profil et vidéo de présentation
  - Gestion des images des instruments enseignés
  - Calendrier interactif avec gestion des réservations en temps réel
- **Réservation de Cours** :
  - Sélection d'une date et heure via un formulaire basique (HTML/CSS/JS)
- **Calendrier** :
  - Vue calendrier pour visualiser les cours et disponibilités
- **Communication** :
  - Pages de communication entre professeurs et élèves
  - FAQ et centre d'aide
  - Système de notifications et alertes par email
- **Système de Notation et Commentaires** :
  - Ajout d'un système de notation avec étoiles et commentaires

#### **Back-End**
- **Gestion des Comptes et Authentification** :
  - Gestion des profils : Élève et Professeur (tables `users`, `profiles` en MariaDB)
  - Authentification et gestion des sessions (Laravel/Symfony, Jetstream/Fortify)
  - Authentification par token pour la vérification de compte
  - Intégration SSO (Facebook, Google, LinkedIn)
  - Gestion des magic links et tokens pour récupération de mot de passe
  - Gestion des photos de profil pour élèves et professeurs
- **Gestion des Réservations** :
  - Stockage des réservations de cours (table `bookings` en MariaDB)
  - API pour récupérer/modifier/supprimer les réservations
- **Panel d'Administration** :
  - Liste des utilisateurs avec possibilité de suppression (interface simple via Bootstrap + Laravel Blade)
  - Modération des avis par un administrateur
- **Paiements et Facturation** :
  - Intégration Stripe/PayPal pour paiements sécurisés
  - Génération de factures et reçus automatiques
- **Tableaux de Bord (Élève & Professeur)** :
  - Gestion des cours réservés
  - Communication avec les élèves/professeurs
  - Statistiques sur les revenus et la progression des élèves

#### **Base de Données**
- **Modèle de Données (MariaDB)** :
  - Table `users` (id, nom, email, mot de passe, rôle)
  - Table `profiles` (user_id, type (élève/professeur), description, profile_image)
  - Table `instruments` (id, nom, description, image)
  - Table `teacher_instruments` (id, teacher_id, instrument_id, niveau, tarif_horaire)
  - Table `bookings` (id, professeur_id, élève_id, date, statut)
  - Table `tokens` (id, user_id, token, type, created_at, expires_at)
  - Table `faq` (id, question, answer, category)
  - Table `messages` (id, sender_id, receiver_id, message, created_at, read)
  - Table `reviews` (id, professeur_id, élève_id, note, commentaire)
  - Table `payments` (id, user_id, montant, statut, transaction_id)
  - Table `media` (id, related_id, related_type, file_path, file_type, created_at)

---

### 4.2 Fonctionnalités Bonus (Évolutions Futures)

#### **Front-End**
- **Expérience Utilisateur Avancée** :
  - Interface entièrement responsive avec animations
  - Mode sombre/clair
  - Application mobile (PWA ou native)
  - Messagerie instantanée (chat) intégrée entre élèves et professeurs
  - Outils pédagogiques intégrés (partage de partitions, métronome en ligne)
  - Blog et actualités pour la communauté musicale
  - Système de gamification (badges, niveaux, objectifs d'apprentissage)
  - Gestion des cours collectifs/groupe

#### **Back-End**
- **Intelligence Artificielle** :
  - Recommandations personnalisées de professeurs
  - Analyse prédictive de la disponibilité et des tarifs
  - Statistiques avancées de progression des élèves
- **Intégration Multiplateforme** :
  - Synchronisation avec Google Calendar/Apple Calendar
  - Intégration avec des outils de visioconférence pour cours en ligne
  - API mobile pour applications natives iOS/Android
  - Système d'affiliation pour recommander des professeurs
- **Système de Notifications** :
  - Rappels automatiques par email avant les cours
  - Notifications push pour mobile
  - Alertes SMS pour les événements importants

#### **Base de Données**
- **Extension Avancée des Modèles** :
  - Table `learning_materials` (ressources pédagogiques partagées)
  - Table `achievements` (suivi de progression et badges)
  - Table `analytics` (données d'utilisation et métriques)
  - Table `group_lessons` (gestion des cours collectifs)
  - Table `notifications` (préférences et historique des notifications)
  - Table `chat_messages` (messagerie instantanée)
  - Table `affiliates` (système de parrainage/recommandation)

---

## 5. Sécurité et RGPD

- Chiffrement des mots de passe (bcrypt ou Argon2 via Laravel Hash)
- Sécurisation des paiements (SSL, 3D Secure via Stripe ou PayPal)
- Gestion des données personnelles conforme au RGPD (Droit à l'oubli, export des données)
- Protection contre les attaques XSS et injections SQL (sanitization des inputs, prepared statements)
- Gestion des rôles et permissions (ACL via Laravel Gate/Policy)
- Système d'authentification renforcé (2FA, gestion des tokens JWT pour API)
- Vérification et expiration des tokens d'authentification

## 6. Infrastructure et Déploiement

- **Configuration du Serveur** :
  - Installation et configuration de Debian, Nginx, PHP, MariaDB
  - Sécurisation du serveur (firewall, fail2ban, HTTPS avec Let's Encrypt)
- **Automatisation du Déploiement** :
  - Intégration continue et déploiement via GitHub Actions
  - Utilisation de Docker pour une gestion simplifiée des dépendances
- **Monitoring et Maintenance** :
  - Mise en place de logs centralisés (ELK Stack, Logrotate)
  - Surveillance de l'infrastructure (Prometheus, Grafana)
  - Plan de mise à jour régulier pour la maintenance et la sécurité

## 7. Documentation

- **Documentation technique** : Explication du code, API endpoints, architecture du projet
- **Guide utilisateur** : Tutoriel pour les professeurs et élèves
- **Gestion des tickets et support** : Système de suivi des bugs et améliorations (JIRA, Trello)
- **FAQ** : Documentation des questions fréquemment posées
- **Tutoriels** : Guides d'utilisation des fonctionnalités de gestion d'images (téléversement, recadrage, etc.)