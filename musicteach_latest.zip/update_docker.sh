#!/bin/bash

# Définition des couleurs pour un affichage plus clair
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Mise à jour Docker MusiTeach - Nouvelles Fonctionnalités ===${NC}"

# Vérifier si une sauvegarde a été effectuée
if [ ! -d "BACKUP" ] || [ $(ls -1 BACKUP | grep "musicteach_update_features" | wc -l) -eq 0 ]; then
    echo -e "${YELLOW}Aucune sauvegarde récente trouvée. Il est recommandé de faire une sauvegarde avant de continuer.${NC}"
    read -p "Voulez-vous créer une sauvegarde maintenant? (o/n): " create_backup
    
    if [[ "$create_backup" == "o" || "$create_backup" == "O" || "$create_backup" == "oui" ]]; then
        ./backup_update.sh
    else
        echo -e "${RED}Attention: Vous continuez sans sauvegarde.${NC}"
    fi
fi

# Arrêter les conteneurs existants
echo -e "${YELLOW}Arrêt des conteneurs existants...${NC}"
docker-compose down
echo -e "${GREEN}Conteneurs arrêtés${NC}"

# Mettre à jour l'image Docker
echo -e "${YELLOW}Mise à jour des images Docker...${NC}"

# Définir le nouveau tag pour l'image
NEW_TAG="v$(date +"%Y%m%d")"

# Modifier le docker-compose.yml pour utiliser le nouveau tag
sed -i "s/image: php:8.1-apache/image: php:8.1-apache:${NEW_TAG}/g" docker-compose.yml

# Ajouter des extensions PHP supplémentaires pour les nouvelles fonctionnalités
echo -e "${YELLOW}Mise à jour du fichier docker-compose.yml avec les extensions PHP nécessaires...${NC}"

# Sauvegarde du fichier docker-compose.yml
cp docker-compose.yml docker-compose.yml.bak

# Ajouter les extensions PHP nécessaires pour les nouvelles fonctionnalités
cat > docker-compose.yml << 'EOL'
version: '3.8'

services:
  webserver:
    image: php:8.1-apache
    container_name: musicteach_web
    ports:
      - "8000:80"
    volumes:
      - .:/var/www/html
    depends_on:
      - mysql
    environment:
      - MYSQL_HOST=mysql
      - MYSQL_DATABASE=musicteach
      - MYSQL_USER=musicteach
      - MYSQL_PASSWORD=musicteach
    restart: unless-stopped
    command: >
      bash -c "
        apt-get update &&
        apt-get install -y libpq-dev libzip-dev zip unzip libicu-dev libpng-dev libjpeg-dev libfreetype6-dev &&
        docker-php-ext-configure gd --with-freetype --with-jpeg &&
        docker-php-ext-install pdo pdo_mysql zip gd intl exif &&
        a2enmod rewrite &&
        echo 'DocumentRoot /var/www/html/public' > /etc/apache2/sites-available/000-default.conf &&
        echo '<Directory /var/www/html/public>' >> /etc/apache2/sites-available/000-default.conf &&
        echo '  AllowOverride All' >> /etc/apache2/sites-available/000-default.conf &&
        echo '  Require all granted' >> /etc/apache2/sites-available/000-default.conf &&
        echo '</Directory>' >> /etc/apache2/sites-available/000-default.conf &&
        apache2-foreground
      "
    networks:
      - musicteach_network

  mysql:
    image: mariadb:10.6
    container_name: musicteach_db
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: musicteach
      MYSQL_USER: musicteach
      MYSQL_PASSWORD: musicteach
    volumes:
      - mysql_data:/var/lib/mysql
      - ./database/schema.sql:/docker-entrypoint-initdb.d/schema.sql
    restart: unless-stopped
    networks:
      - musicteach_network
    command: --character-set-server=utf8mb4 --collation-server=utf8mb4_unicode_ci

  phpmyadmin:
    image: phpmyadmin/phpmyadmin
    container_name: musicteach_phpmyadmin
    depends_on:
      - mysql
    ports:
      - "8080:80"
    environment:
      - PMA_HOST=mysql
      - PMA_PORT=3306
      - MYSQL_ROOT_PASSWORD=root
    restart: unless-stopped
    networks:
      - musicteach_network

volumes:
  mysql_data:
    name: musicteach_data

networks:
  musicteach_network:
    name: musicteach_network
EOL

echo -e "${GREEN}Docker-compose mis à jour avec succès${NC}"

# Lancer les nouveaux conteneurs
echo -e "${YELLOW}Lancement des nouveaux conteneurs...${NC}"
docker-compose up -d --build

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Conteneurs démarrés avec succès${NC}"
    echo -e "${GREEN}MusiTeach est maintenant disponible avec les nouvelles fonctionnalités à:${NC}"
    echo -e "${BLUE}- Application: http://localhost:8000${NC}"
    echo -e "${BLUE}- phpMyAdmin: http://localhost:8181${NC}"
    echo 
    echo -e "${YELLOW}Nouveautés disponibles:${NC}"
    echo "- FAQ (http://localhost:8000/faq.php)"
    echo "- Ressources musicales (http://localhost:8000/resources.php)"
    echo "- Conditions d'utilisation (http://localhost:8000/terms.php)"
    echo "- Politique de confidentialité (http://localhost:8000/privacy.php)"
    echo "- Mode sombre activable sur toutes les pages"
else
    echo -e "${RED}Échec du démarrage des conteneurs${NC}"
    echo -e "${YELLOW}Restauration de la configuration Docker précédente...${NC}"
    mv docker-compose.yml.bak docker-compose.yml
    docker-compose up -d
    exit 1
fi

echo -e "${GREEN}Mise à jour terminée avec succès!${NC}"