<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Profile.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Paramètres de pagination
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 20; // Nombre d'utilisateurs par page

// Récupérer tous les utilisateurs
$users = User::findAll($page, $perPage);
$totalUsers = User::count();
$totalPages = ceil($totalUsers / $perPage);

// Titre de la page
$pageTitle = "Gestion des utilisateurs";

// Inclure l'en-tête
include_once __DIR__ . '/../resources/views/header.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Administration - Gestion des utilisateurs</h1>
    
    <!-- Actions rapides -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Actions rapides</h5>
                    <div class="d-flex gap-2">
                        <a href="admin_dashboard.php" class="btn btn-outline-primary">
                            <i class="fas fa-tachometer-alt me-2"></i>Tableau de bord
                        </a>
                        <a href="admin_users.php" class="btn btn-primary">
                            <i class="fas fa-users me-2"></i>Utilisateurs
                        </a>
                        <a href="admin_bookings.php" class="btn btn-outline-primary">
                            <i class="fas fa-calendar-alt me-2"></i>Réservations
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Liste des utilisateurs -->
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="card-title mb-0">Liste des utilisateurs</h5>
                <a href="admin_user_add.php" class="btn btn-success">
                    <i class="fas fa-plus me-2"></i>Ajouter un utilisateur
                </a>
            </div>
            
            <!-- Formulaire de recherche -->
            <form action="admin_users.php" method="get" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <input type="text" name="search" class="form-control" placeholder="Rechercher par nom ou email"
                               value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <select name="role" class="form-select">
                            <option value="">Tous les rôles</option>
                            <option value="student" <?= isset($_GET['role']) && $_GET['role'] === 'student' ? 'selected' : '' ?>>Élèves</option>
                            <option value="teacher" <?= isset($_GET['role']) && $_GET['role'] === 'teacher' ? 'selected' : '' ?>>Professeurs</option>
                            <option value="admin" <?= isset($_GET['role']) && $_GET['role'] === 'admin' ? 'selected' : '' ?>>Administrateurs</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">Rechercher</button>
                    </div>
                </div>
            </form>
            
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Rôle</th>
                            <th>Date d'inscription</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td><?= htmlspecialchars($user['name']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td>
                                    <?php
                                    switch ($user['role']) {
                                        case 'student':
                                            echo '<span class="badge bg-info">Élève</span>';
                                            break;
                                        case 'teacher':
                                            echo '<span class="badge bg-success">Professeur</span>';
                                            break;
                                        case 'admin':
                                            echo '<span class="badge bg-danger">Admin</span>';
                                            break;
                                        default:
                                            echo '<span class="badge bg-secondary">Inconnu</span>';
                                    }
                                    ?>
                                </td>
                                <td><?= formatDate($user['created_at']) ?></td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="admin_user_edit.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                            <a href="admin_user_delete.php?id=<?= $user['id'] ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ? Cette action est irréversible.');">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?= generatePagination($page, $totalPages, 'admin_users.php?page=%d') ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// Inclure le pied de page
include_once __DIR__ . '/../resources/views/footer.php';
?>