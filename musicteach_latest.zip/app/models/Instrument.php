<?php
require_once __DIR__ . '/../db_connect.php';

/**
 * Modèle pour la gestion des instruments
 */
class Instrument {
    /**
     * Récupérer tous les instruments
     * 
     * @return array Liste des instruments
     */
    public static function findAll() {
        $db = getDbConnection();
        $stmt = $db->query("SELECT * FROM instruments ORDER BY name");
        return $stmt->fetchAll();
    }
    
    /**
     * Récupérer un instrument par son ID
     * 
     * @param int $id ID de l'instrument
     * @return array|false Données de l'instrument ou false si non trouvé
     */
    public static function findById($id) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM instruments WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
    
    /**
     * Créer un nouvel instrument
     * 
     * @param string $name Nom de l'instrument
     * @param string $category Catégorie de l'instrument
     * @return int|false ID de l'instrument créé ou false en cas d'erreur
     */
    public static function create($name, $category) {
        $db = getDbConnection();
        
        $stmt = $db->prepare(
            "INSERT INTO instruments (name, category, created_at, updated_at) 
             VALUES (:name, :category, NOW(), NOW())"
        );
        
        $stmt->execute([
            'name' => $name,
            'category' => $category
        ]);
        
        return $db->lastInsertId();
    }
    
    /**
     * Mettre à jour un instrument
     * 
     * @param int $id ID de l'instrument
     * @param array $data Données à mettre à jour
     * @return bool Succès de l'opération
     */
    public static function update($id, $data) {
        $db = getDbConnection();
        
        $allowedFields = ['name', 'category'];
        $fields = [];
        $params = ['id' => $id];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $fields[] = "$key = :$key";
                $params[$key] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = NOW()";
        $sql = "UPDATE instruments SET " . implode(', ', $fields) . " WHERE id = :id";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
    }
    
    /**
     * Supprimer un instrument
     * 
     * @param int $id ID de l'instrument
     * @return bool Succès de l'opération
     */
    public static function delete($id) {
        $db = getDbConnection();
        $stmt = $db->prepare("DELETE FROM instruments WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    /**
     * Récupérer les instruments par catégorie
     * 
     * @param string $category Catégorie d'instruments
     * @return array Liste des instruments
     */
    public static function findByCategory($category) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM instruments WHERE category = :category ORDER BY name");
        $stmt->execute(['category' => $category]);
        return $stmt->fetchAll();
    }
    
    /**
     * Récupérer toutes les catégories d'instruments
     * 
     * @return array Liste des catégories
     */
    public static function getAllCategories() {
        $db = getDbConnection();
        $stmt = $db->query("SELECT DISTINCT category FROM instruments ORDER BY category");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    /**
     * Rechercher des instruments par nom
     * 
     * @param string $query Terme de recherche
     * @return array Liste des instruments correspondants
     */
    public static function search($query) {
        $db = getDbConnection();
        $stmt = $db->prepare("SELECT * FROM instruments WHERE name LIKE :query ORDER BY name");
        $stmt->execute(['query' => '%' . $query . '%']);
        return $stmt->fetchAll();
    }
}