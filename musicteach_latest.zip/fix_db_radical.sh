#!/bin/bash

# Obtenir l'ID du conteneur webserver
WEBSERVER=$(docker ps | grep musicteach_webserver | awk '{print $1}')
if [ -z "$WEBSERVER" ]; then
    echo "Le conteneur webserver n'est pas en cours d'exécution"
    exit 1
fi

# Copier directement le fichier simple dans le conteneur
docker cp /home/fennec/PROJECTS/MUSICTEACH/db_connect_simple.php ${WEBSERVER}:/var/www/html/app/db_connect.php
echo "Fichier de connexion simplifié copié dans le conteneur"

# Activer les extensions PHP nécessaires dans le conteneur
docker exec ${WEBSERVER} bash -c "docker-php-ext-install mysqli && docker-php-ext-enable mysqli && service apache2 restart"
echo "Extension mysqli installée et activée dans le conteneur"

# Vérifier les modules PHP activés
echo "Modules PHP activés dans le conteneur:"
docker exec ${WEBSERVER} php -m

# Créer un fichier de test directement dans le conteneur
docker exec ${WEBSERVER} bash -c "cat > /var/www/html/public/test_simple.php << 'EOF'
<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo '<h1>Test de connexion à la base de données</h1>';

// Fonction de connexion directe
function getDirectDbConnection() {
    try {
        \$dsn = 'mysql:host=mysql;dbname=musicteach;charset=utf8mb4';
        \$pdo = new PDO(\$dsn, 'musicteach', 'musicteach');
        \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return \$pdo;
    } catch (PDOException \$e) {
        die('Erreur de connexion : ' . \$e->getMessage());
    }
}

// Extensions PHP
echo '<h2>Extensions PHP chargées</h2>';
echo '<pre>';
print_r(get_loaded_extensions());
echo '</pre>';

// Test de connexion directe
echo '<h2>Test de connexion directe</h2>';
try {
    \$db = getDirectDbConnection();
    echo '<p style=\"color:green\">Connexion directe réussie!</p>';
    
    // Test de requête
    \$stmt = \$db->query('SHOW TABLES');
    \$tables = \$stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo '<h3>Tables dans la base de données:</h3>';
    echo '<ul>';
    foreach (\$tables as \$table) {
        echo '<li>' . \$table . '</li>';
    }
    echo '</ul>';
    
} catch (Exception \$e) {
    echo '<p style=\"color:red\">Erreur de connexion directe: ' . \$e->getMessage() . '</p>';
}

// Test avec fichier db_connect.php
echo '<h2>Test avec le fichier db_connect.php</h2>';
try {
    require_once __DIR__ . '/../app/db_connect.php';
    \$db = getDbConnection();
    echo '<p style=\"color:green\">Connexion via getDbConnection réussie!</p>';
} catch (Exception \$e) {
    echo '<p style=\"color:red\">Erreur avec getDbConnection: ' . \$e->getMessage() . '</p>';
}

// Contenu du fichier db_connect.php
echo '<h2>Contenu du fichier db_connect.php</h2>';
echo '<pre>';
highlight_file(__DIR__ . '/../app/db_connect.php');
echo '</pre>';
EOF"
echo "Fichier de test créé dans le conteneur"

echo "Vous pouvez maintenant accéder à http://localhost:8000/test_simple.php pour vérifier la connexion"