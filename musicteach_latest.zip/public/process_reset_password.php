<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/db_connect.php';

// Démarrer la session
startSession();

// Rediriger si déjà connecté
if (isLoggedIn()) {
    redirect('dashboard.php');
}

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('reset_password.php');
}

// Vérifier le token CSRF
if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
    setFlashMessage('error', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
    redirect('reset_password.php');
}

// Récupérer et nettoyer les données du formulaire
$token = sanitizeInput($_POST['token'] ?? '');
$password = $_POST['password'] ?? '';
$passwordConfirm = $_POST['password_confirm'] ?? '';

// Valider les données
if (empty($token)) {
    setFlashMessage('error', 'Token de réinitialisation invalide.');
    redirect('reset_password.php');
}

if (empty($password)) {
    setFlashMessage('error', 'Le mot de passe est requis.');
    redirect('reset_password.php?token=' . urlencode($token));
}

if (strlen($password) < 8) {
    setFlashMessage('error', 'Le mot de passe doit contenir au moins 8 caractères.');
    redirect('reset_password.php?token=' . urlencode($token));
}

if ($password !== $passwordConfirm) {
    setFlashMessage('error', 'Les mots de passe ne correspondent pas.');
    redirect('reset_password.php?token=' . urlencode($token));
}

try {
    $db = getDbConnection();
    
    // Vérifier si le token existe et est valide
    $stmt = $db->prepare("
        SELECT email, expiry 
        FROM password_resets 
        WHERE token = :token 
        LIMIT 1
    ");
    $stmt->execute(['token' => $token]);
    $reset = $stmt->fetch();
    
    if (!$reset) {
        setFlashMessage('error', 'Ce lien de réinitialisation est invalide ou a expiré.');
        redirect('reset_password.php');
    }
    
    // Vérifier si le token a expiré
    if (strtotime($reset['expiry']) < time()) {
        setFlashMessage('error', 'Ce lien de réinitialisation a expiré. Veuillez demander un nouveau lien.');
        
        // Supprimer le token expiré
        $stmt = $db->prepare("DELETE FROM password_resets WHERE token = :token");
        $stmt->execute(['token' => $token]);
        
        redirect('reset_password.php');
    }
    
    // Récupérer l'utilisateur
    $user = User::findByEmail($reset['email']);
    if (!$user) {
        setFlashMessage('error', 'Utilisateur non trouvé.');
        redirect('reset_password.php');
    }
    
    // Mettre à jour le mot de passe
    if (User::updatePassword($user['id'], $password)) {
        // Supprimer tous les tokens de réinitialisation pour cet utilisateur
        $stmt = $db->prepare("DELETE FROM password_resets WHERE email = :email");
        $stmt->execute(['email' => $reset['email']]);
        
        setFlashMessage('success', 'Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter avec votre nouveau mot de passe.');
        redirect('login.php');
    } else {
        setFlashMessage('error', 'Une erreur est survenue lors de la réinitialisation du mot de passe.');
        redirect('reset_password.php?token=' . urlencode($token));
    }
    
} catch (Exception $e) {
    setFlashMessage('error', 'Une erreur est survenue lors de la réinitialisation du mot de passe.');
    if (DEBUG) {
        setFlashMessage('error', 'Erreur : ' . $e->getMessage());
    }
    redirect('reset_password.php?token=' . urlencode($token));
}