<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/utils.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Booking.php';

// Vérifier si l'utilisateur est connecté et est un administrateur
requireAdmin();

// Vérifier si l'ID de réservation est fourni
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setFlashMessage('error', 'Réservation non trouvée.');
    redirect('admin_bookings.php');
}

$bookingId = (int)$_GET['id'];

// Récupérer la réservation
$booking = Booking::findById($bookingId);

// Vérifier si la réservation existe
if (!$booking) {
    setFlashMessage('error', 'Réservation non trouvée.');
    redirect('admin_bookings.php');
}

// Vérifier si la réservation est déjà annulée
if ($booking['status'] === 'canceled') {
    setFlashMessage('info', 'Cette réservation est déjà annulée.');
    redirect('admin_bookings.php');
}

// Annuler la réservation
try {
    if (Booking::update($bookingId, ['status' => 'canceled'])) {
        // TODO: Envoyer un email d'annulation à l'élève et au professeur (fonctionnalité à implémenter)
        
        setFlashMessage('success', 'La réservation a été annulée avec succès.');
    } else {
        setFlashMessage('error', 'Une erreur est survenue lors de l\'annulation de la réservation.');
    }
} catch (Exception $e) {
    setFlashMessage('error', 'Une erreur est survenue lors de l\'annulation de la réservation.');
}

// Rediriger vers la page des réservations
redirect('admin_bookings.php');
