<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la session
session_start();

// Fonction de redirection
function redirect($url) {
    header("Location: $url");
    exit;
}

// Fonction flash message
function setFlashMessage($type, $message) {
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}

// Fonction de validation CSRF
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && $_SESSION['csrf_token'] === $token;
}

// Fonction de nettoyage des entrées
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Fonction de validation d'email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('signup.php');
}

// Vérifier le token CSRF (simplifié)
if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
    setFlashMessage('danger', 'Une erreur de sécurité est survenue. Veuillez réessayer.');
    redirect('signup.php');
}

// Récupérer et nettoyer les données du formulaire
$name = sanitizeInput($_POST['name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$passwordConfirm = $_POST['password_confirm'] ?? '';
$role = sanitizeInput($_POST['role'] ?? 'student');

// Stocker les données du formulaire en session pour remplir à nouveau le formulaire en cas d'erreur
$_SESSION['form_data'] = [
    'name' => $name,
    'email' => $email,
    'role' => $role
];

// Valider les données
$errors = [];

if (empty($name)) {
    $errors[] = 'Le nom est requis.';
}

if (empty($email) || !isValidEmail($email)) {
    $errors[] = 'L\'adresse email est invalide.';
}

if (empty($password)) {
    $errors[] = 'Le mot de passe est requis.';
} elseif (strlen($password) < 8) {
    $errors[] = 'Le mot de passe doit contenir au moins 8 caractères.';
}

if ($password !== $passwordConfirm) {
    $errors[] = 'Les mots de passe ne correspondent pas.';
}

if ($role !== 'student' && $role !== 'teacher') {
    $errors[] = 'Le rôle sélectionné est invalide.';
}

// S'il y a des erreurs, rediriger avec un message d'erreur
if (!empty($errors)) {
    setFlashMessage('danger', implode(' ', $errors));
    redirect('signup.php');
}

// Connexion à la base de données
try {
    $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    $pdo = new PDO($dsn, 'musicteach', 'musicteach', $options);
    
    // Vérifier si l'email existe déjà
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    if ($stmt->fetchColumn() > 0) {
        setFlashMessage('danger', 'Cette adresse email est déjà utilisée.');
        redirect('signup.php');
    }
    
    // Hacher le mot de passe
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insérer le nouvel utilisateur
    $stmt = $pdo->prepare(
        "INSERT INTO users (name, email, password, role, is_active, created_at, updated_at) 
         VALUES (:name, :email, :password, :role, 1, NOW(), NOW())"
    );
    
    $stmt->execute([
        'name' => $name,
        'email' => $email,
        'password' => $hashedPassword,
        'role' => $role
    ]);
    
    $userId = $pdo->lastInsertId();
    
    // Créer le profil de base pour l'utilisateur
    $stmt = $pdo->prepare(
        "INSERT INTO profiles (user_id, type, created_at, updated_at) 
         VALUES (:user_id, :type, NOW(), NOW())"
    );
    
    $stmt->execute([
        'user_id' => $userId,
        'type' => $role
    ]);
    
    // Nettoyer les données de formulaire stockées en session
    unset($_SESSION['form_data']);
    
    // Définir un message de succès
    setFlashMessage('success', 'Votre compte a été créé avec succès ! Vous pouvez maintenant vous connecter.');
    
    // Rediriger vers la page de connexion
    redirect('login.php');
    
} catch (PDOException $e) {
    setFlashMessage('danger', 'Une erreur est survenue lors de la création de votre compte.');
    if (defined('DEBUG') && DEBUG) {
        error_log("Erreur PDO: " . $e->getMessage());
    }
    redirect('signup.php');
}