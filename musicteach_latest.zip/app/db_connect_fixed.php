<?php
require_once __DIR__ . '/config.php';

/**
 * Connexion à la base de données avec PDO uniquement
 * Version sécurisée sans mysqli pour les environnements limités
 * 
 * @return PDO Instance de connexion PDO
 */
function getDbConnection() {
    // S'assurer que les constantes nécessaires sont définies
    if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER') || !defined('DB_PASS')) {
        if (defined('DEBUG') && DEBUG) {
            die("Erreur de configuration: les constantes de base de données ne sont pas définies.");
        } else {
            die("Erreur de configuration du système.");
        }
    }
    
    // Connexion avec PDO
    $charset = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . $charset;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        
        // Vérifier la connexion en exécutant une requête simple
        $pdo->query("SELECT 1");
        
        return $pdo;
    } catch (\PDOException $e) {
        if (defined('DEBUG') && DEBUG) {
            throw new \PDOException($e->getMessage(), (int)$e->getCode());
        } else {
            die("Erreur de connexion à la base de données.");
        }
    }
}