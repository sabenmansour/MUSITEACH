#!/bin/bash

# Vérifier si les conteneurs sont en cours d'exécution
echo "Liste des conteneurs en cours d'exécution :"
docker ps

# Vérifier les logs des conteneurs
echo -e "\nLogs récents du conteneur mysql :"
docker logs $(docker ps | grep mysql | awk '{print $1}') | tail -n 15

echo -e "\nLogs récents du conteneur webserver :"
docker logs $(docker ps | grep webserver | awk '{print $1}') | tail -n 15

# Tester l'accès à la base de données depuis le conteneur webserver
echo -e "\nTest de connexion à la base de données depuis le conteneur webserver :"
docker exec $(docker ps | grep webserver | awk '{print $1}') php -r '
try {
    $pdo = new PDO("mysql:host=mysql;dbname=musicteach", "musicteach", "musicteach");
    echo "Connexion réussie à la base de données!\n";
    
    // Obtenir la liste des tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables dans la base de données : " . implode(", ", $tables) . "\n";
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage() . "\n";
}'

# Vérifier si le fichier db_connect.php contient encore mysqli_connect
echo -e "\nVérification du fichier db_connect.php dans le conteneur :"
docker exec $(docker ps | grep webserver | awk '{print $1}') grep -n "mysqli_connect" /var/www/html/app/db_connect.php
if [ $? -eq 0 ]; then
    echo "ERREUR : Le fichier db_connect.php contient encore des références à mysqli_connect"
else
    echo "OK : Le fichier db_connect.php ne contient plus de références à mysqli_connect"
fi