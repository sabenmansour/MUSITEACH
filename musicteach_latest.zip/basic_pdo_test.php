<?php
// Afficher les erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo '<h1>Test PDO basique</h1>';

// Tester la connexion PDO
try {
    $dsn = "mysql:host=mysql;dbname=musicteach;charset=utf8mb4";
    $user = "musicteach";
    $pass = "musicteach";
    
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo '<p style="color:green">Connexion réussie à la base de données!</p>';
    
    // Tester une requête simple
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo '<h2>Tables dans la base de données:</h2>';
    echo '<ul>';
    foreach ($tables as $table) {
        echo '<li>' . htmlspecialchars($table) . '</li>';
    }
    echo '</ul>';
    
} catch (PDOException $e) {
    echo '<p style="color:red">Erreur de connexion: ' . htmlspecialchars($e->getMessage()) . '</p>';
}
?>