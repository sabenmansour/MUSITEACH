<?php
/**
 * Gestion de l'authentification
 */

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/config.php';

// Démarrer une session si ce n'est pas déjà fait
function startSession() {
    if (session_status() === PHP_SESSION_NONE) {
        // Pour le développement, utiliser des paramètres simplifiés
        if (defined('DEBUG') && DEBUG) {
            // En développement, ne pas exiger HTTPS
            $params = [
                'lifetime' => 0,
                'path' => '/',
                'domain' => '',
                'secure' => false,
                'httponly' => true,
                'samesite' => 'Lax'
            ];
        } else {
            // En production, utiliser des paramètres sécurisés
            $cookieParams = session_get_cookie_params();
            $params = [
                'lifetime' => $cookieParams['lifetime'],
                'path' => $cookieParams['path'],
                'domain' => $cookieParams['domain'],
                'secure' => true, // Requiert HTTPS
                'httponly' => true, // Empêche l'accès JavaScript aux cookies
                'samesite' => 'Lax' // Protection contre les attaques CSRF
            ];
        }
        
        // Définir les paramètres du cookie de session
        session_set_cookie_params($params);
        
        // Démarrer la session
        session_start();
        
        // Régénère l'ID de session à chaque démarrage pour éviter la fixation de session
        if (!isset($_SESSION['last_regeneration']) || time() - $_SESSION['last_regeneration'] > 30 * 60) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}

// Vérifier si l'utilisateur est connecté
function isLoggedIn() {
    startSession();
    
    // Déjà connecté via la session
    if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
        return true;
    }
    
    // Vérifier le cookie "Se souvenir de moi"
    if (isset($_COOKIE['remember_token']) && !empty($_COOKIE['remember_token'])) {
        $token = $_COOKIE['remember_token'];
        $user = getUserByRememberToken($token);
        
        if ($user) {
            // Authentifier l'utilisateur
            loginUser($user);
            
            // Rafraîchir le token pour prolonger la durée
            refreshRememberToken($token);
            
            return true;
        } else {
            // Supprimer le cookie invalide
            setcookie(
                'remember_token', 
                '', 
                time() - 3600, 
                '/', 
                '', 
                true, 
                true
            );
        }
    }
    
    return false;
}

/**
 * Récupérer un utilisateur à partir d'un token "Se souvenir de moi"
 */
function getUserByRememberToken($token) {
    try {
        require_once __DIR__ . '/db_connect.php';
        $db = getDbConnection();
        
        // Vérifier si la table remember_tokens existe
        $stmt = $db->prepare("SHOW TABLES LIKE 'remember_tokens'");
        $stmt->execute();
        $tableExists = $stmt->fetchColumn();
        
        if (!$tableExists) {
            return null;
        }
        
        // Supprimer les tokens expirés
        $db->exec("DELETE FROM remember_tokens WHERE expiry < NOW()");
        
        // Récupérer le token valide
        $stmt = $db->prepare("
            SELECT u.* FROM users u
            JOIN remember_tokens t ON u.id = t.user_id
            WHERE t.token = :token
            AND t.expiry > NOW()
            LIMIT 1
        ");
        $stmt->execute(['token' => $token]);
        
        return $stmt->fetch();
    } catch (Exception $e) {
        if (defined('DEBUG') && DEBUG) {
            error_log("Error getting user by remember token: " . $e->getMessage());
        }
        return null;
    }
}

/**
 * Rafraîchir un token "Se souvenir de moi" pour prolonger sa durée
 */
function refreshRememberToken($token) {
    try {
        require_once __DIR__ . '/db_connect.php';
        $db = getDbConnection();
        
        // Vérifier si la table remember_tokens existe
        $stmt = $db->prepare("SHOW TABLES LIKE 'remember_tokens'");
        $stmt->execute();
        $tableExists = $stmt->fetchColumn();
        
        if (!$tableExists) {
            return false;
        }
        
        // Prolonger la durée du token (30 jours)
        $newExpiry = time() + (30 * 24 * 60 * 60);
        
        $stmt = $db->prepare("
            UPDATE remember_tokens 
            SET expiry = FROM_UNIXTIME(:expiry)
            WHERE token = :token
        ");
        
        $stmt->execute([
            'token' => $token,
            'expiry' => $newExpiry
        ]);
        
        // Mettre à jour également le cookie
        setcookie(
            'remember_token',
            $token,
            [
                'expires' => $newExpiry,
                'path' => '/',
                'domain' => '',
                'secure' => true,
                'httponly' => true,
                'samesite' => 'Lax'
            ]
        );
        
        return true;
    } catch (Exception $e) {
        if (defined('DEBUG') && DEBUG) {
            error_log("Error refreshing remember token: " . $e->getMessage());
        }
        return false;
    }
}

// Vérifier si l'utilisateur est un admin
function isAdmin() {
    startSession();
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Vérifier si l'utilisateur est un professeur
function isTeacher() {
    startSession();
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'teacher';
}

// Vérifier si l'utilisateur est un étudiant
function isStudent() {
    startSession();
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'student';
}

// Authentifier un utilisateur
function loginUser($user) {
    startSession();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['logged_in'] = true;
    
    // Régénère l'ID de session à la connexion pour éviter la fixation de session
    session_regenerate_id(true);
    
    // Enregistrer l'historique de connexion
    logLogin($user['id']);
}

// Déconnecter un utilisateur
function logoutUser() {
    startSession();
    
    // Récupérer l'ID de l'utilisateur pour la journalisation
    $userId = $_SESSION['user_id'] ?? null;
    
    // Supprimer le token "Se souvenir de moi" s'il existe
    if (isset($_COOKIE['remember_token'])) {
        $token = $_COOKIE['remember_token'];
        
        try {
            require_once __DIR__ . '/db_connect.php';
            $db = getDbConnection();
            
            // Vérifier si la table remember_tokens existe
            $stmt = $db->prepare("SHOW TABLES LIKE 'remember_tokens'");
            $stmt->execute();
            $tableExists = $stmt->fetchColumn();
            
            if ($tableExists) {
                // Supprimer le token de la base de données
                $stmt = $db->prepare("DELETE FROM remember_tokens WHERE token = :token");
                $stmt->execute(['token' => $token]);
            }
        } catch (Exception $e) {
            // Silently fail - logging should not prevent logout
            if (defined('DEBUG') && DEBUG) {
                error_log("Error removing remember token: " . $e->getMessage());
            }
        }
        
        // Supprimer le cookie
        setcookie(
            'remember_token', 
            '', 
            time() - 3600, 
            '/', 
            '', 
            true, 
            true
        );
    }
    
    // Enregistrer la déconnexion
    if ($userId) {
        logLogout($userId);
    }
    
    // Détruire la session
    session_unset();
    session_destroy();
    
    // Supprimer le cookie de session
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), 
            '', 
            time() - 42000, 
            $params['path'], 
            $params['domain'], 
            $params['secure'], 
            $params['httponly']
        );
    }
}

// Rediriger si non connecté
function requireLogin() {
    if (!isLoggedIn()) {
        // Sauvegarder l'URL demandée pour rediriger après la connexion
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            startSession();
            $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        }
        
        setFlashMessage('error', 'Vous devez être connecté pour accéder à cette page.');
        redirect('login.php');
    }
}

// Rediriger si non admin
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        setFlashMessage('error', 'Accès réservé aux administrateurs.');
        redirect('index.php');
    }
}

// Rediriger si non professeur
function requireTeacher() {
    requireLogin();
    if (!isTeacher()) {
        setFlashMessage('error', 'Accès réservé aux professeurs.');
        redirect('index.php');
    }
}

// Rediriger si non étudiant
function requireStudent() {
    requireLogin();
    if (!isStudent()) {
        setFlashMessage('error', 'Accès réservé aux élèves.');
        redirect('index.php');
    }
}

// Gérer les messages flash
function setFlashMessage($type, $message) {
    startSession();
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message
    ];
}

// Récupérer et supprimer le message flash
function getFlashMessage() {
    startSession();
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $message;
    }
    return null;
}

// Hasher un mot de passe
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT, ['cost' => 12]);
}

// Vérifier un mot de passe
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Vérifier la complexité d'un mot de passe
function isPasswordStrong($password) {
    // Longueur minimale
    if (strlen($password) < 8) {
        return false;
    }
    
    // Vérifier s'il contient au moins un chiffre
    if (!preg_match('/\d/', $password)) {
        return false;
    }
    
    // Vérifier s'il contient au moins une majuscule
    if (!preg_match('/[A-Z]/', $password)) {
        return false;
    }
    
    // Vérifier s'il contient au moins une minuscule
    if (!preg_match('/[a-z]/', $password)) {
        return false;
    }
    
    return true;
}

// Générer un token de réinitialisation de mot de passe
function generatePasswordResetToken() {
    return bin2hex(random_bytes(32));
}

// Générer un token d'activation de compte
function generateActivationToken() {
    return bin2hex(random_bytes(16));
}

// Enregistrer une connexion dans l'historique
function logLogin($userId) {
    if (defined('LOG_AUTH_ACTIVITIES') && LOG_AUTH_ACTIVITIES) {
        try {
            require_once __DIR__ . '/db_connect.php';
            $db = getDbConnection();
            
            // Vérifier si la table auth_logs existe
            $stmt = $db->prepare("SHOW TABLES LIKE 'auth_logs'");
            $stmt->execute();
            $tableExists = $stmt->fetchColumn();
            
            // Créer la table si elle n'existe pas
            if (!$tableExists) {
                $db->exec("
                    CREATE TABLE auth_logs (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        action ENUM('login', 'logout', 'failed_login') NOT NULL,
                        ip_address VARCHAR(45) NOT NULL,
                        user_agent VARCHAR(255) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        INDEX(user_id),
                        INDEX(action)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                ");
            }
            
            $stmt = $db->prepare("
                INSERT INTO auth_logs (user_id, action, ip_address, user_agent) 
                VALUES (:user_id, 'login', :ip_address, :user_agent)
            ");
            
            $stmt->execute([
                'user_id' => $userId,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);
        } catch (Exception $e) {
            // Silently fail - logging should not prevent login
            if (defined('DEBUG') && DEBUG) {
                error_log("Error logging login: " . $e->getMessage());
            }
        }
    }
}

// Enregistrer une déconnexion dans l'historique
function logLogout($userId) {
    if (defined('LOG_AUTH_ACTIVITIES') && LOG_AUTH_ACTIVITIES) {
        try {
            require_once __DIR__ . '/db_connect.php';
            $db = getDbConnection();
            
            $stmt = $db->prepare("SHOW TABLES LIKE 'auth_logs'");
            $stmt->execute();
            $tableExists = $stmt->fetchColumn();
            
            if ($tableExists) {
                $stmt = $db->prepare("
                    INSERT INTO auth_logs (user_id, action, ip_address, user_agent) 
                    VALUES (:user_id, 'logout', :ip_address, :user_agent)
                ");
                
                $stmt->execute([
                    'user_id' => $userId,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                ]);
            }
        } catch (Exception $e) {
            // Silently fail
            if (defined('DEBUG') && DEBUG) {
                error_log("Error logging logout: " . $e->getMessage());
            }
        }
    }
}

// Enregistrer une tentative de connexion échouée
function logFailedLogin($email) {
    if (defined('LOG_AUTH_ACTIVITIES') && LOG_AUTH_ACTIVITIES) {
        try {
            require_once __DIR__ . '/db_connect.php';
            $db = getDbConnection();
            
            $stmt = $db->prepare("SHOW TABLES LIKE 'auth_logs'");
            $stmt->execute();
            $tableExists = $stmt->fetchColumn();
            
            if ($tableExists) {
                // Obtenir l'ID de l'utilisateur si possible
                $userId = null;
                $stmt = $db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
                $stmt->execute(['email' => $email]);
                $user = $stmt->fetch();
                if ($user) {
                    $userId = $user['id'];
                }
                
                $stmt = $db->prepare("
                    INSERT INTO auth_logs (user_id, action, ip_address, user_agent) 
                    VALUES (:user_id, 'failed_login', :ip_address, :user_agent)
                ");
                
                $stmt->execute([
                    'user_id' => $userId ?? 0,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                ]);
            }
        } catch (Exception $e) {
            // Silently fail
            if (defined('DEBUG') && DEBUG) {
                error_log("Error logging failed login: " . $e->getMessage());
            }
        }
    }
}

/**
 * Vérifier le nombre de tentatives de connexion échouées récentes
 * Retourne true si le compte n'est pas bloqué, false sinon
 */
function checkLoginAttempts($email) {
    if (defined('MAX_LOGIN_ATTEMPTS') && MAX_LOGIN_ATTEMPTS > 0) {
        try {
            require_once __DIR__ . '/db_connect.php';
            $db = getDbConnection();
            
            $stmt = $db->prepare("SHOW TABLES LIKE 'auth_logs'");
            $stmt->execute();
            $tableExists = $stmt->fetchColumn();
            
            if ($tableExists) {
                // Obtenir l'ID de l'utilisateur
                $stmt = $db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
                $stmt->execute(['email' => $email]);
                $user = $stmt->fetch();
                
                if ($user) {
                    // Compter les tentatives récentes (dans les 30 dernières minutes)
                    $stmt = $db->prepare("
                        SELECT COUNT(*) 
                        FROM auth_logs 
                        WHERE user_id = :user_id 
                        AND action = 'failed_login' 
                        AND created_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
                    ");
                    $stmt->execute(['user_id' => $user['id']]);
                    $attempts = $stmt->fetchColumn();
                    
                    return $attempts < MAX_LOGIN_ATTEMPTS;
                }
            }
            
            return true; // Par défaut, autoriser la connexion
        } catch (Exception $e) {
            // En cas d'erreur, autoriser la connexion
            if (defined('DEBUG') && DEBUG) {
                error_log("Error checking login attempts: " . $e->getMessage());
            }
            return true;
        }
    }
    
    return true; // Si la limitation n'est pas activée
}